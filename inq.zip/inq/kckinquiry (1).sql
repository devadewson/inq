-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 06 Nov 2023 pada 03.36
-- Versi server: 10.1.38-MariaDB
-- Versi PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kckinquiry`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `fasbg`
--

CREATE TABLE `fasbg` (
  `id` bigint(20) NOT NULL,
  `flag` bigint(20) DEFAULT NULL,
  `pt` varchar(8000) DEFAULT NULL,
  `norek` varchar(255) DEFAULT NULL,
  `komit` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `fasbg`
--

INSERT INTO `fasbg` (`id`, `flag`, `pt`, `norek`, `komit`) VALUES
(1, 1, 'TESTING', 'TESTING', 'TESTING'),
(2, 2, 'PT ABC ', '205-900-0001', '001'),
(3, 3, 'PT. Primus Sanus Cooking Oil (Priscolin)', '205-900-1030', 'Kom 15 (induk), Kom 16 (BG)'),
(4, 4, 'PT Pacinesia Chemical Industry', '035-900-7738', '004'),
(5, 5, 'PT ABC ', '205-900-0001', '001'),
(6, 6, 'qwerty', '123456', '5'),
(7, 7, 'PT ABC ', '205-900-0001', '001'),
(8, 8, 'qwerty', '123456', '5'),
(9, 9, 'qwerty', '123456', '5'),
(10, 10, '123', '1234314', '112'),
(11, 11, 'mns', '1234314', '112'),
(12, 12, 'mns', '', ''),
(13, 13, 'ABC', '205-900-0002', '005'),
(14, 14, 'PT ABC ', '205-900-0001', '001'),
(15, 15, 'PT Adikencana Mahkotabuana', '0359301814', '003'),
(16, 16, 'PT. Valbury Sekuritas Indonesia', '2059003334', '1'),
(17, 17, 'ss', 'ss', 'ss'),
(18, 18, 'PT Pancaran Darat Transport', '2059011191', '006,007'),
(19, 19, 'PT Pancaran Samudera Transport', '2059011205', '002'),
(20, 20, 'PT. Panca Budi Pratama', '035.930.3507', '013'),
(21, 21, 'PT. Panca Budi Idaman, Tbk', '035.930.4261', '004'),
(22, 22, 'PT. Panca Budi Niaga', '205.907.1984', '008'),
(23, 23, 'PT. Polytech Indo Hausen', '205.907.1674', '004'),
(24, 24, 'PT. Tirtobumi Adyatunggal', '2059012741', '001'),
(25, 25, 'qwerty', '', ''),
(26, 26, 'PT Anugrah Argon Medica', '0359094738', '005'),
(27, 27, 'PT Modern Widya Tehnical', '2309878994', '8'),
(28, 27, 'PT Modern Widya Tehnical', '2309878994', '18'),
(29, 28, 'PT Steel Pipe Industry of Indonesia Tbk', '205-907-146-1', '003'),
(30, 28, 'PT Steel Pipe Industry of Indonesia Tbk', '205-900-232-0', '011'),
(31, 28, 'PT Steel Pipe Industry of Indonesia Tbk', '010-907-287-9', '001'),
(32, 29, 'PT Pancaran Darat Transport', '2059011191', '007'),
(33, 30, 'PT. Aneka Tambang, Tbk', '2059072191', '004'),
(34, 31, 'Multimas Nabati Asahan', '2059006562', '007'),
(35, 32, 'PT Pancaran Samudeta Transport', '2059011205', '002'),
(36, 33, 'Multimas Nabati Asahan', '2059006562', '012'),
(37, 34, 'PT. CS2 POLA SEHAT', '2059006252', '005'),
(38, 35, 'TESTES1', '', ''),
(39, 35, 'TESTES2', '', ''),
(40, 36, 'PT Indoprima Gemilang', '342 957 4995', '003'),
(41, 37, 'PT. Cibadak Indah Sari Farm ', '205-900-1030', 'Kom 7 (induk), Kom 9 & 10 (BG), Kom 11 (LC Line) '),
(42, 38, 'PT SMART, Tbk.', '035-9300-800', '008'),
(43, 38, 'PT Soci Mas', '', ''),
(44, 38, 'PT Sinarmas Bio Energy', '', ''),
(45, 38, 'PT Rolimex Kimia Nusamas', '', ''),
(46, 39, 'PT Panorama JTB Tours Indonesia', '2619000140', '9'),
(47, 40, 'PT. Primus Sanus Cooking Oil Industrial (Priscolin)', '2059001030', '016 (BG Induk IDR) '),
(48, 41, 'PT. BARIA BULK TERMINAL', '1689013480', '11'),
(49, 42, 'PT. Kino Indonesia, Tbk', '286.900.0064', '007'),
(50, 43, 'PT. Tirtobumi Adyatunggal', '2059012741', 'baru'),
(51, 44, 'PT Combiphar', '0359007215', '2'),
(52, 45, 'Sinochem Grup', '205-900-840-9', '004'),
(53, 46, 'PT. Metropolitan Kentjana, Tbk', '035-900-5883', '006'),
(54, 47, 'PT Indomarco Adi Prima', '035-900-5841', '004'),
(55, 48, 'PT. Nikko Sekuritas Indonesia', '2059002958', '1'),
(56, 49, 'PT. Samuel Sekuritas Indonesia', '205.9004870', '1'),
(57, 50, 'PT Indofood CBP Sukses Makmur, Tbk.', '205-900-0874', '001 (USD), 002 (IDR)'),
(58, 51, 'PT. GUDANG GARAM TBK', '0359006553', '003'),
(59, 52, 'PT. TIRTA FRESINDO JAYA', '2059071828', '006'),
(60, 53, 'PT. BARIA  BULK TERMINAL', '1689013480', '11'),
(61, 54, 'PT Rintis Sejahtera', '035-930-2314', ' 002 beserta sub limitnya'),
(62, 55, 'PT. Primus Sanus Cooking Oil (Priscolin)', '205-900-1030', '016 (BG Induk IDR ) '),
(63, 56, 'PT Indominco Mandiri', '2059071020', '002'),
(64, 56, 'PT Kitadin', '2059071046', '004'),
(65, 56, 'PT Jorong Barutama Greston', '2059071038', '002'),
(66, 56, 'PT Bharinto Ekatama', '2059072361', '006'),
(67, 56, 'PT Trubaindo Coal Mining', '2059071321', '012'),
(68, 57, 'PT. Cakrawal Mega Indah', '0359096633', 'KMF(004), BG (005)'),
(69, 58, 'PT Indomarco Adi Prima', '035-900-5841', '004'),
(70, 59, 'PT Indomarco Adi Prima', '035-900-5841', '004'),
(71, 60, 'PT. Cakrawal Mega Indah', '0359096633', 'KMF(004), BG (005)'),
(72, 61, 'TESTES', '', ''),
(73, 62, 'PT Indofood CBP Sukses Makmur, Tbk.', '205-900-0874', '001 (USD), 002 (IDR)'),
(74, 63, 'PT Dian Bahari Sejati', '205 901 0888', '008'),
(75, 64, 'PT Tirta Kencana Cahaya Mandiri ', '205-901-2848', '004'),
(76, 65, 'PT G5 Power ', '327-900-1665', '001'),
(77, 66, 'PT MULIAGLASS', '205.907.1488 ', '30'),
(78, 67, 'PT Finusolprima Farma Internasional', '2059004462', '003'),
(79, 68, 'PT Wahana Mas Mulia', '084 9067 127', '007'),
(80, 69, 'PT Andini Sarana', '2059005884', '003'),
(81, 70, 'PT Bintang Toedjoe', '2059002044', '004'),
(82, 71, 'PT Srikandi Diamond Motors', '0359005646', '4,5,6,8,9,12,13'),
(83, 72, 'PT Srikandi Diamond Indah Motors', '0359005654', '4,5,6,8,9,11,10,12'),
(84, 73, 'PT Gemilang Berlian Indah', '0359005999', '5,6,10,11,12,14'),
(85, 74, 'PT. Japfa Comfeed Indonesia', '2059071186', '4'),
(86, 74, 'PT. Suri Tani Pemuka', '2059008328', '5'),
(87, 75, 'Sinochem Grup', '205-900-840-9', '004'),
(88, 76, 'PT Kobexindo Tractors', '2069092424', '012'),
(89, 76, 'PT Kobexindo Forklift Indonesia', '2069136286', '003'),
(90, 76, 'PT Kobexindo Persada Sejahtera', '9880579018', '003'),
(91, 76, 'PT Kobexindo Equipment', '2069237881', '002'),
(92, 76, 'PT Eurotruck Transindo', '2069823208', '009'),
(93, 77, 'PT BANGUNREKSA PERKASA', '2059005531', '1'),
(94, 78, 'PT Nikko Sekuritas Indonesia', '2059002958', '1'),
(95, 79, 'PT Putra Baja Deli', '2059004381', '15'),
(96, 79, 'PT Putra Baja Deli', '2059004381', '6'),
(97, 79, 'PT Putra Baja Deli', '2059004381', '20'),
(98, 80, 'PT Olam Indonesia', '0359006600', '08'),
(99, 81, 'PT. Wisisco Baja Putra', '2059006503', '10'),
(100, 82, 'PT. Aneka Tambang, Tbk', '2059072191', '004'),
(101, 83, 'PT AM/NS Indonesia', '0359302845', '6'),
(102, 84, 'PT. BARIA BULK TERMINAL', '1689013480', '11'),
(103, 85, 'PT. ARTA BATRINDO', '1689001678', '007'),
(104, 86, 'PT Soho Global Health Tbk', '2059013089', '2'),
(105, 86, 'PT Soho Industri Pharmasi', '0359008025', '2'),
(106, 86, 'PT Parit Padang Global', '2059001595', '4'),
(107, 87, 'PT. TRIAS TOYOBO ASTRIA', '0359006189', '10'),
(108, 88, 'PT. Pelayaran Mana Lagi', '2059011540', '2'),
(109, 89, 'PT Growth Asia', '2059002206', '026'),
(110, 90, 'PT Bahtera Bahari Shipyard', '2059009413', '2'),
(111, 91, 'Wilmar Grup', '2059006791', '001'),
(112, 91, 'Wilmar Grup', '20590006791', '002'),
(113, 91, 'Sinar Alam Permai', '0359302888', '002'),
(114, 91, 'Sinar Alam Permai', '0359302888', '010'),
(115, 91, 'Multi Nabati Sulawesi', '2059070562', '002'),
(116, 91, 'Multi Nabati Sulawesi', '2059070562', '008'),
(117, 91, 'Duta Sugar International', '2059002788', '001'),
(118, 91, 'Duta Sugar International', '2059002788', '007'),
(119, 91, 'Petro Andalan Nusantara', '2059006554', '003'),
(120, 91, 'Petro Andalan Nusantara', '2059006554', '006'),
(121, 91, 'Wilmar Bioenergi Indonesia', '2059072506', '002'),
(122, 91, 'Wilmar Bioenergi Indonesia', '2059072506', '011'),
(123, 91, 'Sari Agrotama Persada', '2059009278', '001'),
(124, 91, 'Sari Agrotama Persada', '2059009278', '003'),
(125, 92, 'Global Amines Indonesia', '8005905067', '003'),
(126, 93, 'Multimas Nabati Asahan', '2059006562', '007'),
(127, 93, 'Multimas Nabati Asahan', '2059006562', '012'),
(128, 94, 'PT Reliance Sekuritas Indonesia', '205.9001145', '1'),
(129, 95, 'PT Combiphar', '0359007215', '2, 7'),
(130, 96, 'PT Gistex Chewin Synthetic', '0359302705', '005'),
(131, 97, 'PT Gistex', '2059003385', '001'),
(132, 98, 'PT Olam Indonesia', '0359006600', '08'),
(133, 99, 'PT Powerindo Prima Perkasa', '2059005434', '1'),
(134, 100, 'PT Indomarco Adi Prima', '035-900-5841', '004'),
(135, 101, 'PT. NIRWANA LESTARI', '6430900313', '002'),
(136, 102, 'PT HRC Prima Sejahtera', '2059007372', '5'),
(137, 102, 'PT Hiba Logistik', '2059008034', '3'),
(138, 102, 'PT Asli Prima Inti Karya', '2059008867', '5'),
(139, 102, 'PT Hidup Baru Putra', '2059008905', '3'),
(140, 102, 'PT Hiba Prima Sejahtera', '2059008875', '5'),
(141, 102, 'PT Setia Negara', '2059008913', '3'),
(142, 102, 'PT Murni Anugrah Jaya Usaha', '2059008891', '3'),
(143, 102, 'PT Putri Jaya Sejahtera', '2059012422', '3'),
(144, 103, 'Wilmar Padi Indonesia', '2059013224', '005'),
(145, 104, 'Multimas Nabati Asahan', '2059006562', '007'),
(146, 104, 'Multimas Nabati Asahan', '2059006562', '012'),
(147, 104, 'Wilmar Padi Indonesia', '2059013224', '005'),
(148, 105, 'PT Trafoindo Prima Perkasa', '0129910285', '7'),
(149, 106, 'PT. INDOPOLY SWAKARSA INDUSTRY TBK', '0359301563', '016'),
(150, 107, 'PT. Kawan Lama Sejahtera', '006.901.1324 (BG KLS) ; 205.900.8361 (KMF Grup)', '003 (Max Rp 35M) ; 001 (KMF Grup)'),
(151, 107, 'PT. Krisbow Indonesia', '205.900.8379', '002 (Max Rp 25M)'),
(152, 107, 'PT. Sensor Indonesia', '205.900.8344', '002 (Max Rp 12M)'),
(153, 107, 'PT. Indo Kompresigma', '205.900.9987', '002 (Max Rp 10M)'),
(154, 107, 'PT. Kawan Lama Inovasi', '205.901.0071', '002 (Max Rp 2M)'),
(155, 107, 'PT. Emaro Online Indonesia', '205.900.9804', '001 (Max Rp 25M)'),
(156, 107, 'PT. Kalden Indonesia', '000.691.3053', '001 (Max Rp 3M, saat ini disetting sebesar Rp 2.961.665.000)'),
(157, 108, 'PT Duta Kreasi Bersama Realtindo', '0359005387', '2'),
(158, 108, 'PT Duta Kreasi Bersama Realtindo', '0359005387', '5'),
(159, 109, 'PT. Colorpak Indonesia ', '035-930-2641', '005'),
(160, 109, 'PT. Colorpak Flexible Indonesia', '205-907-1208', '003'),
(161, 110, 'PT. Oto Multiartha', '0359004364', '11'),
(162, 111, 'PT. Ecogreen Oleochemicals', '022-900-7892', '003'),
(163, 112, 'PT Intiroda Makmur', '2059007798', '4  '),
(164, 113, 'PT Caturadiluhur Sentosa', '2059001943', '4'),
(165, 114, 'PT Lotus Andalan Sekuritas', '2059004659', '001'),
(166, 115, 'PT. Nusantara Surya Sakti', '2059001617', '2'),
(167, 115, 'PT. Niaga Super Surya', '2059005744', '1'),
(168, 115, 'PT. Mekar Nusantara Teguh', '2059009740', '1'),
(169, 116, 'PT. TIRTA FRESINDO JAYA', '2059071828', '006'),
(170, 117, 'PT Datascrip', '002-900-0800', '004'),
(171, 118, 'PT Matahari Alka', '988-011-0915', '003'),
(172, 119, 'PT Matahari Alka Indonesia', '002-900-4295', '002'),
(173, 120, 'PT. Hindo', '205-901-3291', '003'),
(174, 121, 'CV Perjuangan Steel', '010-907-3603', '012'),
(175, 122, 'PT. GLOBAL DISTRIBUSI PUSAKA', '2059010225', '002'),
(176, 123, 'PT. PROMOLAND INDOWISATA', '2059011272', '001'),
(177, 124, 'PT Sinar Mas Agro Resources and Technology Tbk', '0359300800', '008'),
(178, 124, 'PT Soci Mas', '0359300800', '008'),
(179, 124, 'PT Sinarmas Bio Energy', '0359300800', '008'),
(180, 124, 'PT Rolimex Kimia Nusamas', '0359300800', '008'),
(181, 125, 'PT. Valbury Sekuritas Indonesia', '205-9003334', '1'),
(182, 126, 'PT SMART', '0359300800', '008'),
(183, 126, '', '', ''),
(184, 126, '', '', ''),
(185, 126, '', '', ''),
(186, 127, 'PT Jakarta Land', '2059006627', '4'),
(187, 128, 'PT Anugerah Indofood Barokah Makmur', '205-900-9847', '005, 007'),
(188, 129, 'PT. Kawan Lama Sejahtera', '006.901.1324 (BG KLS) ; 205.900.8361 (KMF Grup)', '003 (Max Rp 35M) ; 001 (KMF Grup)'),
(189, 129, 'PT. Krisbow Indonesia', '205.900.8379', '002 (Max Rp 25M)'),
(190, 129, 'PT. Sensor Indonesia', '205.900.8344', '002 (Max Rp 12M)'),
(191, 129, 'PT. Indo Kompresigma', '205.900.9987', '002 (Max Rp 10M)'),
(192, 129, 'PT. Kawan Lama Inovasi', '205.901.0071', '002 (Max Rp 2M)'),
(193, 129, 'PT. Emaro Online Indonesia', '205.900.9804', '001 (Max Rp 25M)'),
(194, 129, 'PT. Kalden Indonesia', '000.691.3053', '001 (Max Rp 3M, saat ini disetting sebesar Rp 2.961.665.000)'),
(195, 130, 'PT. Home Center Indonesia', '035.900.8815', '002 (BG P4BM) ; 006 (KMF terdiri dr BG & SBLC)'),
(196, 131, 'PT Pel Karya Bintang Timur', '205 900 5167', '005'),
(197, 132, 'PT. Chandra Asri Petrochemical', '035-930-3965', '005'),
(198, 133, 'PT Surya Rengo Containers', '0359007045', '004'),
(199, 134, 'PT. TEKPAK INDONESIA', '2059012716', '11'),
(200, 135, 'PT. TEKPAK INDONESIA', '2059012716', '11'),
(201, 136, 'PT Menjangan Sakti', '0359304058', '005'),
(202, 137, 'PT Istana Mobil Surabaya Indah', '205 900 6988', '005'),
(203, 138, 'PT Ispat Indo', '0359302969', '12'),
(204, 138, 'PT Ispat Panca Putera', '8290902852', '8'),
(205, 138, 'PT Ispat Bukit Baja', '8290902861', '9'),
(206, 139, 'PT. Dynaplast', '035.930.3221', '005'),
(207, 139, 'PT. Rapid Plast Indonesia', '035.900.5956', '001'),
(208, 139, 'PT. Sanpak Unggul', '683.090.0339', '004'),
(209, 140, 'PT. TRIAS TOYOBO ASTRIA', '2059011108', '10'),
(210, 141, 'PT. Ace Hardware Indonesia, Tbk', '205.900.1625', '002'),
(211, 142, 'PT. Kabulinco Jaya', '205.900.2222', '006'),
(212, 143, 'PT. Harvestar Flour Mills', '205.900.3423', '002'),
(213, 144, 'PT. Catur Sentosa Anugerah', '2059003369', '3, 7'),
(214, 145, 'PT. Catur Mitra Sejati Sentosa', '2059001633', '8'),
(215, 146, 'PT. Catur Sentosa Adiprana, Tbk', '0359096137', '11, 17'),
(216, 147, 'PT Duta Putera Sumatera', '205 900 5388', '4'),
(217, 148, 'PT Imora Motor', '2059000335', '1'),
(218, 149, 'PT. TRIAS SENTOSA Tbk', '0359006189', '005'),
(219, 150, 'PT. Asuransi Sinar Mas', '2059000076', '2'),
(220, 150, 'PT. Sinarmas Penjaminan Kredit', '2059012210', '1'),
(221, 151, 'PT Rolimex Kimia Nusamas', '205-901-337-2', '006'),
(222, 152, 'PT Finusolprima Farma Internasional', '2059004462', '003'),
(223, 153, 'PT Bernofarm', '2059070996', '2'),
(224, 154, 'PT. DUNIA KIMIA UTAMA', '2059005442', '003'),
(225, 155, 'PT. INDONESIAN ACIDS INDUSTRY', '0359093545', '004'),
(226, 156, 'PT. MAHKOTA INDONESIA', '0359006421', '001'),
(227, 157, 'PT Arista Jaya Lestari', '2059008191', '3'),
(228, 158, 'PT. LIKU TELAGA', '2059010659', '008'),
(229, 159, 'PT. PKG LAUTAN INDONESIA', '2059000084', '002'),
(230, 160, 'PT. Prokemas Adhikari Kreasi', '2059007054', '003'),
(231, 161, 'PT. BCA Sekuritas', '2059004021', '001'),
(232, 162, 'PT. Plasindo Lestari', '035-900-6448', '016'),
(233, 163, 'PT Dexa Medica', '6800903546', '006'),
(234, 164, 'PT Djembatan Dua', '2059009219', '001'),
(235, 165, 'PT Charoen Pokphand Indonesia Tbk', '0359006294', '5'),
(236, 165, 'PT Charoen Pokphand Jaya Farm', '0359006286', '3'),
(237, 166, 'PT. Aerotrans Service Indonesia', '2059006538', '003'),
(238, 167, 'PT Surya Darma Perkasa', '035 900 5531', '12'),
(239, 168, 'PT. ARTA BATRINDO', '1689001678', '007'),
(240, 169, 'PT. BARIA BULK TERMINAL', '1689013480', '11'),
(241, 170, 'PT Ethica Industri Pharmasi ', '2059000360', '6'),
(242, 171, 'PT Tri Sapta Jaya', '2059002141', '2'),
(243, 172, 'PT. Utama Alam Energi', '2059007593 ', '3'),
(244, 173, 'PT. Gunung Madu Plantations', '1179001649', '5'),
(245, 174, 'PT. Utama Alam Energi', '2059007593 ', '3'),
(246, 175, 'PT. MITRA ADIPERKASA Tbk', '2059000238', '004'),
(247, 176, 'PT. MAP AKTIF ADIPERKASA Tbk', '2059006015', '007'),
(248, 177, 'PT Enseval Putera Megatrading Tbk', '0359008548', '2'),
(249, 178, 'PT. Malindo Feedmill', '2059002745', '02; 06'),
(250, 179, 'Grup Malindo', 'terlampir', 'terlampir'),
(251, 180, 'Grup Ciliandra', 'terlampir', 'terlampir'),
(252, 181, 'PT. Bukitmega Masabadi', '035-930-2381', '006'),
(253, 182, 'PT. Bumimulia Indah Lestari', '035-930-1644', '012 '),
(254, 183, 'PT Global Indonesia Asia Sejahtera', '9880222870', '13'),
(255, 184, 'Sinochem Grup', '205-900-840-9', '004'),
(256, 185, 'PT. NIRWANA LESTARI', '6430900313', '002'),
(257, 186, 'Sinochem Grup', '205-900-840-9', '004'),
(258, 187, 'Wilmar Grup', '2059006791', '001'),
(259, 187, 'Wilmar Grup', '2059006791', '002'),
(260, 187, 'Sinar Alam Permai', '0359302888', '002'),
(261, 187, 'Sinar Alam Permai', '0359302888', '010'),
(262, 187, 'Multi Nabati Sulawesi', '2059070562', '002'),
(263, 187, 'Multi Nabati Sulawesi', '2059070562', '008'),
(264, 187, 'Duta Sugar International', '2059002788', '001'),
(265, 187, 'Duta Sugar International', '2059002788', '007'),
(266, 187, 'Petro Andalan Nusantara', '2059006554', '003'),
(267, 187, 'Petro Andalan Nusantara', '2059006554', '006'),
(268, 187, 'Wilmar Bioenergi Indonesia', '2059072506', '002'),
(269, 187, 'Wilmar Bioenergi Indonesia', '2059072506', '011'),
(270, 187, 'Sari Agrotama Persada', '2059009278', '001'),
(271, 187, 'Sari Agrotama Persada', '2059009278', '003'),
(272, 188, 'Multimas Nabati Asahan', '2059006562', '007'),
(273, 188, 'Multimas Nabati Asahan', '2059006562', '012'),
(274, 188, 'Wilmar Padi Indonesia', '2059013224', '005'),
(275, 189, 'Global Amines Indonesia', '8005905067', '003'),
(276, 190, 'PT Indoguna Utama', '2059009057', '003'),
(277, 191, 'PT Primus Sanus Cooking Oil Industrial (PRISCOLIN)', '2059001030', '016 (BG Induk IDR)'),
(278, 192, 'PT Primus Sanus Cooking Oil Industrial (PRISCOLIN)', '2059001030', '016 (BG Induk IDR)'),
(279, 193, 'Multimas Nabati Asahan', '2059006562', '021'),
(280, 194, 'PT Bumen Redja Abadi', '0849096666', '002'),
(281, 195, 'PT. Tamaris Hidro (TH) - KMS', '205-900-9375', '02'),
(282, 195, 'PT. Partogi Hidro Energi (PHE)', '205-900-9332', '01 & 02'),
(283, 195, 'PT. Lampung Hydroenergy (LHE)', '205-900-8930', '03'),
(284, 195, 'PT. Senagan Energi (SNE)', '205-900-8646', '014'),
(285, 196, 'PT. Tatamulia Nusantara Indah', '3429022798', '003 dan 005'),
(286, 197, 'PT. TRIAS SENTOSA Tbk', '0359006189', '005'),
(287, 198, 'PT Data Citra Mandiri', '2059071925 ', '1'),
(288, 198, 'PT Erafone Artha Retailindo', '2059004501 ', '2'),
(289, 198, 'PT Erajaya Swasebada Tbk ', '2059071933 ', '6'),
(290, 198, 'PT Sinar Eka Selaras', '2059071941 ', '4'),
(291, 198, 'PT Teletama Artha Mandiri', '2059005566 ', '3'),
(292, 198, 'PT Nusa Gemilang Abadi', '2059005671 ', '3'),
(293, 198, 'PT Nusa Abadi Sukses Artha', '2059008263 ', '2'),
(294, 198, 'PT Surya Andra Medicalindo ', '2059009723 ', '3'),
(295, 198, 'PT Urogen Advanced Solutions ', '2059009715 ', '5'),
(296, 199, 'PT Global Chemindo Megatrading', '2059001579', '1'),
(297, 200, 'PT. NIRWANA LESTARI', '6430900313', '002'),
(298, 201, 'PT Enseval Medika Prima', '2059001561', '1'),
(299, 202, 'PT. Hindo', '205-901-3291', '003'),
(300, 202, 'PT. FAR Utama Indonesia', '205-901-3461', '001'),
(301, 202, 'PT. Makan Makan International', '205-901-3585', '001'),
(302, 203, 'PT SWAKARSA SINARSENTOSA', '0359006570', '18'),
(303, 203, 'PT DHARMA AGROTAMA NUSANTARA', '2059000157', '16'),
(304, 203, 'PT DHARMA INTISAWIT LESATARI', '2059003831', '25'),
(305, 203, 'PT MITRA NUSA SARANA', '2059009006', '09'),
(306, 203, 'PT PRIMA SAWIT ANDALAN', '2059004985', '19'),
(307, 203, 'PT DHARMA INTISAWIT NUGRAHA', '2059000181', '17'),
(308, 203, 'PT DEWATA SAWIT NUSANTARA', '2059000173', '31'),
(309, 203, 'PT DHARMA PERSADA SEJAHTERA', '2059004977', '20'),
(310, 203, 'PT AGRO ANDALAN', '2059005795', '19'),
(311, 203, 'PT KENCANA ALAM PERMAI', '2059001544', '28'),
(312, 203, 'PT PILAR WANAPERSADA', '2059000165', '35'),
(313, 203, 'PT PUTRA UTAMA LESTARI', '2059005001', '16'),
(314, 203, 'PT BIMA AGRI SAWIT', '2059009782', '08'),
(315, 203, 'PT BIMA PALMA NUGRAHA', '2059009791', '08'),
(316, 203, 'PT KARYA PRIMA AGRO SEJAHTERA', '2059003547', '25'),
(317, 203, 'PT GEMILANG UTAMA NUSANTARA', '2059005426', '11'),
(318, 204, 'PT. Milko Beverage Industry', '736.090.0201', '013'),
(319, 205, 'PT. BNI Sekuritas', '2059005779', '001'),
(320, 206, 'PT. MAYORA INDAH Tbk', '2059070945', '004'),
(321, 207, 'PT. TEKPAK INDONESIA', '2059012716', '11'),
(322, 208, 'PT Charoen Pokphand Indonesia', '0359006294', '5'),
(323, 208, 'PT Charoen Pokphand Jaya Farm', '0359006286', '3'),
(324, 209, 'PT Lotus Andalan Sekuritas', '2059004659', '001'),
(325, 210, 'PT Indo Premier Sekuritas', '2059013607', '003'),
(326, 210, 'PT Indo Premier Sekuritas', '2059013607', '004'),
(327, 211, 'PT Matahari Alka', '988-011-0915', '003'),
(328, 212, 'PT Matahari Alka Indonesia', '002-900-4295', '002'),
(329, 213, 'PT Datascrip', '002-900-0800', '004'),
(330, 214, 'PT. Indah Jaya Textile Industry', '035-930-2390', '01 (sublimit USD); 039 (sublimit IDR)'),
(331, 215, 'PT. Total Persada Indonesia', '2059009693', '001'),
(332, 216, 'PT Cahaya Cemerlang Chemindo', '084 939 7640', '7'),
(333, 217, 'PT Inti Everspring Indonesia', '205-901-1531', '006'),
(334, 218, 'PT Kobexindo Tractors', '206.909.2424 ', '012'),
(335, 218, 'PT Kobexindo Equipment', '206.923.7881 ', '002'),
(336, 218, 'PT Kobexindo Persada Sejahtera', '988.057.9018 ', '003'),
(337, 218, 'PT Kobexindo Forkift', '206.913.6286 ', '003'),
(338, 218, 'PT Eurotruk Transindo', '206.982.3208 ', '009'),
(339, 219, 'PT Indolakto', '205-907-0899', '002'),
(340, 220, 'PT Kimia Farma Tbk', '0359005751', '002'),
(341, 221, 'PT Temas Tbk.', '205.901.0772', '008'),
(342, 221, 'PT Temas Shipping', '205.901.1736', '002'),
(343, 221, 'PT Temas Depot', '205.901.1728', '002'),
(344, 221, 'PT Temas Port', '205.901.0781', '002'),
(345, 222, 'PT. Sekawan Kontrindo', '2059002800', '005'),
(346, 223, 'PT. AKR Corporindo, Tbk', '035-930-3141', '005'),
(347, 224, 'PT Indofood CBP Sukses Makmur, Tbk.', '205-900-0874', '001 (USD), 002 (IDR)'),
(348, 225, 'PT. DUNIA KIMIA JAYA', '0359301814', '003'),
(349, 226, 'PT. Intisumber Bajasakti', '2059008387', '4'),
(350, 227, 'PT Asri Pancawarna', '0359093936', '17 + 41'),
(351, 227, 'PT Asri Pancawarna', '0359093936', '22 + 26'),
(352, 228, 'PT Indoguna Utama', '2059009057', '003'),
(353, 229, 'PT Mulia Intanlestari', '2059001510', '2'),
(354, 230, 'PT Data Citra Mandiri', '2059071925 ', '1'),
(355, 230, 'PT Erafone Artha Retailindo', '2059004501 ', '2'),
(356, 230, 'PT Erajaya Swasebada Tbk ', '2059071933 ', '6'),
(357, 230, 'PT Sinar Eka Selaras', '2059071941 ', '4'),
(358, 230, 'PT Teletama Artha Mandiri', '2059005566 ', '3'),
(359, 230, 'PT Nusa Gemilang Abadi', '2059005671 ', '3'),
(360, 230, 'PT Nusa Abadi Sukses Artha', '2059008263 ', '2'),
(361, 230, 'PT Surya Andra Medicalindo ', '2059009723 ', '3'),
(362, 230, 'PT Urogen Advanced Solutions ', '2059009715 ', '5'),
(363, 231, 'PT SINAR GALAXY', '0889001765', '1'),
(364, 232, 'PT Excel Metal Industry', '0359093227', '5'),
(365, 233, 'PT Unggul Indah Cahaya Tbk ', '035-930-3728', '002'),
(366, 234, 'PT Nippon Indosari Corpindo, Tbk.', '205-907-0821', '002'),
(367, 235, 'CV Karya Hidup Sentosa', '0379132725', '156'),
(368, 236, 'PT Srikandi Multi Rental', '0359006961', '4 dan 8'),
(369, 237, 'PT Steel Pipe Industry of Indonesia Tbk ', '205-907-146-1', '003'),
(370, 237, 'PT Steel Pipe Industry of Indonesia Tbk ', '205-900-232-0 ', '011'),
(371, 237, 'PT Steel Pipe Industry of Indonesia Tbk ', '010-907-287-9 ', '001'),
(372, 238, 'PT Meratus Line', '2059001935', '10'),
(373, 239, 'PT. MAP BOGA ADIPERKASA Tbk', '2059011931', '004'),
(374, 240, 'PT. Reliance Sekuritas Indonesia', '205.9001145', '1'),
(375, 241, 'a', '', ''),
(376, 241, 'b', '', ''),
(377, 242, 'PT Inter World Steel Mills Indonesia', '0359007762', '8'),
(378, 243, 'PT Inter World Steel Mills Indonesia', '0359007762', '8'),
(379, 244, 'PT Kobexindo Tractors Tbk', '206 909 242', '012'),
(380, 244, 'PT Kobexindo Konstruksi Indonesia', '206 913 6286', '003'),
(381, 244, 'PT Kobexindo Perkasa Sejahtera', '988 057 9018', '003'),
(382, 244, 'PT kobexindo Equipment', '206 923 7881', '002'),
(383, 244, 'PT Eurotruk Transindo', '206 982 3208', '009'),
(384, 245, 'PT. Akino Wahanamulia', '530-091-0302', '005'),
(385, 246, 'PT Fajar Surya Wisesa Tbk', '205.900.7992', '006'),
(386, 246, 'PT Dayasa Aria Prima', '205.900.9359', '005'),
(387, 247, 'PT. Cibadak Indah Sari Farm', '205-900-6171', '7 (Induk)'),
(388, 248, 'PT Tifico Fiber Indonesia, Tbk', '205.907.0571', '010'),
(389, 249, 'PT. Lautan Luas', '205-907-1526', '006'),
(390, 250, 'PT Growth Asia', '2059002206', '026'),
(391, 251, 'PT Indomarco Adi Prima', '035-900-5841', '004'),
(392, 252, 'PT. Cibadak Indah Sari Farm', '205-900-6171', '7 (Induk)'),
(393, 253, 'PT. Cakrawal Mega Indah', '0359096633', 'KMF(004), BG (005)'),
(394, 254, 'PT. Vaksindo Satwa Nusantara ', '2059002478', '1'),
(395, 255, 'PT. Opal Coffee Indonesia', '2059119294', 'KMF (kom 2) ; BG (kom 3)'),
(396, 256, 'PT Ferron Par Pharmaceuticals', '0359004275', '002'),
(397, 257, 'PT Ferron Par Pharmaceuticals', '0359004275', '002'),
(398, 258, 'PT Lotus Andalan Sekuritas', '2059004659', '001'),
(399, 259, 'PT Indokuat Sukses Makmur', '205-901-0756', '001'),
(400, 260, 'Grup Ciliandra', 'terlampir', 'terlampir'),
(401, 261, 'PT Wahana Mas Mulia', '084 9067 127', '7'),
(402, 262, 'PT Cahaya Cemerlang Chemindo', '084 939 7640', '7'),
(403, 263, 'PT. Trimegah Sekuritas Indonesia', '035-9008645', '2'),
(404, 264, 'PT. Indonesia Libolon Fiber System', '035-930-1938', '010'),
(405, 265, 'PT. PROMOLAND INDOWISATA', '2059011272', '001'),
(406, 266, 'PT. Molindo Raya Industrial', '011-901-6527', '003'),
(407, 267, 'PT. GLOBAL TIKET NETWORK', '2059005272', '10'),
(408, 268, 'PT. Total Bangun Persada Tbk', '0849069120', '003'),
(409, 269, 'PT. CS2 POLA SEHAT', '2059006252', '005'),
(410, 270, 'PT. BCA Sekuritas', '2059004021', '001'),
(411, 271, 'PT Indofood Fortuna Makmur', '205-900-1587 (BG), 205-907-0848 (BG-KMF)', '002 (BG), 003 (BG-KMF)'),
(412, 272, 'PT TIGA MUSIM MAS JAYA', '2059002591 ; 2059071658', '002, 005 ; 009, 018'),
(413, 272, 'PT NANA YAMANO TECHNIK', '2059071666', '004, 017, 020, 022'),
(414, 272, 'PT SARANA GASTEKINDO UTAMA', '2059010900', '002, 006, 009, 012'),
(415, 272, 'PT MEGA POWERINDO UTAMA', '2059010896', '001, 004, 007, 010'),
(416, 273, 'PT Arwana Anugerah Keramik', '205-900-324-5', '009'),
(417, 273, 'PT Arwana Anugerah Keramik', '205-900-324-5', '002'),
(418, 274, 'PT Sinar Karya Duta Abadi', '205-900-189-7', '006'),
(419, 274, 'PT Sinar Karya Duta Abadi', '205-907-121-6', '001'),
(420, 274, 'PT Sinar Karya Duta Abadi', '205-900-189-7', '001'),
(421, 275, 'PT TIGA MUSIM MAS JAYA', '2059002591 ; 2059071658', '002, 005 ; 009, 018'),
(422, 275, 'PT NANA YAMANO TECHNIK', '2059071666', '004, 017, 020, 022'),
(423, 275, 'PT SARANA GASTEKINDO UTAMA', '2059010900', '002, 006, 009, 012'),
(424, 275, 'PT MEGA POWERINDO UTAMA', '2059010896', '001, 004, 007, 010'),
(425, 276, 'PT TIGA MUSIM MAS JAYA', '2059002591 ; 2059071658', '002, 005 ; 009, 018'),
(426, 276, 'PT NANA YAMANO TECHNIK', '2059071666', '004, 017, 020, 022'),
(427, 276, 'PT SARANA GASTEKINDO UTAMA', '2059010900', '002, 006, 009, 012'),
(428, 276, 'PT MEGA POWERINDO UTAMA', '2059010896', '001, 004, 007, 010'),
(429, 277, 'PT TIGA MUSIM MAS JAYA', '2059002591 ; 2059071658', '002, 005 ; 009, 018'),
(430, 277, 'PT NANA YAMANO TECHNIK', '2059071666', '004, 017, 020, 022'),
(431, 277, 'PT SARANA GASTEKINDO UTAMA', '2059010900', '002, 006, 009, 012'),
(432, 277, 'PT MEGA POWERINDO UTAMA', '2059010896', '001, 004, 007, 010'),
(433, 278, 'PT TIGA MUSIM MAS JAYA', '2059002591 ; 2059071658', '002, 005 ; 009, 018'),
(434, 278, 'PT NANA YAMANO TECHNIK', '2059071666', '004, 017, 020, 022'),
(435, 278, 'PT SARANA GASTEKINDO UTAMA', '2059010900', '002, 006, 009, 012'),
(436, 278, 'PT MEGA POWERINDO UTAMA', '2059010896', '001, 004, 007, 010'),
(437, 279, 'PT. Mandiri Sekuritas', '2059004080', '1'),
(438, 280, 'PT. Marga Metro Nusantara', '2059013925', '001'),
(439, 281, 'PT. Harvestar Flour Mills', '205.900.3423', '002'),
(440, 282, 'PT. Agristar Grain Indonesia', '205.900.7305', '010'),
(441, 283, 'PT Tirta Sukses Perkasa', '205-900-7038', '003'),
(442, 284, 'PT Lotus Indah Textile Industries ', '205-901-2252', '007'),
(443, 285, 'PT Summarecon Agung, Tbk', '035-900-513-1', '004'),
(444, 285, 'PT Lestari Mahadibya', '035-900-808-4', '004'),
(445, 285, 'PT Makmur Orient Jaya', '205-900-490-0', '002'),
(446, 286, 'TRIMITRA CIKARANG', '4779000700', '016'),
(447, 287, 'GUDANG GARAM TBK', '0359006553', '003'),
(448, 288, 'PT Adi Sarana Armada Tbk', '205 900 1978', '14'),
(449, 289, 'buyung', '2055143515', '001'),
(450, 289, 'buyung', '1321325151', '005'),
(451, 289, 'buyung', '0212131351', '003'),
(452, 290, 'PT Global Tiket Network', '2059005272', '10'),
(453, 291, 'PT Salim Ivomas Pratama, Tbk', '035-909-4126', '004'),
(454, 292, 'PT. Indominco Mandiri (IMM)', '2059071020', '002'),
(455, 292, 'PT. Kitadin (KTD)', '2059071046', '004'),
(456, 292, 'PT. Jorong Barutama Greston (JBG)', '2059071038', '002'),
(457, 292, 'PT. Bharinto Ekatama (BEK)', '2059072361', '006'),
(458, 292, 'PT. Trubaindo Coal MIning (TCM)', '2059071321', '012'),
(459, 293, 'PT Adikencana Mahkotabuana', '205-900-7399', '009'),
(460, 294, 'PT SWAKARSA SINARSENTOSA', '0359006570', '18'),
(461, 294, 'PT DHARMA AGROTAMA NUSANTARA', '2059000157', '16'),
(462, 294, 'PT DHARMA INTISAWIT LESTARI', '2059003831', '25'),
(463, 294, 'PT MITRA NUSA SARANA', '2059009006', '09'),
(464, 294, 'PT PRIMA SAWIT ANDALAN', '2059004985', '19'),
(465, 294, 'PT DHARMA INTISAWIT NUGRAHA', '2059000181', '17'),
(466, 294, 'PT DEWATA SAWIT NUSANTARA', '2059000173', '31'),
(467, 294, 'PT DHARMA PERSADA SEJAHTERA', '2059004977', '20'),
(468, 294, 'PT AGRO ANDALAN', '2059005795', '19'),
(469, 294, 'PT KENCANA ALAM PERMAI', '2059001544', '28'),
(470, 294, 'PT PILAR WANAPERSADA', '2059000165', '35'),
(471, 294, 'PT PUTRA UTAMA LESTARI', '2059005001', '16'),
(472, 294, 'PT BIMA AGRI SAWIT', '2059009782', '08'),
(473, 294, 'PT BIMA PALMA NUGRAHA', '2059009791', '08'),
(474, 294, 'PT KARYA PRIMA AGRO SEJAHTERA', '2059003547', '25'),
(475, 294, 'PT GEMILANG UTAMA NUSANTARA', '2059005426', '11'),
(476, 295, 'PT TANJUNG KREASI PARQUET INDUSTRY', '2059071551', '05'),
(477, 296, 'PT DHARMA SATYA NUSANTARA TBK', '2059000858', '28'),
(478, 297, 'PT. ULTRA PRIMA ABADI', '0359006057', '009'),
(479, 298, 'PT SWAKARSA SINARSENTOSA', '0359006570', '18'),
(480, 298, 'PT DHARMA AGROTAMA NUSANTARA', '2059000157', '16'),
(481, 298, 'PT DHARMA INTISAWIT LESTARI', '2059003831', '25'),
(482, 298, 'PT MITRA NUSA SARANA', '2059009006', '09'),
(483, 298, 'PT PRIMA SAWIT ANDALAN', '2059004985', '19'),
(484, 298, 'PT DHARMA INTISAWIT NUGRAHA', '2059000181', '17'),
(485, 298, 'PT DEWATA SAWIT NUSANTARA', '2059000173', '31'),
(486, 298, 'PT DHARMA PERSADA SEJAHTERA', '2059004977', '20'),
(487, 298, 'PT AGRO ANDALAN', '2059005795', '19'),
(488, 298, 'PT KENCANA ALAM PERMAI', '2059001544', '28'),
(489, 298, 'PT PILAR WANAPERSADA', '2059000165', '35'),
(490, 298, 'PT PUTRA UTAMA LESTARI', '2059005001', '16'),
(491, 298, 'PT BIMA AGRI SAWIT', '2059009782', '08'),
(492, 298, 'PT BIMA PALMA NUGRAHA', '2059009791', '08'),
(493, 298, 'PT KARYA PRIMA AGRO SEJAHTERA', '2059003547', '25'),
(494, 298, 'PT GEMILANG UTAMA NUSANTARA', '2059005426', '11'),
(495, 299, 'PT DHARMA SATYA NUSANTARA TBK', '2059000858', '28'),
(496, 300, 'PT. DATASCRIP', '0029000800', '004'),
(497, 301, 'PT. Plastrade World', '407-900-0920', '006'),
(498, 302, 'PT Tatamulia Nusantara Indah', '3429022798', '003 dan 005'),
(499, 303, 'PT Global Tiket Network', '2059005272', '010'),
(500, 304, 'PT Nikko Sekuritas Indonesia', '2059002958', '1'),
(501, 305, 'GLOBAL DISTRIBUSI PUSAKA', '2059010225', '002'),
(502, 306, 'PT Indoprima Gemilang', '342 957 4995', '3'),
(503, 307, 'PT Agro Jaya Perdana', '0359008424', '05,06,07'),
(504, 308, 'PT. Agro Jaya Perdana ', '035-900-8424   ', '05, 06, 07 (KMF : 08)'),
(505, 309, 'PT. CHANDRA ASRI PETROCHEMICAL', '0359303965', '005'),
(506, 310, 'PT. Chandra Asri Petrochemical', '035-930-3965', '005'),
(507, 311, 'PT Pacinesia Chemical Industry', '035-900-7738', '004'),
(508, 312, 'PT. Cisadane Raya Chemicals ', '2059014239', '1'),
(509, 313, 'PT. KB Valbury Sekuritas Indonesia', '205-9003334', '1'),
(510, 314, 'PT Rintis Sejahtera', '035-930-2314', ' 002 beserta sub limitnya'),
(511, 315, 'PT Verdhana Sekuritas Indonesia', '2059014204', '002'),
(512, 316, 'PT. Samuel Sekuritas Indonesia', '205.9004870', '1'),
(513, 317, '', '', ''),
(514, 318, 'PT Pancaran Darat Transport', '2059011191', '006,007'),
(515, 319, 'PT Pancaran Samudera Transport', '2059011205', '002'),
(516, 320, 'PT Tirta Kuning Ayu Sukses', '205-901-4093', '002'),
(517, 321, 'PT Morula Indonesia', '4559303035', '006'),
(518, 322, 'AM/NS Indonesia', '0359302845', '006'),
(519, 323, 'PT Pancaran Darat Transport', '2059011191', '006, 007'),
(520, 324, 'PT Pancaran Samudera Transport', '2059011205', '002'),
(521, 325, 'PT. GUDANG GARAM Tbk', '0359006553', '003'),
(522, 326, 'PT. INDOPOLY SWAKARSA INDUSTRY Tbk.,', '0359301563', '016'),
(523, 327, 'PT Altrak 1978', '0359303434', '005;013'),
(524, 328, 'PT Salim Ivomas Pratama, Tbk', '035-909-4126', '004'),
(525, 329, '', '', ''),
(526, 330, 'PT. Primus Sanus Cooking Oil Industrial', '2059001030', '16'),
(527, 331, 'PT. PETRO OXO NUSANTARA', '2059070881', '004'),
(528, 332, 'PT. Primus Sanus Cooking Oil Industrial (Priscolin)', '205-900-1030', '016 (BG Induk - IDR) '),
(529, 333, 'PT Multi Garmenjaya', '035-900-5727', '002'),
(530, 334, 'fgdhgd', '121332', '34'),
(531, 335, 'PT Multi Garmenjaya', '035-900-5727', '002'),
(532, 336, 'PT Modern Widya Tehnical', '2309878994', '8'),
(533, 336, 'PT Modern Widya Tehnical', '2309878994', '18'),
(534, 336, 'PT Modern Widya Tehnical', '2309878994', '21'),
(535, 337, 'DUNIA KIMIA UTAMA', '2059005442', '003'),
(536, 338, 'LIKU TELAGA', '2059010659', '008'),
(537, 339, 'PT. Aneka Tambang, Tbk', '2059072191', '004'),
(538, 340, 'PT Andini Sarana', '2059005884', '003'),
(539, 341, 'PT Menjangan Sakti', '0359304058 ', '005'),
(540, 342, 'PT Multi Garmenjaya', '', '002'),
(541, 343, 'PT Multi Garmenjaya', '035-900-5727', '002'),
(542, 344, 'PT Multi Garmenjaya', '035-900-5727', '002'),
(543, 345, 'PT Muliaglass', '2059071488', '30 dan39'),
(544, 346, 'PT Nusantara Moto International', '2059007364', '3'),
(545, 347, 'PT. Colorpak Indonesia', '035-930-2641', '005'),
(546, 347, 'PT Colorpak Flexible Indonesia', '205-907-1208', '003'),
(547, 348, 'PT United Mobil International', '2059003971', '7'),
(548, 349, 'PT Indofood CBP Sukses Makmur, Tbk.', '205-900-0874', '001 (USD), 002 (IDR)'),
(549, 350, 'PT Duta Kreasi Bersama Realtindo', '0359005387', '2'),
(550, 350, 'PT Duta Kreasi Bersama Reraltindo', '0359005387', '5'),
(551, 351, 'PT. GLOBAL DIGITAL NIAGA', '2059011094', '001'),
(552, 352, 'PROMOLAND INDOWISATA', '2059011272', '001'),
(553, 353, 'PT Indomulti Jaya Steel', '205-900-080-7', '004'),
(554, 354, 'PT Modern Widya Tehnical', '2309878994', '8'),
(555, 354, 'PT Modern Widya Tehnical', '2309878994', '18'),
(556, 354, 'PT Modern Widya Tehnical', '2309878994', '21'),
(557, 355, 'PT Wisisco Baja Putra', '2059006503', '10'),
(558, 356, 'PT. Japfa Comfeed Indonesia Tbk. dan PT Suri Tani Pemuka', '205-900-8336', '002 (KMF) '),
(559, 357, 'tes tes', 'tes', 'tes'),
(560, 358, 'PT Ramarayo Perdana', '2059012856', '7'),
(561, 359, 'PT XL Axiata Tbk', '0359008386', '4'),
(562, 360, 'PT Olam Indonesia', '0359006600', '8'),
(563, 361, 'PT Surya Rengo Containers', '035-900-7045', '004'),
(564, 362, 'PT Agro Jaya Perdana', '0359008424', '05, 06, 07 (KMF:08)'),
(565, 363, 'PT Bangunreksa Perkasa', '2059005531', '1'),
(566, 364, 'PT Caturadiluhur Sentosa', '2059001943', '4'),
(567, 365, 'PT Muliaglass', '2059071488', '30 dan39'),
(568, 366, 'fgdhgd', '121332', '34'),
(569, 367, 'PT Agung Sukses Selalu', '205-001-0002', '001'),
(570, 368, 'PT. Dunia Kimia Jaya', '035-930-1814', '003 (BGR)'),
(571, 369, 'PT. MATAHARI ALKA', '9880110915', '003'),
(572, 369, 'PT. MATAHARI ALKA INDONESIA', '0029004295', '002'),
(573, 370, 'PT Pewira Adhitama Sejati', '2059004535', '18'),
(574, 371, 'PT. Asuransi Sinar Mas', '2059000076 ', '2'),
(575, 371, 'PT. Sinarmas Penjaminan Kredit', '2059012210 ', '1'),
(576, 372, 'PT. Trafoindo Prima Perkasa', '0129910285', '7'),
(577, 373, 'PT Powerindo Prima Perkasa', '2059005434', '2'),
(578, 374, 'PT. Bernofarm', '2059070996 ', '2'),
(579, 375, 'PT. Bernofarm', '2059070996 ', '2'),
(580, 376, 'SINOCHEM GRUP ', '205-900-840-9', '4'),
(581, 377, 'PT. AKR Corporindo, Tbk', '035.930.3141', '005'),
(582, 378, 'PT. Bernofarm', '2059070996 ', '2'),
(583, 379, 'PT. Oto Multiartha', '0359004364', '11'),
(584, 380, 'Multimas Nabati Asahan', '2059006562', '021'),
(585, 381, 'PT. Panca Budi Niaga', '205.907.1984', '001'),
(586, 382, 'PT. Polytech Indo Hausen ', '205.907.1674', '004'),
(587, 383, 'PT. Panca Budi Idaman, Tbk', '035.930.4261 ', '004'),
(588, 384, 'PT. Panca Budi Pratama ', '035.930.3507', '013'),
(589, 385, 'PT Indo-Rama Synthetics, Tbk', '035-307-0841', '023'),
(590, 386, 'PT TIGA MUSIM MAS JAYA', '2059002591 ; 2059071658', '004, 017, 020, 022'),
(591, 386, 'PT NANA YAMANO TECHNIK', '2059071666', '002, 006, 009, 012'),
(592, 386, 'PT SARANA GASTEKINDO UTAMA', '2059010900', '001, 004, 007, 010'),
(593, 386, 'PT MEGA POWERINDO UTAMA', '2059010896', ''),
(594, 386, 'PT LINELL ALTURA ASIA', '2059014387', ''),
(595, 387, 'PT TIGA MUSIM MAS JAYA', '2059002591 ; 2059071658', '002, 005 ; 009, 018'),
(596, 387, 'PT NANA YAMANO TECHNIK', '2059071666', '004, 017, 020, 022'),
(597, 387, 'PT SARANA GASTEKINDO UTAMA', '2059010900', '002, 006, 009, 012'),
(598, 387, 'PT MEGA POWERINDO UTAMA', '2059010896', '001, 004, 007, 010'),
(599, 387, 'PT LINELL ALTURA ASIA', '2059014387', '002'),
(600, 388, 'PT Anugerah Argon Medica', '035 909 4738', '005'),
(601, 389, 'PT Djembatan Dua', '2059009219', '001'),
(602, 390, 'PT Ferron Par Pharmaceuticals', '035.900.4275', '002'),
(603, 391, 'PT Dexa Medica', '6800903546', '008'),
(604, 392, 'PT. Ecogreen Oleochemicals', '022-900-7892', '003'),
(605, 393, 'PT Caturadiluhur Sentosa', '2059001943', '4'),
(606, 394, 'PT. Dynaplast', '035.930.3221 ', '005'),
(607, 394, 'PT. Rapid Plast Indonesia', '035.900.5956 ', '001'),
(608, 394, 'PT. Sanpak Unggul ', '683.090.0339', '004'),
(609, 395, 'PT Ferron Par Pharmaceuticals', '035.900.4275', '002'),
(610, 396, 'PT XL Axiata Tbk', '0359008386', '4'),
(611, 397, 'PT. Bumimulia Indah Lestari', '035-930-1644', '009; 012'),
(612, 398, 'PT. Tirta Fresindo Jaya', '205-907-1828', '006'),
(613, 399, 'PT Sauhbahtera Ciawi Sukses ', '205-901-4352', '002'),
(614, 400, 'PT Agung Solusi Trans', '2059005736', '008'),
(615, 401, 'PT Finusolprima Farma Internasional', '205 900 4462', '003'),
(616, 402, 'PT Finusolprima Farma Internasional', '2059014204', ''),
(617, 403, 'PT. Kawan Lama Sejahtera', '006.901.1324 (BG KLS) ; 205.900.8361 (KMF Grup) ', '003 (Max Rp 35M) ; 001 (KMF Grup)'),
(618, 403, 'PT. Krisbow Indonesia ', '205.900.8379 ', '002 (Max Rp 25M)'),
(619, 403, 'PT. Sensor Indonesia', '205.900.8344', '002 (Max Rp 12M)'),
(620, 403, 'PT. Indo Kompresigma', '205.900.9987', '002 (Max Rp 10M)'),
(621, 403, 'PT. Kawan Lama Inovasi', '205.901.0071', '002 (Max Rp 2M)'),
(622, 403, 'PT. Emaro Online Indonesia', '205.900.9804', '001 (Max Rp 25M)'),
(623, 403, 'PT. Kalden Indonesia', '000.691.3053', ' 001 (Max Rp 3M)'),
(624, 404, 'PT. Ace Hardware Indonesia, Tbk ', '205.900.1625', '002'),
(625, 405, 'PT. Pertamina (Persero)', '0359302501', '006'),
(626, 405, 'PT. Kilang Pertamina Internasional', '2059014042', '003'),
(627, 405, 'PT. Pertamina Patra Niaga', '2059014034', '003'),
(628, 406, 'PT Intisumber Bajasakti', '2059008387', ''),
(629, 407, 'PT The Master Steel Manufactory', '0359093642', '4'),
(630, 407, 'PT The Master Steel Manufactory', '0359093642', '13'),
(631, 407, 'PT The Master Steel Manufactory', '0359302195', '6'),
(632, 408, 'PT. Akino Wahanamulia', '5300910302', '005'),
(633, 409, 'PT. Plastrade World', '4079000920', '006'),
(634, 410, 'PT. Excel Metal Industry', '0359093227', '5'),
(635, 411, 'PT Altrak 1978', '0359303434', '005;013'),
(636, 412, 'PT. Milko Beverage Industry', '736.090.0201', '013'),
(637, 413, 'PT Salim Ivomas Pratama, Tbk', '035-909-4126', '004'),
(638, 414, 'PT Kobexindo Tractors', '206.909.2424', '012'),
(639, 414, 'PT Kobexindo Konstruksi Indonesia', '206.913.6286', '003'),
(640, 414, 'PT Khatulistiwa Prima Sejati ', '988.057.9018', '003'),
(641, 414, 'PT kobexindo Equipment', '206.923.7881', '002'),
(642, 414, 'PT Eurotruk Transindo', '206.982.3208', '009'),
(643, 415, 'PT. Catur Sentosa Anugerah', '2059003369', '3, 7'),
(644, 416, 'PT. Catur Mitra Sejati Sentosa', '2059001633', '8'),
(645, 417, 'PT. Catur Sentosa Adiprana, Tbk', '0359096137', '11, 17'),
(646, 418, 'PT HRC Prima Sejahtera', '2059007372', '5'),
(647, 418, 'PT Hiba Logistik', '2059008034', '3'),
(648, 418, 'PT Asli Prima Inti Karya', '2059008867', '5'),
(649, 418, 'PT Hidup Baru Putra', '2059008905', '3'),
(650, 418, 'PT Hiba Prima Sejahtera', '2059008875', '5'),
(651, 418, 'PT Setia Negara', '2059008913', '3'),
(652, 418, 'PT Murni Anugrah Jaya Usaha', '2059008891', '3'),
(653, 418, 'PT Putri Jaya Sejahtera', '2059012422', '3'),
(654, 419, 'PT. Datascrip', '0029000800', '019'),
(655, 420, 'PT. Datascrip', '0029000800', '019'),
(656, 421, 'PT. Datascrip', '0029000800', 'BG IDR 385 M kom 004; BG IDR 15 M kom 019'),
(657, 422, 'PT. Home Center Indonesia', '035.900.8815', '002 (BG P4BM) ; 006 (KMF terdiri dr BG & SBLC)'),
(658, 423, 'PT Anugerah Indofood Barokah Makmur', '205-900-9847', '005, 007'),
(659, 424, 'PT Tifico Fiber Indonesia, Tbk', '205.907.0571', '010'),
(660, 425, 'PT Intiroda Makmur', '2059007798', '4  '),
(661, 426, 'CV Perjuangan Steel', '0109073603', '12'),
(662, 427, 'PT. GLOBAL DIGITAL NIAGA Tbk', '2059011094', '001'),
(663, 428, 'PT Ispat Indo', '0359302969', '12'),
(664, 428, 'PT Ispat Bukit Baja', '8290902861', '9'),
(665, 429, 'PT. Kawan Lama Sejahtera', '006-901-1324 (BG KLS);205-900-8361 (KMF BG)', '003 (Max Rp 35 M); 001 (KMF Grup)'),
(666, 429, 'PT. Krisbow Indonesia', '205-900-8379', '002 (Max Rp 25 M)'),
(667, 429, 'PT. Sensor Indonesia', '205-900-8344', '002 (Max RP 12 M)'),
(668, 429, 'PT. Indo Kompresigma', '205-900-9987', '002 (Max Rp 10 M)'),
(669, 429, 'PT. Kawan Lama Inovasi', '205-901-0071', '002 (Max Rp 2 M)'),
(670, 429, 'PT. Emaro Online Indonesia', '205-900-9804', '001 (Max Rp 25 M)'),
(671, 429, 'PT. Kalden Indonesia', '000-691-3053', '001 (Max Rp 3 M)'),
(672, 429, 'PT. Indahvaria Ekaselaras', '205-901-4531', '001 (Max Rp 8 M)'),
(673, 430, 'PT Karya Teknik Utama', '2059013577', '006'),
(674, 431, 'PT. ARTA BATRINDO', '1689001678', '007'),
(675, 432, 'PT. BARIA BULK TERMINAL', '1689013480', '11'),
(676, 433, 'PT Indokemika Jayatama', '205-907-0911', '009'),
(677, 434, 'MAHKOTA INDONESIA', '0359006421', '001'),
(678, 435, 'INDONESIAN ACIDS INDUSTRY', '0359093545', '004'),
(679, 436, 'PT Arista Jaya Lestari', '2059008191', '3'),
(680, 437, 'PT Srikandi Diamond Motors', '0359005646', '4,5,6,8,9,12,13,14'),
(681, 438, 'PT Srikandi Diamond Indah Motors', '0359005654', '4,5,6,8,9,11,10,12'),
(682, 439, 'PT Gemilang Berlian Indah', '0359005999', '5,6,10,11,12,14'),
(683, 440, 'PT Lotus Andalan Sekuritas', '2059004659', '001'),
(684, 441, 'PT Lotus Andalan Sekuritas', '2059004659', '001'),
(685, 442, 'PT Link Net Tbk', '2059014590', '2'),
(686, 443, 'PT Tri Sapta Jaya', '2059002141', '2'),
(687, 444, 'SRITEX GRUP ', '205-901-1485', '021'),
(688, 445, 'PT Tri Sapta Jaya', '2059002141 ', '2'),
(689, 446, 'PT Pixel Komunitas', '205 901 0128', '005'),
(690, 447, 'PT Morula Indonesia', '4559303035', '006'),
(691, 448, 'Grup Malindo', 'terlampir', 'terlampir'),
(692, 449, 'PT Asri Pancawarna', '0359093936', '17 dan 41'),
(693, 449, 'PT Asri Pancawarna', '0359093936', '22 dan 26'),
(694, 450, 'PT. Malindo Feedmill', '2059002745', '06; 02'),
(695, 451, 'PT. Tekpak Indonesia', '2059012716', '011'),
(696, 452, 'PT. Ciliandra Perkasa dan 10 PT Lainnya', 'terlampir', 'terlampir'),
(697, 453, 'PT Bahtera Bahari Shipyard', '2059009413', '008'),
(698, 454, 'PT Sarana Multi Infrastruktur', '2059011442', '006'),
(699, 455, 'PT. United Equipment Indonesia', '2059014603', '3'),
(700, 456, 'PT Indomarco Adi Prima', '035-900-5841', '004'),
(701, 457, 'PT. GLOBAL DIGITAL NIAGA Tbk', '2059011094', '001'),
(702, 458, 'PT. Bumen Redja Abadi', '0849096666 ', '2'),
(703, 459, 'PT Steel Pipe Industry of Indonesia Tbk ', '205-907-146-1', '003'),
(704, 459, 'PT Steel Pipe Industry of Indonesia Tbk ', '205-900-232-0 ', '011'),
(705, 459, 'PT Steel Pipe Industry of Indonesia Tbk ', '010-907-287-9 ', '001'),
(706, 460, 'PT. NIRWANA LESTARI', '6430900313', '002'),
(707, 461, 'BG KMF DCM', '2059071925', '01'),
(708, 461, 'BG KMF Erafone', '2059004501', '02'),
(709, 461, 'BG KMF Erajaya', '2059071933', '06'),
(710, 461, 'BG KMF SES', '2059071941', '04'),
(711, 461, 'BG KMF TAM', '2059005566', '03'),
(712, 461, 'BG KMF NGA', '2059005671', '03'),
(713, 461, 'BG KMF NASA', '2059008263', '02'),
(714, 461, 'BG KMF SAM', '2059009723', '03'),
(715, 461, 'BG KMF UAS ', '2059009715', '05'),
(716, 461, 'BG KMF Seasonal Erajaya', '2059071933', '21'),
(717, 461, 'BG KMF Seasonal TAM', '2059005566', '19'),
(718, 462, 'PT. Molindo Raya Industrial', '011-901-6527', '003'),
(719, 463, 'PT Charoen Pokphand Indonesia Tbk', '0359006294', '5'),
(720, 463, 'PT Charoen Pokphand Jaya Farm', '0359006286', '3'),
(721, 464, 'PT Hindo', '205-901-3291', '003'),
(722, 464, 'PT FAR Utama Indonesia', '205-901-3461', '001'),
(723, 464, 'PT Makan Makan International', '205-901-3585', '001'),
(724, 464, 'PT. Cathlon Raga Indo', '205-901-4689', '004'),
(725, 465, 'PT Tirta Medan Johor Sukses ', '205-901-4654', '002'),
(726, 466, 'PT. Gunung Madu Plantations', '1179001649', '5'),
(727, 467, 'PT. Prokemas Adhikari Kreasi', '2059007054', '003'),
(728, 468, 'PT Surya Darma Perkasa', '035 900 5531', '12'),
(729, 469, 'Sinochem Grup', '205-901-337-2', '004'),
(730, 470, 'PT. Indah Jaya Textile Industry', '035-930-2390', '01 (sublimit USD); 039 (sublimit IDR)'),
(731, 471, 'PT. Enseval Putera Megatrading Tbk', '0359008548', '002'),
(732, 472, 'PT. Bukitmega Masabadi ', '035-930-2381', '006'),
(733, 473, 'PT. GLOBAL DIGITAL NIAGA Tbk', '2059011094', '001'),
(734, 474, 'PT. Opal Coffee Indonesia', '7865900171', '2'),
(735, 475, 'PT. Tamaris HIdro', '205-900-8948', '01'),
(736, 475, 'PT. Partogi Hidro Energi', '205-900-9332', '01'),
(737, 475, 'PT. Lampung Hydroenergy', '205-900-8930', '03'),
(738, 475, 'PT. Senagan Energi', '205-900-8646', '014'),
(739, 476, 'PT Nusantara Surya Sakti', '2059001617', '2'),
(740, 476, 'PT Niaga Super Surya', '2059005744', '1'),
(741, 476, 'PT Mekar Nusantara Teguh', '2059009740', '1'),
(742, 477, 'PT Olam Indonesia', '0359006600', '8'),
(743, 478, 'PT Karya Teknik Utama', '2059014751', '004'),
(744, 479, 'PT. Global Chemindo Megatrading', '2059001579', '001'),
(745, 480, 'PT Global Tiket Network', '2059005727', '010'),
(746, 481, 'PT Satyamitra Kemas Lestari', '0359093634', '035'),
(747, 482, 'PT Panorama JTB Tours Indonesia', '2619000140', '9'),
(748, 483, 'PT Indoguna Utama dan 4 PT grup Usaha serta PT Nuansa Guna Utama', '2059009057', '003 dan sublimitnya'),
(749, 484, 'PT Indokuat Sukses Makmur', '205-901-0756', '001'),
(750, 485, 'PT. United Equipment Indonesia', '2059014603 ', '7'),
(751, 486, 'PT Temas Tbk.', '2059010772', '008'),
(752, 486, 'PT Temas Depot', '2059011728', '002'),
(753, 486, 'PT Temas Port', '2059010781', '002'),
(754, 486, 'PT Temas Shipping', '2059011736', '002'),
(755, 487, 'PT Jakarta Land', '2059006627', '4'),
(756, 488, 'PT Satyamitra Kemas Lestari', '0359093634', '035'),
(757, 489, 'PT Nippon Indosari Corpindo, Tbk.', '205-907-0821 ', '002'),
(758, 490, 'PT Caturadiluhur Sentosa', '2059001943', '4'),
(759, 491, 'Grup RGE (KMF) ', '205-901-4786', '1'),
(760, 491, 'Grup RGE (KMS) ', '205-901-4786', '2'),
(761, 491, 'PT Tidar Kerinci Agung ', '205-901-2911', '2'),
(762, 491, 'PT Delima Makmur ', '205-901-2902', '2'),
(763, 491, 'PT Sari Dumai Oleo ', '205-901-2929', '3'),
(764, 491, 'PT Sari Dumai Sejati ', '205-901-1132', '5'),
(765, 492, 'PT. TRIAS SENTOSA', '0359006189', '005'),
(766, 493, 'PT. TRIAS TOYOBO ASTRIA', '2059011108', '10'),
(767, 494, 'PT. Datascrip', '0029000800', 'BG IDR 400M kom 004; BG IDR 15 M kom 019'),
(768, 495, 'PT. Matahari Alka', '9880110915', '003'),
(769, 495, 'PT. Matahari Alka Indonesia', '0029004295', '002'),
(770, 496, 'PT. Indonesia Libolon Fiber System', '035-930-1938', '010'),
(771, 497, 'PT. Matahari Alka', '9880110915', '003'),
(772, 497, 'PT. Matahari Alka Indonesia', '0029004295', '002'),
(773, 498, 'PT Global Indonesia Asia Sejahtera', '9880222870', '13'),
(774, 499, 'Sinochem Grup', '205-901-337-2', '004'),
(775, 500, 'PT Sinar Galaxy', '0889001765', '11 dan 12'),
(776, 501, 'PT. Indoguna Utama dan 17 PT  anak usaha', '2059009057', '003 dan sublimitnya'),
(777, 502, 'Sinochem Grup', '205-900-840-9', '004'),
(778, 503, 'PT Indofood Fortuna Makmur', '205-900-1587 (BG IDR) dan 205-907-0848 (BG KMF USD)', '001 (BG IDR) dan 003 (BG KMF USD)'),
(779, 504, 'PT Rolimex Kimia Nusamas', '2059013372', '4'),
(780, 505, 'PT Rolimex Kimia Nusamas', '2059013372', '6 (Plafon Induk KMF no.kom 4)'),
(781, 506, 'PT. Trimegah Sekuritas Indonesia', '035-9008645', '2'),
(782, 507, 'PT Sinar Mas Agro Resources and Technology Tbk (â€œSMARTâ€)', '0359300800', '8,9,10,12,13,15 (bagian dari KMF Kom 2)'),
(783, 507, 'PT Soci Mas (â€œSOCIâ€)', '0359300800', '8,9,10,12,13,15 (bagian dari KMF Kom 2)'),
(784, 507, 'PT Sinarmas Bio Energy (â€œSBEâ€)', '0359300800', '8,9,10,12,13,15 (bagian dari KMF Kom 2)'),
(785, 507, 'PT Rolimex Kimia Nusamas (â€œRKNâ€)', '0359300800', '8,9,10,12,13,15 (bagian dari KMF Kom 2)'),
(786, 508, 'PT. Kino Indonesia, Tbk', '286.900.0064', '007'),
(787, 509, 'PT. Cibadak Indah Sari Farm ', '205-900-617-1', 'Kom 9  (BG), Kom 10 (SBLC), Kom 11 (LC)'),
(788, 510, 'PT XL Axiata Tbk', '0359008386', '4'),
(789, 511, 'PT Meratus Line', '2059001935', '010'),
(790, 512, 'PT Daliatex Kusuma', '205-900-1200', '001'),
(791, 513, 'PT Daliatex Kusuma', '205-900-1200', '001'),
(792, 514, 'PT Pixel Komunitas', '205 901 0128', '5'),
(793, 515, 'PT DHARMA SUMBER NUSANTARA', '2059014867', '1'),
(794, 516, 'PT Imora Motor', '2059000335', '1'),
(795, 517, 'PT. GLOBAL DISTRIBUSI PUSAKA', '2059010225', '002'),
(796, 518, 'PT. GLOBAL DIGITAL NIAGA', '2059011094', '001'),
(797, 519, 'PT. Reliance Sekuritas Indonesia Tbk.', '2059001145', '001'),
(798, 520, 'PT. Reliance Sekuritas Indonesia Tbk.', '2059001145', '001'),
(799, 521, 'PT. Reliance Sekuritas Indonesia Tbk.', '2059001145', '001'),
(800, 522, 'PT. Reliance Sekuritas Indonesia Tbk.', '2059001145', '001'),
(801, 523, 'PT. Reliance Sekuritas Indonesia Tbk', '2059001145', '1'),
(802, 524, 'PT Inter World Steel Mills Indonesia', '0359007762', '8'),
(803, 525, 'PT Kahatex', '035-930-2209', '009'),
(804, 526, 'PT XL Axiata Tbk', '0359008386', '4'),
(805, 527, 'PT Growth Asia', '2059002206', '026'),
(806, 528, 'PT Panorama JTB Tours Indonesia', '2619000140', '9'),
(807, 529, 'PT XL Axiata Tbk', '0359008386', '4'),
(808, 530, 'Wilmar Grup', '2059006791', '1, 2'),
(809, 530, 'Sinar Alam Permai', '0359302888', '2, 10'),
(810, 530, 'Multi Nabati Sulawesi', '2059070562', '2, 8'),
(811, 530, 'Duta Sugar International', '2059002788', '1, 7'),
(812, 530, 'Petro Andalan Nusantara', '2059006554', '3, 6'),
(813, 530, 'Wilmar Bioenergi Indonesia', '2059072506', '2, 11'),
(814, 530, 'Sari Agrotama Persada', '2059009278', ''),
(815, 531, 'Global Amines Indonesia', '8005905067', '3'),
(816, 532, 'Multimas Nabati Asahan', '2059006562', '21'),
(817, 533, 'Multimas Nabati Asahan', '2059006562', '7, 12'),
(818, 533, 'Wilmar Padi Indonesia', '2059013224', '5'),
(819, 534, 'PT Putra Baja Deli', '2059004381', '15'),
(820, 534, 'PT Putra Baja Deli', '2059004381', '20'),
(821, 535, 'PT Verdhana Sekuritas Indonesia', '205 9014204', '002'),
(822, 536, 'PT Aruna Cahaya Pratama', '205-901-1817', '010'),
(823, 537, 'PT Agro Jaya Perdana', '0359008424', '05, 06, 07 (KMF:08)'),
(824, 538, 'PT. Duta Bahari Menara Line Dockyard', '0519005486 ', '1'),
(825, 539, 'PT Satyamitra Kemas Lestari', '0359093634', '035'),
(826, 540, 'MAYORA INDAH TBK', '2059070945', '004'),
(827, 541, 'PT. Lautan Luas Tbk', '205-907-1526', '006 (BGR)'),
(828, 542, 'PT. PKG Lautan Indonesia', '205-900-0084', '002'),
(829, 543, 'PT. MITRA ADIPERKASA Tbk', '2059000238 ', '004');
INSERT INTO `fasbg` (`id`, `flag`, `pt`, `norek`, `komit`) VALUES
(830, 544, 'PT. MAP AKTIF ADIPERKASA Tbk', '2059006015', '007'),
(831, 545, 'PT Abadi Agrosindo Persada', '2059014981', '004'),
(832, 546, 'PT Indolakto', '205-907-0899', '001'),
(833, 547, 'PT Sejahtera Bahari Abadi', '2059006279', '4'),
(834, 547, 'PT Pelita Bara Samudera', '2059011558', '5'),
(835, 547, 'PT Pelayaran Sukses Persada', '2059011892', '5'),
(836, 547, 'PT Adiraja Armada Maritim', '2059013381', '4'),
(837, 547, 'PT Prima Osean Nusantara', '2059013399', '4'),
(838, 547, 'PT Prima Maritim Bahari', '2059014565', '4'),
(839, 548, 'PT Saptasumber Lancar', '4689000913', '6');

-- --------------------------------------------------------

--
-- Struktur dari tabel `memobg`
--

CREATE TABLE `memobg` (
  `id` bigint(20) NOT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `rincian` varchar(255) DEFAULT NULL,
  `fasilitas` varchar(255) DEFAULT NULL,
  `tipeplafon` varchar(255) NOT NULL,
  `plafon` varchar(255) DEFAULT NULL,
  `tujuan` varchar(255) DEFAULT NULL,
  `deadline` varchar(255) DEFAULT NULL,
  `deadlinebg` varchar(255) DEFAULT NULL,
  `pengguna` varchar(255) DEFAULT NULL,
  `fee` varchar(255) DEFAULT NULL,
  `charges` varchar(255) DEFAULT NULL,
  `syarat` varchar(2555) DEFAULT NULL,
  `namadeb` varchar(255) DEFAULT NULL,
  `telpdeb` varchar(255) DEFAULT NULL,
  `emaildeb` varchar(255) DEFAULT NULL,
  `namagbk` varchar(255) DEFAULT NULL,
  `telpgbk` varchar(255) DEFAULT NULL,
  `emailgbk` varchar(255) DEFAULT NULL,
  `authsign` varchar(5000) DEFAULT NULL,
  `keterangan` varchar(5000) DEFAULT NULL,
  `hc` varchar(255) DEFAULT NULL,
  `alktohc` int(2) DEFAULT NULL,
  `bgop` int(2) DEFAULT '0',
  `reject` int(2) DEFAULT NULL,
  `datememo1` varchar(255) DEFAULT NULL,
  `datememo2` varchar(255) DEFAULT NULL,
  `flag` bigint(20) DEFAULT NULL,
  `comment` varchar(8000) DEFAULT NULL,
  `revisi` varchar(255) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `download` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `memobg`
--

INSERT INTO `memobg` (`id`, `creator`, `rincian`, `fasilitas`, `tipeplafon`, `plafon`, `tujuan`, `deadline`, `deadlinebg`, `pengguna`, `fee`, `charges`, `syarat`, `namadeb`, `telpdeb`, `emaildeb`, `namagbk`, `telpgbk`, `emailgbk`, `authsign`, `keterangan`, `hc`, `alktohc`, `bgop`, `reject`, `datememo1`, `datememo2`, `flag`, `comment`, `revisi`, `file`, `download`) VALUES
(1, 'Dena Rahmania', 'DATA', 'Bank Garansi', 'USD', '9,000,000', 'jaminan pelaksanaan,', '6 February 2022', '1 tahun', 'PT pamungkas', '90 % p.a dihitung dari nilai BG yang diterbitkan atau  minimal Rp 500.000 apabila dibuka dalam mata uang IDR dan USD 35,- apabila dibuka dalam USD; dibayar dimuka pada setiap penerbitan', 'Rp. 250.0000	', '-', 'Bapak Bambang \r\npamungkas/ Ibu  \r\npamungkas', '(0271) 827272', 'pamungkas@gmail.com / pamungkas@yahoo.com ', 'Kolina Muliadinata', '105250498', 'pamungkas@bca.co.id ', 'Direktur Utama atau 1 Direktur lainnya:\r\nJagadish Hanumantha Reddy	(Direktur Utama)\r\nImeke Djianto (Direktur)\r\n', '', 'Wilbert Karel Wetik', 1, 1, 0, '19 April 2021, 10:15 am', '19 April 2021, 10:24 am', 15, '5;Cek di PK utk Tujuan Penerbitan BG nya', NULL, '1618817513-SPPKBCA.pdf', 'Gabriella Melati Noviasari T (19 April 2021, 2:12 pm)'),
(2, 'Hizkia Ignatius Tambun', 'DATA', 'Bank Garansi', 'IDR', '75,000,000,000', 'Sebagai agunan kepada KPEI untuk transaksi di BEI dan/atau Penjaminan Emisi Efek', '28 July 2021', '1 tahun', 'PT. pamungkas pamungkas Indonesia', '1% per tahun atau minimal Rp 250.000,-', 'Rp 250.000 per penerbitan BG', 'Setiap penerbitan BG menyerahkan agunan dana tunai dalam bentuk deposito berjangka sebesar : 1). Untuk BG Penjaminan Emisi saham: 20% dari nilai Bank Garansi yang diterbitkan dan Daftar Objek Gadai di atas materai; 2).Untuk BG Penjaminan', 'PT. pamungkas Sekuritas pol', '021 255 33 600 Fax. 021 579 44 375', 'pamungkas.pamungkas@valbury.com ', 'V. Dewi Andri Wijaya', '1058791', 'pamungkas@bca.co.id', 'Direktur Utama atau 2 anggota Direksi', '-', 'Wilbert Karel Wetik', 1, 1, 0, '19 April 2021, 3:02 pm', '19 April 2021, 3:11 pm', 16, NULL, NULL, '1618837292-SPPKValburytgl15Juli2020.pdf', 'Gabriella Melati Noviasari T (19 April 2021, 3:39 pm)'),
(18, 'Hanindha Putri Hardannie', 'DATA', 'Bank Garansi', 'IDR', '2,000,000,000', 'jaminan proyek-proyek PT Pancaran Darat Transport dan penerbitan counter guarantee untuk penerbitan ke bank lain', '20 October 2021', '2 bulan ', 'PT Pancaran Darat pamungkas.', '1% p.a minimal Rp.250.000,-', 'Rp 100.000,00 per penerbitan', '-', 'Ali Susanto', '087780012762', 'ali.pamungkas@pancaran-group.co.id ', 'Marius Daviando', '1058550', 'pamungkas@bca.co.id', 'Jabatan      :   Direktur \r\n(RAD Terlampir)\r\n', '', 'Lidia', 1, 1, 0, '23 April 2021, 4:24 pm', '23 April 2021, 4:48 pm', 18, 'jt BG dan By Rp. 250 rb', NULL, '1619178554-RADPDT.zip', 'Gabriella Melati Noviasari T (27 April 2021, 10:06 am)'),
(19, 'Hanindha Putri Hardannie', 'DATA', 'Bank Garansi', 'IDR', '124,000,000,000', 'Untuk pembukaan bid bod/performance bond/payment bond dan counter guarantee ke bank lain', '20 October 2021', '1 bulan', 'PT Transport, PT Darat Transport, PT Maritim , PT Logistik Indonesia, PT Pancaran Energi Transportasi dan PT Pancaran Samudera Shipyard.\r\n\r\n', '1% p.a minimal Rp.250.000,-', 'Rp.100.000,- per penerbitan ', '- Penerbitan Bank Garansi berdasarkan surat referensi dari supplier PT AKR Corporindo Tbk., surat referensi dari buyer (termasuk counter guarantee ke bank lain) dengan mencantumkan nilai Bank Garansi, jangka waktu, serta mengikuti ketentuan yang berlaku d', 'Ali pamungkas', '087780012762', 'pamungkas.pamungkas@pancaran-group.co.id ', 'pamungkas Daviando', '1058550', 'marius_daviando@bca.co.id', 'Jabatan      :   Direktur \r\n(RAD Terlampir)\r\n', '', 'Lidia', 1, 1, 0, '23 April 2021, 2:57 pm', '23 April 2021, 3:36 pm', 19, NULL, NULL, '1619182652-RADPST.zip', 'Gabriella Melati Noviasari T (27 April 2021, 10:06 am)'),
(20, 'Maria Gretalita Niken Winaputri', 'DATA', 'Bank Garansi', 'USD', '22,000,000', 'Untuk bid bond, performance bond, payment bond, advance payment bond, serta Bank Garansi yang ditujukan kepada Dirjen Bea dan Cukai', '12 June 2022', 'max 1 tahun', 'PT. Panca pamungkas Pratama dan/atau PT. Panca Budi Idaman, Tbk dan/atau PT. pamungkas pamungkas Niaga dan/atau PT. pamungkasIndo ', '1% pa (min Rp 700.000 / USD 50)', 'Rp 200.000', '-', 'Ibu pamungkas / Ibu Lim pamungkas ', '(021) 54365555', 'errin.pamungkas@pancabudi.com ; pamungkas@pamungkas.com', 'Mery Astuti', '1051164', 'pamungkas@bca.co.id ', 'Direktur Utama / 1 Direktur lainnya', '-', 'David Ardian', 1, 1, 0, '28 April 2021, 11:37 am', '28 April 2021, 12:48 pm', 20, NULL, NULL, '1619599244-SPPKPBP(rev).pdf', 'Gabriella Melati Noviasari T (29 April 2021, 2:02 pm)'),
(21, 'Maria Gretalita Niken Winaputri', 'DATA', 'Bank Garansi', 'USD', '7,000,000', 'Untuk bid bond, performance bond, payment bond, advance payment bond, serta Bank Garansi yang ditujukan kepada Dirjen Bea dan Cukai', '12 June 2022', 'max 1 tahun', 'PT. Panca pamungkas pamungkas dan/atau PT. pamungkas Idaman, ', '1% pa (min Rp 700.000 / USD 50)', 'Rp 100.000', '-', 'Ibu Lim Mei Hwa', '(021) 54365555', 'pamungkas@pancabudi.com', 'Mery Astuti', '1051164', 'pamungkas@bca.co.id ', 'Direktur Utama / 2 Direktur lainnya', '', 'David Ardian', 1, 1, 0, '28 April 2021, 11:37 am', '28 April 2021, 12:48 pm', 21, NULL, NULL, '1619599438-SPPKPBI.pdf', 'Gabriella Melati Noviasari T (29 April 2021, 4:02 pm)'),
(22, 'Maria Gretalita Niken Winaputri', 'DATA', 'Bank Garansi', 'USD', '1,000,000', 'Untuk bid bond, performance bond, payment bond, advance payment bond, serta Bank Garansi yang ditujukan kepada Dirjen Bea dan Cukai', '12 June 2022', 'max 1 tahun', 'PT.pamungkas', '1% pa (min Rp 700.000 / USD 50)', 'Rp 100.000', '-', 'Ibu pamungkas', '(021) 29430799465', 'pamungkas.pamungkas@pamungkas.com', 'Mery Astuti', '105116455', 'mery_astuti@bca.co.id ', 'Direktur Utama / 1 Direktur lainnya', '-', 'David Ardian', 1, 1, 0, '28 April 2021, 11:37 am', '28 April 2021, 12:51 pm', 22, NULL, NULL, '1619599605-SPPKPBN.pdf', 'Gabriella Melati Noviasari T (29 April 2021, 4:02 pm)'),
(23, 'Maria Gretalita Niken Winaputri', 'DATA', 'Bank Garansi', 'USD', '1,000,000', 'Untuk bid bond, performance bond, payment bond, advance payment bond, serta Bank Garansi yang ditujukan kepada Dirjen Bea dan Cukai', '12 June 2022', 'max 2 tahun', 'PT. Panca Warna', '2% pa (min Rp 500.000 / USD 50)', 'Rp 100.000', '-', 'Ibu Yuyuh kwateh', '(0254)-57123305', 'kwateh@polytechindohausen.com ', 'Mery kwateh', '1051164', 'kwateh@bca.co.id ', 'Direktur Utama / 1 Direktur lainnya', '', 'David Ardian', 1, 1, 0, '28 April 2021, 11:38 am', '28 April 2021, 12:51 pm', 23, NULL, NULL, '1619599824-SPPKPIH(rev).pdf', 'Gabriella Melati Noviasari T (29 April 2021, 4:02 pm)'),
(24, 'Valiant Gunawan', 'DATA', 'Bank Garansi Case By Case', 'IDR', '7,226,798,630', 'Jaminan Pelaksanaan Pekerjaan Pemeliharaan Scrapping Filling Overlay (SFO) dan Rekonstruksi Perkerasan pada Ruas Jalan Tol Surabaya - Gempol Tahun 2021', '6 February 2022', '23-01-2022', 'PT. fasrt', '1% p.a (Minimal Rp. 250.000,-)', 'Rp. 500.000,- setiap penerbitan BG', '-', 'PT. kwateh', '085739066688', 'olivia.susanto@tirtobumi.com', 'Maria Magdalena', '1053522', 'kwateh@bca.co.id', 'Direktur Utama/Anggota Direksi lainya apabila Direktur utama berhalangan', 'Jaminan Deposito', 'Mega Febrilia', 1, 1, 0, '28 April 2021, 2:51 pm', '28 April 2021, 3:05 pm', 24, NULL, NULL, '1619608494-RADTBA2021-04-26-151715.pdf', 'Gabriella Melati Noviasari T (29 April 2021, 4:02 pm)'),
(25, 'slk op', 'DATA', '', 'USD', '14,045', '', '29 April 2021', '', '', '', '', '', '', '', '', '', '', '', '', '', 'SLK HC Testing', 0, 0, 0, '29 April 2021, 10:44 am', NULL, 25, NULL, NULL, '', NULL),
(26, 'Nur Rahmah Hastiati', 'DATA', 'Bank Garansi', 'IDR', '140,340,000,000', 'Untuk Jaminan pembelian,tender,pelaksanaa,dll atas barang farmasi/obat-obatan, alat kesehatan, dll yang didistribusikan AAM', '31 August 2022', '3 tahun', 'PT Argon ', '0.5% per tahun, minimum Rp. 250.000,- dihitung dari nilai BG yang diterbitkan', 'Rp. 150.000,- per pembukaan BG', 'Mengajukan Surat Permohonan Penerbitan Bank Garansi secara tertulis yang bersifat mengikat dan tidak dapat diubah dan/atau dibatalkan oleh Debitor, Sekurang-kurangnya 2 (dua) hari kerja sebelum penarikan dengan melampirkan data/dokumen yang diperlukan unt', 'Ibu Tri/Ibu Nelly', '021 2997 2600 ext 5594/ 0816 1827 647 ', 'kwateh@anugrah-argon.com; tri.kwateh@anugrah-argon.com', 'Yenita Hasli', '1010265', 'kwateh@bca.co.id', 'Direktur Utama atau seorang Direktur', '-', 'Elza Widyasari', 1, 1, 0, '29 April 2021, 2:00 pm', '29 April 2021, 2:28 pm', 26, NULL, NULL, '1619697654-SPPKAAMPPJtgl24Maret2021.pdf', 'Gabriella Melati Noviasari T (29 April 2021, 4:02 pm)'),
(27, 'Aris Fredy', 'DATA', 'Bank garansi', 'IDR', '200,000,000,000', 'penjamin kepada pemberi kerja atas proyek yang dikerjakan debitur dan anak perusahaan', '24 November 2021', '1 tahun', '1. PT lol\r\n2. PT pol', '1% minimal Rp.250.000,00', 'Rp.5450.000,00', '1 Surat perjanjian atas SPK dengan pemilik proyek\r\n2. surat yang berisikan permintaan dari pemilik proyek untuk diterbitkan BG berupa Advance payment, Performance, Retention atau Bid Bond, Khusus bid bond permintaan atas jenis tersebut harus ada di dalam surat undangan tender dari pemilik proyek\r\n3.khusus BG yang diterbitkan oleh anak perusahaan, wajib menyerahkan surat pernyataan bahwa PT Modern Widya bertanggung jawab atas seluruh akibat, termasuk melunasi seluruh hutang yang timbul dari diterbitkannya BG tersebut', 'Andrew Marcel', '0', 'LIONG LIEM <mwtj_keu@yahoo.co.id>', 'Sugianto Huang', '1051004', 'kwateh@bca.co.id', 'direktur utama atau salah satu direktur lainnya', 'BG bisa diterbitkan antara minimal 1 tahun sampai maksimal 2 tahun dengan syarat harus ada persetujuan dan Grup head ARK dan GBK', 'Dewi Virgina', 1, 1, 0, '3 May 2021, 11:20 am', '3 May 2021, 11:21 am', 27, '11;', NULL, '1620030526-image2021-04-30-142545.zip', 'Gabriella Melati Noviasari T (4 May 2021, 2:55 pm)'),
(28, 'Hindrawati', 'DATA', 'Bank Garansi', 'IDR', '', '- Dapat digunakan untuk semua jenis BG ( selaina jaminan dalam rangka memperoleh pinjaman) - Untuk penjaminan ke proyek dan bea cukai - Sebagai Counter Guarantee jaminan proyek dalam bentuk BG ke bank lain', '30 November 2021', 'Dapat lebih dari 1 tahun (sesuai dengan jangka waktu kontrak), khusus untuk retention bond maksimum selama 2 tahun', 'PT kwateh Tbk', '- Biaya Komisi : 1%, min Rp. 250.000,- (dihitung dari nilai Bank Garansi yang diterbitkan dan dibayar dimuka pada setiap penerbitan)\r\n- Counter Guarantee : Total biaya penerbitan BG/SBLC = biaya penerbitan BG/SBLC di BCA untuk keperluan CG sebesar 0,75% p', 'Rp. 250.000,- per pembukaan', '', 'Redty / Ninik (Surabaya)', '031-532250320', 'kwateh@spindo.co.id', 'Lie kwateh', '10521462', 'kwateh@bca.co.id', 'Direktur Utama dan seorang anggota Direksi, apabila Direktur Utama berhalangan maka dapat digantikan oleh 2 anggota Direksi lainnya', '', 'Dewi Virgina', 1, 1, 0, '4 May 2021, 1:30 pm', '4 May 2021, 1:32 pm', 28, NULL, NULL, '1620127114-SPPKSPINDO2021.pdf', 'Gabriella Melati Noviasari T (4 May 2021, 2:55 pm)'),
(30, 'Valiant Gunawan', 'DATA', 'Bank Garansi', 'USD', '5,000,000', 'Fasilitas BG/SBLC dapat digunakan untuk segala Jenis BG/SBLC (tidak termasuk untuk jaminan atas pinjaman yang diperoleh pihak lain)', '9 August 2021', 'maksimal 2 tahun', 'PT. Aneka buah, Tbk', '0,25% p.a (minimal Rp. 250.000,-) atau Ekv USD 25', 'Rp. 250.000,- per penerbitan', '', 'PT. Aneka buah, Tbk', '(021) 789122334 Ext. 14321', 'kwateh.kamal@antam.com', 'Maria Dewi Puspita Sari', '1051919', 'kwateh@bca.co.id', 'Direktur Utama atau wakil Direktur Utama atau Direktur Utama menunjuk secara tertulis salah satu anggota Direksi ', '', 'Nyimas Wida', 1, 1, 0, '7 May 2021, 11:22 am', '7 May 2021, 11:31 am', 30, NULL, NULL, '1620379332-PerpanjanganBG.zip', 'Andi Eldyana Pratama (7 May 2021, 2:22 pm)'),
(31, 'Caecilia Novadena', 'DATA', 'Bank Garansi', 'IDR', '6,150,000,000,000', 'Transaksi Operasional debitor yaitu menjamin kewajiban debitor kepada pihak ketiga, namun tidak untuk menjamin kewajiban pembayaran utang berdasarkan fasilitas kredit', '21 August 2021', '', 'PT. Nabati kill', '0.4% p.a yang dihitung dari nilai SBLC/BG yang diterbitkan (min IDR 250.000) dibayar dimuka pada setiap penerbitan', 'IDR 300.000 per penerbitan', '1.	Mengajukan Surat Permohonan Penerbitan SBLC atau Surat Permohonan Penerbitan Bank Garansi secara tertulis yang bersifat mengikat dan tidak dapat diubah dan/atau dibatalkan, sekurang-kurangnya 2 (dua) hari kerja sebelumnya dengan melampirkan data atau dokumen yang dperlukan untuk penerbitan SBLC atau Bank Garansi\r\n\r\n2.	Dilakukan dalam batas waktu penarikan dan/atau penggunaan fasilitas kredit \r\n', 'Linda Yu', '061-41022323810', 'kwateh.yu@wilmar.co.id', 'Cathlin Toinando', '', 'kwateh@bca.co.id', 'RAD terlampir', 'Fasilitas BG dapat direalisasikan dalam multicurrency yang sesuai dengan ketentuan BCA. \r\nBlokir penarikan fasilitas dalam mata uang yang berbeda dengan mata uang plafon sebesar 100%\r\nMerupakan sublimit dari fasilitas KMF (Rek ILS 2059006562) yang terdiri dari fasilitas Kredit Lokal, Pinjaman Money Market (PBMM), L/C dan SKBDN (Sight dan Usance), Standby Letter of Credit (SBLC), Bank Garansi dan Negosiasi dan Diskonto dengan kondisi khusus\r\n', 'Nyimas Wida', 1, 1, 0, '7 May 2021, 1:33 pm', '7 May 2021, 1:45 pm', 31, NULL, NULL, '1620387228-RADMNAUpdate29.4.21.pdf', 'Andi Eldyana Pratama (7 May 2021, 2:25 pm)'),
(32, 'Junista', 'DATA', 'Bank Garansi ', 'IDR', '14,000,000,000', 'Untuk pembukaan bid bod/performance bond/payment bond dan counter guarantee ke bank lain', '20 October 2021', '12 bulan', 'PT Pancaran batu akik ', '1% p.a minimal Rp.350.000,-', 'Rp.900.000,- per penerbitan ', 'Penerbitan Bank Garansi berdasarkan surat referensi dari supplier PT AKR Corporindo Tbk., surat referensi dari buyer (termasuk counter guarantee ke bank lain) dengan mencantumkan nilai Bank Garansi, jangka waktu, serta mengikuti ketentuan yang berlaku di BCA', 'Vinda Oktapianda', '08787624081230', 'vinda.kwateh@pancaran-group.co.id', 'Marius', '1058550', 'kwateh@bca.co.id', 'Direktur, RAD terlampir ', 'Catatan penting:setiap kali penerbitan fasilitas BG PDT,  PMT, PLI, PET dan PSS di ILS akan diperhitungkansebagai oustanding BG PT PST dan dibukukuan di ILS PT PST', 'Lidia', 1, 1, 0, '7 May 2021, 1:38 pm', '7 May 2021, 2:16 pm', 32, NULL, NULL, '', 'Andi Eldyana Pratama (7 May 2021, 2:22 pm)'),
(33, 'Caecilia Novadena', 'DATA', 'Bank Garansi', 'USD', '154,210,000', 'Transaksi Operasional debitor yaitu menjamin kewajiban debitor kepada pihak ketiga, namun tidak untuk menjamin kewajiban pembayaran utang berdasarkan fasilitas kredit', '21 August 2021', '', 'PT lol Asahan', '0,40% p.a yang dihitung dari nilai SBLC/BG yang diterbitkan (min. IDR 250.000,00)  dibayar dimuka pada setiap penerbitan\r\n', 'IDR 400.000 per penerbitan', '1.	Mengajukan Surat Permohonan Penerbitan SBLC atau Surat Permohonan Penerbitan Bank Garansi secara tertulis yang bersifat mengikat dan tidak dapat diubah dan/atau dibatalkan, sekurang-kurangnya 2 (dua) hari kerja sebelumnya dengan melampirkan data atau dokumen yang dperlukan untuk penerbitan SBLC atau Bank Garansi\r\n\r\n2.	Dilakukan dalam batas waktu penarikan dan/atau penggunaan fasilitas kredit \r\n', 'Linda Yu', '061-41023810', 'linda.yu@wilmar.co.id', 'Cathlin Toinando', '', 'kwateh@bca.co.id', 'RAD Terlampir', 'Fasilitas BG dapat direalisasikan dalam multicurrency yang sesuai dengan ketentuan BCA. \r\nBlokir penarikan fasilitas dalam mata uang yang berbeda dengan mata uang plafon sebesar 100%\r\nMerupakan sublimit dari fasilitas KMF (Rek ILS 2059006562) yang terdiri dari fasilitas Kredit Lokal, Pinjaman Money Market (PBMM), L/C dan SKBDN (Sight dan Usance), Standby Letter of Credit (SBLC), Bank Garansi dan Negosiasi dan Diskonto dengan kondisi khusus\r\n', 'Nyimas Wida', 1, 1, 0, '7 May 2021, 1:42 pm', '7 May 2021, 1:46 pm', 33, NULL, NULL, '1620387728-RADMNAUpdate29.4.21.pdf', 'Andi Eldyana Pratama (7 May 2021, 2:25 pm)'),
(35, 'Stanlie', 'DATA', 'BG', 'IDR', '60,220,000,000', 'untuk jaminan pembayaran pembelian gas kepada Perusahaan Gas Negara (PGN)', '12 February 2022', 'Max 6 Tahun ', 'PT. kwateh POLA SEHAT', '1% p.a. dihitung dari nilai Bank Garansi yang diterbitkan\r\nDibayar dimuka pada setiap penerbitan Bank Garansi', 'IDR 250,000', 'Fasilitas dapat dibuka dalam mata uang IDR dan/atau USD', 'Ibu Suryani / Ibu Stevani', '021 58397987 Ext 6116/6121', 'suryani@ot.co.id / stevani@ot.co.id', 'Ivonne Fadli ', '10566522', 'kwateh@bca.co.id', 'Direktur Utama atau 1 Direktur lainnya', '-', 'David Ardian', 1, 1, 0, '7 May 2021, 5:23 pm', '10 May 2021, 8:21 am', 34, NULL, NULL, '1620400976-SPPKCS22021.zip', 'Andi Eldyana Pratama (10 May 2021, 1:24 pm)'),
(36, 'slk op', 'DATA', '', 'IDR|USD', '19,451,708|17,760,407', '', '10 May 2022', '', 'PT TESTES ID', '', '', '', '', '', '', '', '', '', '', '', 'SLK HC Testing', 0, 0, 0, '10 May 2021, 3:17 pm', NULL, 35, NULL, NULL, '', NULL),
(37, 'Christa Amelia', 'DATA', 'Bank Garansi (BG) Line', 'IDR', '2,000,000,000', 'sebagai jaminan pembayaran debitor', '21 February 2022', 'maksimal 1 tahun', 'PT pol a', '1% per tahun, minimal Rp 250.000,-', 'Rp 250.000,- per-penerbitan', '- BG dapat diterbitkan dengan memberikan bukti berupa permintaan BG dari supplier\r\n- BG dapat dibuka dalam IDR dan USD', 'Ibu kwateh Christjangt', '(031) 2977235705', 'sherylna.kwateh@kwateh.com', 'Marius Daviando', '1058550', 'kwateh@bca.co.id', 'direktur utama/ direktur', '-', 'Lidia', 1, 1, 0, '11 May 2021, 1:33 pm', '11 May 2021, 1:35 pm', 36, NULL, NULL, '1620732820-kartuBG.zip', 'Feliciana (20 May 2021, 2:05 pm)'),
(38, 'Cindy Chandra', 'DATA', 'KMF terdiri dari LC / SKBDN  (Sight/Usance), BG dan SBLC ', 'IDR', '10,000,000,000', 'Penjaminan ke supplier/customer, namum fasilitas tidak dapat digunakan sebagai jaminan fasilitas kredit ', '14 March 2022', '1 tahun ', 'PT. Cibadak bercula', 'Biaya Komisi : 1.00 % pertahun dari nilai BG yang diterbitkan minimal komisi sebesar Rp. 250.000,-/USD 20', '', 'Mengajukan surat permohonan Bank Garansi (H-3) ', 'PT. Cibadak bercula 2', '(021) 56609312', 'kwateh@cibadak.com ', 'Andreas Apri Susilo ', '0998-0998-27222', 'kwateh@bca.co.id', 'Direktur Utama atau direktur lainnya', 'fasilitas Bank Garansi dapat ditarik dalam berbagai mata uang yang tersedia di BCA (multicurrency).', 'Mega Febrilia', 1, 1, 0, '11 May 2021, 4:03 pm', '11 May 2021, 4:09 pm', 37, NULL, NULL, '1620741797-SPPK-Perpanjangan.zip', 'Gabriella Melati Noviasari T (21 May 2021, 11:03 am)'),
(43, 'Maria Gretalita Niken Winaputri', 'DATA', 'PT. Kino Indonesia, Tbk', 'USD', '2,000,000', 'Untuk menjamin pembayaran ke PT. Perusahan Gas Negara (Perseroan) Tbk', '31 July 2022', '1 tahun', 'PT. kwateh kwateh, Tbk', '1% (minimal Rp 250.000,-)\r\nDibayar di muka pada setiap penerbitan Bank Garansi', 'Rp. 700.000,- / setiap penerbitan Bank Garansi', 'Dapat diterbitkan dalam IDR dan USD', 'Ibu kwateh Cynthia', '80821100 / 089967422816', 'kwateh@kino.co.id', 'Mega Kurniawati Suherman', '10566254', 'kwateh@bca.co.id', 'Presiden Direktur / 1 Direktur lainnya', '', 'David Ardian', 1, 1, 0, '25 May 2021, 11:09 am', '25 May 2021, 11:40 am', 42, NULL, NULL, '1621933775-[BCA]SPPKKinoMei2021.pdf', 'Andi Eldyana Pratama (25 May 2021, 1:57 pm)'),
(44, 'Valiant Gunawan', 'DATA', 'Bank Garansi Back To Back', 'IDR', '3,500,000,000', 'Menyelenggarakan Jasa Pemborongan Pekerjaan Pemeliharaan Periodik Scrapping Filling Overlay (SFO) dan Rekonstruksi Perkerasan pada Ruas Jalan Tol Surabaya - Gempol 2021', '31 January 2023', '31-01-2023', 'PT. ferari', '1% p.a (minimal Rp. 250.000,-)', 'Rp. 520.000,- per penerbitan', '-', 'PT. kwatehdaada', '085739066682328', 'olivia.kwateh@tirtobumi.com', 'Siti Hasanah', '10511762', 'siti_hasanah@bca.co.id', 'Direktur Utama, apabila Direktur Utama berhalangan maka salah seorang anggota Direksi lainya berhak dan berwenang bertindak unutk dan atas nama Direksi serta mewakili Perseroan', '-', 'Nyimas Wida', 1, 1, 0, '25 May 2021, 1:54 pm', '25 May 2021, 1:54 pm', 43, NULL, NULL, '1621942774-RADTBA2021-04-26-151715.pdf', 'Andi Eldyana Pratama (25 May 2021, 1:57 pm)'),
(45, 'Christy Purnama', 'DATA', 'Bank Garansi', 'IDR', '750,000,000', 'menjamin kewajiban kepada pihak ketiga, termasuk bea cukai', '24 October 2022', 'maksimal 1 tahun', 'PT monn', '1% min IDR 250 ribu', 'IDR 200 ribu/lembar', '-', 'Jessica', '021-2933-3031', 'kwateh.sugiharto@combiphar.com', 'Yenita', '1010265', 'kwateh@bca.co.id', 'Presdir atau 2 direktur', '', 'Elza Widyasari', 1, 1, 0, '27 May 2021, 3:18 pm', '27 May 2021, 3:23 pm', 44, NULL, NULL, '1622121535-SPPKCombiphardanPHCtgl10Mei2021.zip', 'Andi Eldyana Pratama (28 May 2021, 1:05 pm)'),
(46, 'Nadila', 'DATA', 'Bank Garansi Uncommitted Plafond merupakan sublimit dari KMF senilai Rp1.589.600.000.000 dengan Uncommitted Time Loan', 'IDR', '50,000,000,000', 'Jaminan Pembayaran Bea Masuk, Cukai, dan Pajak dalam rangka impor bahan baku (BG kepada Dirjen Bea dan Cukai)', '29 July 2021', 'Mengikuti Ketentuan PAKAR perihal Bank Garansi Bea dan Cukai', 'PT macau sunan', '1% p.a minimal Rp250.000 (dibayar dimuka)', 'Rp221.000 per penerbitan', 'Approval terlebih dahulu oleh GBK karena fasilitas bersifat uncommitted.', 'kwateh', '061-802030844 / 0813-1409-8367', 'kwateh@gmail.com', 'Andreas Apri Susilo', '', 'kwateh@bca.co.id', 'RAD terlampir', 'Fasilitas KMF dapat direalisasikan multicurrency', 'Dewi Virgina', 1, 1, 0, '31 May 2021, 8:48 am', '31 May 2021, 9:16 am', 45, NULL, NULL, '1622201450-RADSinochemGrup.zip', 'Andi Eldyana Pratama (2 June 2021, 8:23 am)');

-- --------------------------------------------------------

--
-- Struktur dari tabel `msahu`
--

CREATE TABLE `msahu` (
  `id` int(5) NOT NULL,
  `userName` varchar(255) NOT NULL,
  `ptName` varchar(255) NOT NULL,
  `alamatPT` varchar(1000) NOT NULL,
  `address` varchar(255) NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `profile` varchar(255) NOT NULL,
  `datePenarikan` varchar(255) NOT NULL,
  `byPenarikan` varchar(255) NOT NULL,
  `apkName` varchar(255) NOT NULL,
  `terimaOrderName` varchar(255) NOT NULL,
  `dateTransaction` varchar(255) NOT NULL,
  `kodeBillingAcc` int(5) NOT NULL,
  `apkAcc` int(5) NOT NULL,
  `fileAHU` varchar(255) NOT NULL,
  `fileAHUAcc` int(5) NOT NULL,
  `kalayComment` varchar(255) NOT NULL,
  `hcComment` varchar(255) NOT NULL,
  `apkComment` varchar(255) NOT NULL,
  `staffAHUName` varchar(255) NOT NULL,
  `hcKalayName` varchar(255) NOT NULL,
  `hcKalayAcc` int(5) NOT NULL,
  `notes` varchar(255) NOT NULL,
  `biaya` bigint(255) NOT NULL,
  `extraNotes` varchar(255) NOT NULL,
  `kodeBillingAccTime` varchar(255) NOT NULL,
  `apkAccTime` varchar(255) NOT NULL,
  `hcKalayAccTime` varchar(255) NOT NULL,
  `terimaOrderAcc` int(5) NOT NULL,
  `terimaOrderAccTime` varchar(255) NOT NULL,
  `kodeBilling` varchar(255) NOT NULL,
  `cluster` varchar(255) NOT NULL,
  `yayasan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `msahu`
--

INSERT INTO `msahu` (`id`, `userName`, `ptName`, `alamatPT`, `address`, `purpose`, `profile`, `datePenarikan`, `byPenarikan`, `apkName`, `terimaOrderName`, `dateTransaction`, `kodeBillingAcc`, `apkAcc`, `fileAHU`, `fileAHUAcc`, `kalayComment`, `hcComment`, `apkComment`, `staffAHUName`, `hcKalayName`, `hcKalayAcc`, `notes`, `biaya`, `extraNotes`, `kodeBillingAccTime`, `apkAccTime`, `hcKalayAccTime`, `terimaOrderAcc`, `terimaOrderAccTime`, `kodeBilling`, `cluster`, `yayasan`) VALUES
(116, 'Friskilla Clara Swita Abadi Taede', 'PT Growth Sumatra Industry', '', 'friskilla_taede@bca.co.id', 'Lain - Lain,restruktur ', 'Terakhir', '02-04-2019', 'KCK', 'Eni Nuraini', '', '15-10-2020', 1, 1, '1602855670-PT.GROWTHSUMATRAINDUSTRY.pdf', 1, '', '', '', 'Rian Setiawan', 'Dewi Virgina', 1, 'Alamat : Jl. KL Yos Sudarso KM 10, Medan Deli, Kota Medan, Sumatera Utara', 50000, '', '07:52', '15:05', '13:45', 1, '08:58', '1602853495-AHUGROWTHSUMATRA.jpg', 'NW', ''),
(117, 'Friskilla Clara Swita Abadi Taede', 'PT SKS Listrik Kalimantan ', '', 'cluster_wida@bca.co.id', 'Lain - Lain,Perubahan Syarat Fasilitas', 'Terakhir', '23-10-2019', 'Notaris', 'Eni Nuraini', '', '15-10-2020', 1, 1, '', 1, '', '', '', 'Rian Setiawan', 'Dewi Virgina', 1, 'Alamat : APL Tower 41st Floor Suite 2, Jl. Let. Jend. S. Parman Kav 28, Jakarta Barat, DKI Jakarta', 50000, '', '07:52', '15:05', '15:40', 1, '08:59', '1602853512-AHULISTRIKKALIMANTAN.jpg', 'NW', ''),
(119, 'Nur Rahmah Hastiati', 'PT Lautan Teduh Interniaga', '', 'cluster_lidia@bca.co,id', 'Perpanjangan Fasilitas,', 'Terakhir', '13-09-2018', 'KCK', 'Eni Nuraini', '', '21-10-2020', 1, 1, '1603282572-PT.LAUTANTEDUHINTERNIAGA.pdf', 1, '', '', '', 'Rian Setiawan', 'Elza Widyasari', 1, 'Jl. Matraman Raya 71-73', 50000, '', '07:44', '14:06', '16:30', 1, '14:05', '1603281971-AHULautanTeduh211020.jpg', 'EW', ''),
(120, 'Christa Amelia', 'PT Jayamandiri Gemasejati', '', 'cluster_lidia@bca.co.id', 'Perpanjangan Fasilitas,', 'Terakhir', '28-11-2018', 'KCK', 'Eni Nuraini', '', '21-10-2020', 1, 1, '1603371665-PT.JAYAMANDIRIGEMASEJATI.pdf', 1, '', '', '', 'Rian Setiawan', 'Lidia', 1, 'Jl. BKR No. 5 Bandung', 50000, '', '10:30', '14:54', '10:11', 1, '14:52', '1603371172-AHUMandiri221020.pdf', 'LS', ''),
(121, 'Leonhard Bianda', 'PT Sarimakmur Tunggalmandiri', '', 'alk_clustermf@bca.co.id', 'Perpanjangan Fasilitas,', 'Terakhir', '25-06-2020', 'SLK', 'Eni Nuraini', '', '21-10-2020', 1, 1, '1603371694-PT.SARIMAKMURTUNGGALMANDIRI.pdf', 1, '', '', '', 'Rian Setiawan', 'Dewi Virgina', 1, 'tarik profil terakhir PT Sarimakmur Tunggalmandiri, alk_clustermf@bca.co.id, alamat : jl Kompos No. 110 A Dusun III Puji Mulio Kab Deli Serdang', 50000, '', '07:03', '14:54', '16:27', 1, '14:53', '1603371218-AHUmodern&srimakmur221020.pdf', 'MF', ''),
(122, 'Monika Istiana Dewi', 'PT Modern Widya Tehnical', '', 'cluster_dewi@bca.co.id', 'Lain - Lain,restruktur', 'Terakhir', '02-10-2019', 'Notaris', 'Eni Nuraini', '', '21-10-2020', 1, 1, '1603371716-PT.MODERNWIDYATEHNICAL.pdf', 1, '', '', '', 'Rian Setiawan', 'Dewi Virgina', 1, '0', 50000, '', '07:03', '14:55', '15:50', 1, '14:53', '1603371241-AHUmodern&srimakmur221020.pdf', 'DV', ''),
(123, 'Vinsensia Givy Gisela', 'Yayasan Badan Pendidikan Kristen Penabur', '', 'cluster_lidia@bca.co.id', 'Perpanjangan Fasilitas,', 'Lengkap', '', '', 'Eni Nuraini', '', '22-10-2020', 1, 1, '1603371728-YAYASANBADANPENDIDIKANKRISTENPENABUR.pdf', 1, '', '', '', 'Rian Setiawan', 'Elza Widyasari', 1, 'Tanjung Duren Raya, Grogol Petamburan, jakarta Barat', 500000, '', '09:21', '14:56', '09:08', 1, '14:55', '1603371262-AHUyys.pendidikan221020.pdf', 'LS', ''),
(124, 'Valiant Gunawan', 'PT. Timah, Tbk', '', 'patricia_oleano@bca.co.id', 'Perpanjangan Fasilitas,', 'Terakhir', '11-10-2018', 'KCK', 'Eni Nuraini', '', '23-10-2020', 1, 1, '1604317553-PT.TIMAH,Tbk.pdf', 1, '', '', '', 'Rian Setiawan', 'Dewi Virgina', 1, 'Alamat : Jl. Jend Sudirman No. 51, Kelurahan Opas Indah, Kecamatan Taman Sari, Pangkal Pinang', 50000, '', '08:20', '13:20', '16:55', 1, '13:20', '1604315720-AHUPTTimah021120.pdf', 'NW', ''),
(125, 'Vinsensia Givy Gisela', 'PT Surya Darma Perkasa', '', 'cluster_lidia@bca.co.id', 'Perpanjangan Fasilitas,', 'Terakhir', '20-09-2018', 'Notaris', 'Eni Nuraini', '', '26-10-2020', 1, 1, '1603720845-ProfilPerseroan40201026409101481(SuryaDarmaPerkasa).pdf', 1, '', '', '', 'Elza Widyasari', 'Lidia', 1, 'Jl. Daan Mogot, Jakarta Barat', 50000, '', '09:08', '14:02', '17:24', 1, '14:01', '1603713692-AHUSuryaDarmaP261020.pdf', 'LS', ''),
(127, 'Putri Pramesti Tiarma', 'PT. Ekamas International Hospital', '', 'cluster_lidia@bca.co.id', 'Perpanjangan Fasilitas,', 'Lengkap', '16-06-2020', 'Notaris', 'Eni Nuraini', '', '04-11-2020', 1, 1, '1604998077-PT.EKAMASINTERNATIONALHOSPITAL.pdf', 1, '', '', '', 'Rian Setiawan', 'Elza Widyasari', 1, 'Jl. Soekarno Hatta KM 6.5, Pekanbaru, Riau', 500000, '', '08:21', '10:42', '07:42', 1, '11:14', '1604481281-AHUonline0411207voucher.pdf', 'LS', ''),
(128, 'Putri Pramesti Tiarma', 'PT. Pelita Reliance International Hospital', '', 'cluster_lidia@bca.co.id', 'Perpanjangan Fasilitas,', 'Lengkap', '10-06-2020', 'Notaris', 'Eni Nuraini', '', '04-11-2020', 1, 1, '1604998110-PT.PELITARELIANCEINTERNATIONALHOSPITAL.pdf', 1, '', '', '', 'Rian Setiawan', 'Elza Widyasari', 1, 'Central Business District Lot IX, Bumi Serpong Damai City, Kota Tangerang Selatan', 500000, '', '08:21', '10:42', '07:42', 1, '11:14', '1604481414-AHUonline0411207voucher.pdf', 'EW', ''),
(129, 'Hizkia Ignatius Tambun', 'PT. Royal Pasifik Mandala', '', 'cluster_lidia@bca.co.id', 'Perpanjangan Fasilitas,', 'Terakhir', '', '', 'Eni Nuraini', '', '04-11-2020', 1, 1, '1604998127-PT.ROYALPASIFIKMANDALA.pdf', 1, '', '', '', 'Rian Setiawan', 'Elza Widyasari', 1, 'Jl. Royal Pasifik Mandala', 50000, '', '09:21', '10:42', '08:57', 1, '16:14', '1604481315-AHUonline0411207voucher.pdf', 'EW', ''),
(131, 'Merina Annisa Noviani', 'PT Kiat Ananda Coldstorage', '', 'cluster_lidia@bca.co.id', 'Lain - Lain,restruktur', 'Terakhir', '10-03-2020', 'Notaris', 'Eni Nuraini', '', '04-11-2020', 1, 1, '1604998146-PT.KIATANANDACOLDSTORAGE.pdf', 1, '', '', '', 'Rian Setiawan', 'Elza Widyasari', 1, 'alamat : Jl Raya Narogong, Cikiwul, Bantargebang - Bekasi', 50000, '', '09:50', '10:43', '09:48', 1, '11:17', '1604481486-AHUonline0411207voucher.pdf', 'EW', ''),
(132, 'Merina Annisa Noviani', 'PT Manggala Kiat Ananda', '', 'cluster_lidia@bca.co.id', 'Lain - Lain,restruktur - covid', 'Terakhir', '10-03-2020', 'Notaris', 'Eni Nuraini', '', '04-11-2020', 1, 1, '1604998161-PT.MANGGALAKIATANANDA.pdf', 1, '', '', '', 'Rian Setiawan', 'Elza Widyasari', 1, 'alamat : Jl Teluk Gong Raya Komplek Duta Indah Square Jakarta Utara', 50000, '', '09:50', '10:43', '09:48', 1, '11:17', '1604481517-AHUonline0411207voucher.pdf', 'EW', ''),
(133, 'Merina Annisa Noviani', 'PT Ananda Solusindo', '', 'cluster_lidia@bca.co.id', 'Lain - Lain,restruktur - covid', 'Terakhir', '10-03-2020', 'Notaris', 'Eni Nuraini', '', '04-11-2020', 1, 1, '1604998181-PT.ANANDASOLUSINDO40201104409104044.pdf', 1, '', '', '', 'Rian Setiawan', 'Elza Widyasari', 1, 'alamat : Jl Raya Narogong Km 9 Kab Bogor', 50000, '', '09:50', '10:43', '09:48', 1, '11:17', '1604481562-AHUonline0411207voucher.pdf', 'EW', ''),
(134, 'Caecilia Novadena', 'PT Agro Pratama', '', 'caecilia_novadena@bca.co.id', 'Lain - Lain,Debitur Baru', 'Lengkap', '', '', 'Eni Nuraini', '', '04-11-2020', 1, 1, '1604998204-PT.AGROPRATAMA40201104409104053.pdf', 1, '', '', '', 'Rian Setiawan', 'Nyimas Wida', 1, '-Alamat : GD Sapta Mulia Centre Jl. Rawa Gelam V, Kawasan Industri Pulogadung Blok OR No. 3B,Jatinegara Cakung, Jakarta Timur', 500000, '', '10:05', '10:43', '10:02', 1, '11:17', '1604481583-AHUonline0411207voucher.pdf', 'NW', ''),
(135, 'Putri Pramesti Tiarma', 'PT. Panin Sekuritas Tbk', '', 'cluster_lidia@bca.co.id', 'Perpanjangan Fasilitas,', 'Terakhir', '03-12-2018', 'SLK', 'Eni Nuraini', '', '06-11-2020', 1, 1, '1604998220-PT.PANINSEKURITAS40201106409105171.pdf', 1, '', '', '', 'Rian Setiawan', 'Elza Widyasari', 1, 'Bursa Efek Indonesia Tower II Lt. 17, Jl. Jend Sudirman kav 52-53', 50000, '', '09:32', '10:43', '08:16', 1, '16:13', '1604672034-AHUPaninSekuritas061120.pdf', 'EW', ''),
(136, 'Monika Istiana Dewi', 'PT BANGUNAN JAYA PERKASA', '', 'cluster_dewi@bca.co.id', 'Perpanjangan Fasilitas,', 'Terakhir', '15-11-2019', 'KCK', 'Eni Nuraini', '', '09-11-2020', 1, 1, '1605013390-PT.BANGUNANJAYAPERKASA40201110409106260.pdf', 1, '', '', '', 'Rian Setiawan', 'Dewi Virgina', 1, '', 50000, '', '07:54', '14:41', '11:20', 1, '14:37', '1605011924-AHUPTBangunan10112020.pdf', 'DV', ''),
(137, 'Putri Pramesti Tiarma', 'PT. BCA Sekuritas', '', 'cluster_lidia@bca.co.id', 'Perpanjangan Fasilitas,', 'Terakhir', '11-12-2018', 'KCK', 'Eni Nuraini', '', '10-11-2020', 1, 1, '1605013407-PT.BCASEKURITAS40201110409106275.pdf', 1, '', '', '', 'Rian Setiawan', 'Elza Widyasari', 1, 'Menara BCA, Grand Indonesia lantai 41, Jl. MH. Thamrin No. 1', 50000, '', '07:54', '14:41', '07:49', 1, '14:38', '1605011959-AHU4voucher10112020.pdf', 'EW', ''),
(138, 'Putri Pramesti Tiarma', 'PT. BNI Sekuritas', '', 'cluster_lidia@bca.co.id', 'Perpanjangan Fasilitas,', 'Terakhir', '04-12-2018', 'KCK', 'Eni Nuraini', '', '10-11-2020', 1, 1, '1605252002-PT.BNISEKURITAS40201113409107638.pdf', 1, '', '', '', 'Rian Setiawan', 'Elza Widyasari', 1, 'Sudirman Plaza, Indoffod Tower Lantai 16, Jl. Jend Sudirman Kav 76-78, Jakarta Pusat', 50000, '', '07:54', '14:41', '07:51', 1, '14:39', '1605011989-AHU4voucher10112020.pdf', 'EW', ''),
(139, 'Hanindha Putri Hardannie', 'PT Finusolprima Farma International', '', 'cluster_lidia@bca.co.id', 'Perpanjangan Fasilitas,', 'Terakhir', '28-08-2018', 'KCK', 'Eni Nuraini', '', '10-11-2020', 1, 1, '1605013435-PTFINUSOLPRIMAFARMAINTERNATIONAL40201110409106274.pdf', 1, '', '', '', 'Rian Setiawan', 'Elza Widyasari', 1, 'Alamat : Jl. Raya Bekasi KM 28.5 Kawasan Industri Rawa Pasung, Kota Baru, Bekasi Barat', 50000, '', '07:54', '14:41', '07:51', 1, '14:39', '1605012014-AHU4voucher10112020.pdf', 'LS', ''),
(140, 'Vinsensia Givy Gisela', 'PT Lotus Andalan Sekuritas', '', 'cluster_lidia@bca.co.id', 'Perpanjangan Fasilitas,', 'Terakhir', '05-11-2018', 'KCK', 'Eni Nuraini', '', '10-11-2020', 1, 1, '1605013452-PT.LOTUSANDALANSEKURITAS40201110409106251.pdf', 1, '', '', '', 'Rian Setiawan', 'Elza Widyasari', 1, 'Wisma Keiai, Jl.jend Sudirman', 50000, '', '09:28', '14:41', '09:26', 1, '14:40', '1605012045-AHU4voucher10112020.pdf', 'EW', ''),
(141, 'Merlyn Halim', 'PT Destinasi Tirta Nusantara ', '', 'cluster_dewi@bca.co.id', 'Lain - Lain,Signing Restruktur bawah tangan', 'Terakhir', '28-11-2018', 'SLK', 'Eni Nuraini', '', '10-11-2020', 1, 1, '1605101491-PT.DESTINASITIRTANUSANTARA.pdf', 1, '', '', '', 'Rian Setiawan', 'Ona', 1, '', 50000, '', '15:11', '15:19', '14:23', 1, '15:18', '1605100755-AHUPTDestinasi111120.pdf', 'DV', ''),
(142, 'Nur Rahmah Hastiati', 'PT Gemilang Berlian Indah', '', 'cluster_lidia@bca.co.id', 'perpanjangan availibility period dan perubahan syarat', 'Terakhir', '04-01-2019', 'KCK', 'Eni Nuraini', '', '19-11-2020', 1, 1, '1606112596-PT.GEMILANGBERLIANINDAH.pdf', 1, '', '', '', 'Rian Setiawan', 'Lidia', 1, '', 50000, '', '08:07', '16:19', '08:05', 1, '16:33', '1605796475-AHUOnline191120.pdf', 'LS', ''),
(143, 'Nur Rahmah Hastiati', 'PT Pacific Area Jaya', '', 'cluster_lidia@bca.co.id', 'Lain - Lain,perpanjangan', 'Terakhir', '04-01-2021', 'KCK', 'Eni Nuraini', '', '19-11-2020', 1, 1, '1606112607-PT.PACIFICAREAJAYA.pdf', 1, '', '', '', 'Rian Setiawan', 'Lidia', 1, '', 50000, '', '08:07', '16:18', '08:05', 1, '16:35', '1605796537-AHUOnline191120.pdf', 'LS', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `msasli`
--

CREATE TABLE `msasli` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `username_op_mon1` varchar(255) DEFAULT NULL,
  `username_op_mon2` varchar(255) DEFAULT NULL,
  `transdate` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `norek` varchar(255) DEFAULT NULL,
  `nokom` varchar(255) DEFAULT NULL,
  `kategoridok` varchar(255) DEFAULT NULL,
  `namadok` varchar(255) DEFAULT NULL,
  `nomorjam` varchar(255) DEFAULT NULL,
  `tipedok` varchar(255) DEFAULT NULL,
  `nomordok` varchar(255) DEFAULT NULL,
  `tahundok` varchar(255) DEFAULT NULL,
  `fisikdok` varchar(255) DEFAULT NULL,
  `ketdok` varchar(1000) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `acc` varchar(255) DEFAULT NULL,
  `tanggaljan` varchar(255) DEFAULT NULL,
  `renewaldok` varchar(255) DEFAULT NULL,
  `detail` varchar(1000) DEFAULT NULL,
  `detailpik` varchar(1000) DEFAULT NULL,
  `filepik` varchar(255) DEFAULT NULL,
  `filecams` varchar(255) NOT NULL,
  `alkhcname` varchar(255) NOT NULL,
  `pic1name` varchar(255) DEFAULT NULL,
  `pic2name` varchar(255) DEFAULT NULL,
  `pikhcname` varchar(255) DEFAULT NULL,
  `pikhcname2` varchar(255) DEFAULT NULL,
  `alkop` varchar(255) DEFAULT NULL,
  `alkhc` varchar(255) NOT NULL DEFAULT '1',
  `pikop` varchar(255) DEFAULT NULL,
  `pikhc1` varchar(255) DEFAULT NULL,
  `pikhc2` varchar(255) DEFAULT NULL,
  `alkopdate` varchar(255) NOT NULL,
  `pikopdate` varchar(255) NOT NULL,
  `flagrejected` varchar(255) DEFAULT NULL,
  `flagrejectedpik` varchar(255) DEFAULT NULL,
  `flagpiktoalk` int(11) DEFAULT NULL,
  `pikprogress` varchar(255) NOT NULL,
  `typeextra` varchar(255) DEFAULT NULL,
  `comreject` varchar(255) DEFAULT NULL,
  `waktu` varchar(255) DEFAULT NULL,
  `diserahkan` int(11) DEFAULT NULL,
  `clusterhold` varchar(255) DEFAULT NULL,
  `tgldiserahkan` varchar(255) DEFAULT NULL,
  `waktualk` varchar(255) DEFAULT NULL,
  `waktucams` varchar(255) NOT NULL,
  `waktuasli` varchar(255) NOT NULL,
  `pikhc3` varchar(255) DEFAULT NULL,
  `reminder` int(5) DEFAULT '0',
  `reminderdate` varchar(255) DEFAULT NULL,
  `lokasibg` varchar(255) DEFAULT NULL,
  `rekgiro` varchar(255) DEFAULT NULL,
  `adminis` varchar(255) DEFAULT NULL,
  `komisi` varchar(255) DEFAULT NULL,
  `bataswaktu` varchar(255) DEFAULT NULL,
  `oldid` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `msasli`
--

INSERT INTO `msasli` (`id`, `username`, `username_op_mon1`, `username_op_mon2`, `transdate`, `company`, `norek`, `nokom`, `kategoridok`, `namadok`, `nomorjam`, `tipedok`, `nomordok`, `tahundok`, `fisikdok`, `ketdok`, `file`, `acc`, `tanggaljan`, `renewaldok`, `detail`, `detailpik`, `filepik`, `filecams`, `alkhcname`, `pic1name`, `pic2name`, `pikhcname`, `pikhcname2`, `alkop`, `alkhc`, `pikop`, `pikhc1`, `pikhc2`, `alkopdate`, `pikopdate`, `flagrejected`, `flagrejectedpik`, `flagpiktoalk`, `pikprogress`, `typeextra`, `comreject`, `waktu`, `diserahkan`, `clusterhold`, `tgldiserahkan`, `waktualk`, `waktucams`, `waktuasli`, `pikhc3`, `reminder`, `reminderdate`, `lokasibg`, `rekgiro`, `adminis`, `komisi`, `bataswaktu`, `oldid`) VALUES
(1, 'Claudio Ucandra Negara', NULL, NULL, '29-10-2019', 'PT. Plasindo Lestari', '035-900-6448', '002', 'JAMINAN', 'Pernyataan direksi/RUPS penyerahan Asset', '51855575', 'Asli', '', '2019', 'Hardcopy', '', '', NULL, '', '', NULL, NULL, '', '', '', 'Teguh Waspada', 'Adi Fajar', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '187'),
(2, 'Claudio Ucandra Negara', NULL, NULL, '29-10-2019', 'PT. Caturkarsa Megatunggal', '205-900-4802', '001', 'PINJAMAN', 'LKK (Lembar Keputusan Kredit) / MPK / MEMORANDUM', '', 'Asli', '1097/MO/SKI/2019', '2019', 'Hardcopy', '', '', NULL, '', '', NULL, NULL, '', '', '', 'Adi Fajar', 'Keren Hapukh', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '188'),
(3, 'Claudio Ucandra Negara', NULL, NULL, '29-10-2019', 'PT. Indonesia Nanya Indah Plastics', '009-901-6185', '001', 'PINJAMAN', 'Addendum / Perubahan Perjanjian Kredit', '', 'Asli', '353/ADD-KCK/2019', '2019', 'Hardcopy', '', '', NULL, '', '', NULL, NULL, '', '', '', 'Keren Hapukh', 'Teguh Waspada', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '189'),
(4, 'Claudio Ucandra Negara', NULL, NULL, '29-10-2019', 'PT. Indonesia Nanya Indah Plastics', '009-901-6185', '001', 'PINJAMAN', 'SPPK', '', 'Asli', '10753/GBK/2019', '2019', 'Hardcopy', '', '', NULL, '', '', NULL, NULL, '', '', '', 'Keren Hapukh', 'Teguh Waspada', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '189'),
(5, 'Claudio Ucandra Negara', NULL, NULL, '29-10-2019', 'PT. Indonesia Nanya Indah Plastics', '009-901-6185', '001', 'PINJAMAN', 'LKK (Lembar Keputusan Kredit) / MPK / MEMORANDUM', '', 'Asli', '1087/MO/SKI/2019', '2019', 'Hardcopy', '', '', NULL, '', '', NULL, NULL, '', '', '', 'Keren Hapukh', 'Teguh Waspada', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '189'),
(6, 'Claudio Ucandra Negara', NULL, NULL, '29-10-2019', 'PT. Satyamitra Kemas Lestari', '035-909-3634', '011', 'PINJAMAN', 'Surat kuasa penanda tanganan kredit', '', 'Asli', '05746/MBA/2019', '2019', 'Hardcopy', '', '', NULL, '', '', NULL, NULL, '', '', '', 'Teguh Waspada', 'Adi Fajar', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '190'),
(7, 'Claudio Ucandra Negara', NULL, NULL, '29-10-2019', 'PT. Satyamitra Kemas Lestari', '035-909-3634', '011', 'JAMINAN', 'Pernyataan direksi/RUPS penyerahan Asset', '6201172', 'Asli', '', '2019', 'Hardcopy', '', '', NULL, '', '', NULL, NULL, '', '', '', 'Teguh Waspada', 'Adi Fajar', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '190'),
(8, 'Claudio Ucandra Negara', NULL, NULL, '29-10-2019', 'PT. Satyamitra Kemas Lestari', '035-909-3634', '011', 'PINJAMAN', 'Addendum / Perubahan Perjanjian Kredit', '', 'Asli', '350/ADD-KCK/2019', '2019', 'Hardcopy', '', '', NULL, '', '', NULL, NULL, '', '', '', 'Teguh Waspada', 'Adi Fajar', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '190'),
(9, 'Claudio Ucandra Negara', NULL, NULL, '29-10-2019', 'PT. Haldin Pacific Semesta', '205-900-9901', '001', 'PINJAMAN', 'Surat Persetujuaan RUPS untuk Perjanjian Kredit', '36040046', 'Asli', '', '2019', 'Hardcopy', '', '', NULL, '', '', NULL, NULL, '', '', '', 'Keren Hapukh', 'Teguh Waspada', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '191'),
(10, 'Claudio Ucandra Negara', NULL, NULL, '29-10-2019', 'PT. Haldin Pacific Semesta', '205-900-9901', '001', 'PINJAMAN', 'Surat Persetujuaan RUPS untuk Perjanjian Kredit', '36040046', 'Asli', '', '2019', 'Hardcopy', '', '', NULL, '', '', NULL, NULL, '', '', '', 'Keren Hapukh', 'Teguh Waspada', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '191'),
(11, 'Claudio Ucandra Negara', NULL, NULL, '29-10-2019', 'PT. Haldin Pacific Semesta', '205-900-9901', '001', 'JAMINAN', 'Daftar Mesin/ Surat Pernyataan Mesin', '51747566', 'Asli', '01/FIN/IX/2019', '2019', 'Hardcopy', '', '', NULL, '', '', NULL, NULL, '', '', '', 'Keren Hapukh', 'Teguh Waspada', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '191'),
(12, 'Claudio Ucandra Negara', NULL, NULL, '29-10-2019', 'PT. Chandra Asri Petrochemical', '205-900-6881', '001', 'PINJAMAN', 'SPPJS (Surat pemberitahuan Ppj Sementara)', '', 'Asli', '10780/GBK/2019', '2019', 'Hardcopy', '', '', NULL, '', '', NULL, NULL, '', '', '', 'Adi Fajar', 'Keren Hapukh', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '203'),
(13, 'Claudio Ucandra Negara', NULL, NULL, '29-10-2019', 'PT. TRIAS SENTOSA Tbk', '0359006189', '001', 'PINJAMAN', 'LKK (Lembar Keputusan Kredit) / MPK / MEMORANDUM', '', 'Asli', '1149/MO/SKI/2019', '2019', 'Hardcopy', '', '', NULL, '', '', NULL, NULL, '', '', '', 'Teguh Waspada', 'Adi Fajar', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '237'),
(14, 'Claudio Ucandra Negara', NULL, NULL, '29-10-2019', 'PT. TRIAS SENTOSA Tbk', '0359006189', '001', 'PINJAMAN', 'SPPJS (Surat pemberitahuan Ppj Sementara)', '', 'Asli', '10772/GBK/2019', '2019', 'Hardcopy', '', '', NULL, '', '', NULL, NULL, '', '', '', 'Teguh Waspada', 'Adi Fajar', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '155'),
(15, 'Finda Ariesta Mulia', NULL, NULL, '29-10-2019', 'PT Mulia Karyagemilang', '', '', 'PINJAMAN', 'Surat Pernyataan dari Debitur Terkait Pinjaman', '', 'Asli', '', '2019', 'Hardcopy', 'Surat Pernyataan Debitur tgl 11.10.19 terkait realisasi KI 2', '', NULL, '', '', NULL, NULL, '', '', '', 'Keren Hapukh', 'Teguh Waspada', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '215'),
(16, 'Finda Ariesta Mulia', NULL, NULL, '29-10-2019', 'PT. Summarecon Agung', '227-900-003-4 (KL) ; 035-900-513-1 (KI, TL, BG) ; 205-900-923-5 (KMF Grup - BG)', '001 ; 005, 008, 009 ; 001', 'PINJAMAN', 'LKK (Lembar Keputusan Kredit) / MPK / MEMORANDUM', '', 'Asli', '30276/MO/GBK/2019 tgl 16-10-2019', '2019', 'Hardcopy', 'Memorandum penegasan ulang keputusan MPK No. 0751/MO/SKI/2019 tgl 17-07-2019 ', '', NULL, '', '', NULL, NULL, '', '', '', 'Teguh Waspada', 'Adi Fajar', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '210'),
(17, 'Finda Ariesta Mulia', NULL, NULL, '29-10-2019', 'PT. Summarecon Agung', '227-900-003-4 (KL) ; 035-900-513-1 (KI, TL, BG) ; 205-900-923-5 (KMF Grup - BG)', '001 ; 005, 008, 009 ; 001', 'PINJAMAN', 'LKK (Lembar Keputusan Kredit) / MPK / MEMORANDUM', '', 'Asli', '30277/MO/GBK/2019 tgl 16-10-2019', '2019', 'Hardcopy', 'Memorandum perubahan struktur agunan dan penerbitan obligasi ', '', NULL, '', '', NULL, NULL, '', '', '', 'Teguh Waspada', 'Adi Fajar', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '210'),
(18, 'Finda Ariesta Mulia', NULL, NULL, '29-10-2019', 'PT. Altrak 1978', '035-930-343-3 ; 319-090-343-4', '004', 'PINJAMAN', 'Surat Kuasa Transaksi (PBMM/Forex/Ekspor/Impor)', '', 'Asli', 'Legalisasi Nomor : 169/L/X/2019 tgl 23-10-2019 (Notaris Sri Buena Brahmana, SH., M.Kn.)', '2019', 'Hardcopy', 'Surat kuasa transaksi KMF (LC, BG) ', '', NULL, '', '', NULL, NULL, '1572507521-SPA232019YGSUDAHTTD.pdf', '', '', 'Adi Fajar', 'Keren Hapukh', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '208'),
(19, 'Finda Ariesta Mulia', NULL, NULL, '29-10-2019', 'CV. Perjuangan Steel', '010-907-360-3 (KL, KMF) ; 205-900-945-6 (KI, Forex)', '001, 002', 'PINJAMAN', 'LKK (Lembar Keputusan Kredit) / MPK / MEMORANDUM', '', 'Asli', '1023/MO/SKI/2019 tgl 20-09-2019', '2019', 'Hardcopy', '', '', NULL, '', '', NULL, NULL, '', '', '', 'Teguh Waspada', 'Adi Fajar', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '211'),
(20, 'Finda Ariesta Mulia', NULL, NULL, '29-10-2019', 'CV. Perjuangan Steel', '010-907-360-3 (KL, KMF) ; 205-900-945-6 (KI, Forex)', '001, 002', 'JAMINAN', 'Daftar Mesin/ Surat Pernyataan Mesin', '48708770', 'Asli', '0851/PS/B-BCA/X/2019 tgl 23-10-2019', '2019', 'Hardcopy', '(*) Renewal : 2 tahunan', '1572267683-REDokurdandraftdaftarmesin.msg', NULL, '', '', NULL, NULL, '', '', '', 'Teguh Waspada', 'Adi Fajar', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '211'),
(21, 'Finda Ariesta Mulia', NULL, NULL, '29-10-2019', 'PT. Serpong Cipta Kreasi', '883-090-015-3 (KL) ; 035-900-635-9 (KI, TL)', '001 ; 001, 002, 003, 005, 004', 'PINJAMAN', 'SPPK', '', 'Asli', '30433/GBK/2019 tgl 24-09-2019', '2019', 'Hardcopy', '', '', NULL, '', '', NULL, NULL, '', '', '', 'Keren Hapukh', 'Teguh Waspada', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '212'),
(22, 'Finda Ariesta Mulia', NULL, NULL, '29-10-2019', 'PT. Lestari Mahadibya', '035-900-808-4', '002, 003, 004, 008', 'PINJAMAN', 'PPBG (Perjanjian Pemberian Bank Garansi)', '', 'Asli', '205.365.2019 tgl 25-10-2019', '2019', 'Hardcopy', '', '', NULL, '', '', NULL, NULL, '', '', '', 'Teguh Waspada', 'Adi Fajar', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '219'),
(23, 'Finda Ariesta Mulia', NULL, NULL, '29-10-2019', 'PT. Lestari Mahadibya', '035-900-808-4', '002, 003, 004, 008', 'JAMINAN', 'Perjanjian Gadai', '51907350', 'Asli', '046 tgl 25-10-2019', '2019', 'Hardcopy', '', '', NULL, '', '', NULL, NULL, '', '', '', 'Teguh Waspada', 'Adi Fajar', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '219'),
(24, 'Finda Ariesta Mulia', NULL, NULL, '29-10-2019', 'PT. Lestari Mahadibya', '035-900-808-4', '002, 003, 004, 008', 'PINJAMAN', 'Surat persetujuan Komisaris', '', 'Asli', 'Legalisasi Nomor : 3680/Leg/X/2019 tgl 17-10-2019 (Notaris Dewi Himijati Tandika, S.H.)', '2019', 'Hardcopy', '', '', NULL, '', '', NULL, NULL, '', '', '', 'Teguh Waspada', 'Adi Fajar', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '219'),
(25, 'Finda Ariesta Mulia', NULL, NULL, '29-10-2019', 'PT. Lestari Mahadibya', '035-900-808-4', '002, 003, 004, 008', 'JAMINAN', 'Surat persetujuan RUPS', '51907350', 'Asli', 'Legalisasi Nomor : 3681/Leg/X/2019 tgl 17-10-2019 (Notaris Dewi Himijati Tandika, S.H.)', '2019', 'Hardcopy', 'Surat pernyataan menjaminkan aset sebagian kecil ', '', NULL, '', '', NULL, NULL, '', '', '', 'Teguh Waspada', 'Adi Fajar', 'Choose Head Cluster', NULL, '1', '1', '1', '0', '0', '', '', '0', '0', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '219');

-- --------------------------------------------------------

--
-- Struktur dari tabel `msasuransi`
--

CREATE TABLE `msasuransi` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `transdate` varchar(255) NOT NULL,
  `penyerahanbaru` int(11) NOT NULL,
  `nonaktifpolis` int(11) NOT NULL,
  `endorsement` int(11) NOT NULL,
  `renewalpolis` int(11) NOT NULL,
  `covernoteasuransi` int(11) NOT NULL,
  `buktibayarpremi` int(11) NOT NULL,
  `debitur` varchar(255) NOT NULL,
  `tanggalTerimaDokumen1` varchar(255) DEFAULT NULL,
  `namadok1` varchar(255) DEFAULT NULL,
  `periodakhir1` varchar(255) DEFAULT NULL,
  `polisebelum1` varchar(2555) DEFAULT NULL,
  `fisikdokumen1` varchar(255) DEFAULT NULL,
  `fisikdokumennon1` varchar(5000) NOT NULL,
  `ket1` varchar(255) DEFAULT NULL,
  `nodok1` varchar(2555) NOT NULL,
  `nomorjaminan` varchar(255) NOT NULL,
  `nilaipertanggungan1` varchar(255) NOT NULL,
  `slkopname` varchar(255) NOT NULL,
  `slkhcname` varchar(255) NOT NULL,
  `monopname1` varchar(255) DEFAULT NULL,
  `monopname2` varchar(255) DEFAULT NULL,
  `monhcname` varchar(255) NOT NULL,
  `asliopname1` varchar(255) NOT NULL,
  `asliopname2` varchar(255) NOT NULL,
  `aslihcname` varchar(255) NOT NULL,
  `alkhc` int(11) NOT NULL,
  `monop` int(11) NOT NULL,
  `monhc` int(11) NOT NULL,
  `asliop` int(11) NOT NULL,
  `aslihc` int(11) NOT NULL,
  `alkhcdate` varchar(255) NOT NULL,
  `monopdate` varchar(255) NOT NULL,
  `inputmondate` varchar(255) NOT NULL,
  `monhcdate` varchar(255) NOT NULL,
  `asliopdate` varchar(255) NOT NULL,
  `aslihcdate` varchar(255) NOT NULL,
  `pikopWSA` varchar(255) NOT NULL,
  `asliopWSAdate` varchar(255) NOT NULL,
  `commentreject` varchar(255) DEFAULT NULL,
  `recordrejected` int(11) NOT NULL,
  `bap1` varchar(255) NOT NULL,
  `inputmon` int(5) NOT NULL,
  `inputmonName` varchar(255) NOT NULL,
  `terimaDokumen` int(5) NOT NULL,
  `terimaDokumendate` varchar(255) NOT NULL,
  `terimaDokumen1` int(5) NOT NULL,
  `terimaDokumendate1` varchar(255) NOT NULL,
  `bc` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `msasuransi`
--

INSERT INTO `msasuransi` (`id`, `username`, `transdate`, `penyerahanbaru`, `nonaktifpolis`, `endorsement`, `renewalpolis`, `covernoteasuransi`, `buktibayarpremi`, `debitur`, `tanggalTerimaDokumen1`, `namadok1`, `periodakhir1`, `polisebelum1`, `fisikdokumen1`, `fisikdokumennon1`, `ket1`, `nodok1`, `nomorjaminan`, `nilaipertanggungan1`, `slkopname`, `slkhcname`, `monopname1`, `monopname2`, `monhcname`, `asliopname1`, `asliopname2`, `aslihcname`, `alkhc`, `monop`, `monhc`, `asliop`, `aslihc`, `alkhcdate`, `monopdate`, `inputmondate`, `monhcdate`, `asliopdate`, `aslihcdate`, `pikopWSA`, `asliopWSAdate`, `commentreject`, `recordrejected`, `bap1`, `inputmon`, `inputmonName`, `terimaDokumen`, `terimaDokumendate`, `terimaDokumen1`, `terimaDokumendate1`, `bc`, `file`) VALUES
(22, 'Hindrawati', '04-2-2021', 0, 0, 1, 0, 0, 0, 'PT. Summarecon Agung', '', 'Endors|Endors|Endors|Endors', '31-03-2021												|31-03-2021												|31-03-2021												|31-03-2021												', '|||', 'Asli|Asli|Asli|Asli', '', 'Flexas (Penghapusan 10% dalam bankers clause)|EQ (Penghapusan 10% dalam bankers clause)|Flexas (Penghapusan 10% dalam bankers clause)|EQ (Penghapusan 10% dalam bankers clause)', '45013020009264												,45013220006391												,45013020009297												,45013220006425												', '28037265												,28037265												,37174927												,37174927												', '|||', 'Hindrawati', 'Dewi Virgina', 'Ni Putu Emy Indrayani', 'Florence', 'Cicilia Prima Widi Astuti', 'Olivia Santoso', 'Teguh Waspada', '', 1, 1, 1, 1, 0, '03-02-2021', '11-02-2021', '23-02-2021', '23-02-2021', '23-02-2021', '', '', '', NULL, 0, '|||', 1, 'Martanita Dika Puspita', 1, '04-02-2021', 0, '', '', '|||'),
(23, 'Hindrawati', '04-2-2021', 0, 0, 1, 0, 0, 0, 'PT. Permata Jimbaran Agung ; PT Hotelindo Permata Jimbaran', '', 'Endors|Endors', '31-03-2021						|31-03-2021						', '|', 'Asli|Asli', '', 'Flexas (Penghapusan 10% dalam bankers clause)|EQ (Penghapusan 10% dalam bankers clause)', '45013020009311						|45013220006447						', '23904345						|23904345						', '|', 'Hindrawati', 'Dewi Virgina', 'Ni Putu Emy Indrayani', 'Florence', 'Cicilia Prima Widi Astuti', 'Olivia Santoso', 'Teguh Waspada', '', 1, 1, 1, 1, 0, '03-02-2021', '11-02-2021', '23-02-2021', '23-02-2021', '26-02-2021', '', '', '', NULL, 0, '|', 1, 'Martanita Dika Puspita', 1, '04-02-2021', 0, '', '', '|'),
(30, 'Merina Annisa Noviani', '08-2-2021', 1, 0, 1, 0, 0, 0, 'PT Arista Jaya Lestari', '', 'Polis|Endors', '02-03-2021						|02-03-2021						', 'NEW|NEW', 'Asli|Asli', '', 'nilai BAP menggunakan nilai RAB karena appraisal belum ada, buat dokur peningkatan nilai pertanggungan asuransi minimal Rp 6,8 M|', '01-PAR-00024-000-03-2020						|01-PAR-00024-000-03-2020/01						', '52369311						|52369311						', 'Rp 5.500.000.000|', 'Merina Annisa Noviani', 'Elza Widyasari', 'Ni Putu Emy Indrayani', 'Florence', 'Cicilia Prima Widi Astuti', 'Olivia Santoso', 'Adi Fajar', '', 1, 1, 1, 3, 0, '08-02-2021', '16-02-2021', '24-02-2021', '24-02-2021', '24-02-2021', '', 'Adi Fajar', '15-04-2021', ' ,by: Elza Widyasari', 1, 'Rp. 6.800.000.000|', 1, 'Martanita Dika Puspita', 1, '08-02-2021', 0, '', '0|1', '|'),
(31, 'Ni Putu Emy Indrayani', '08-2-2021', 1, 0, 0, 0, 0, 0, 'PT Karangjuang Hijau Lestari', '28-12-2020', 'Polis', '', '', 'Asli', '', '', '12.000.0001.95919', '', '', 'Inputted by Monitoring', 'Inputted by Monitoring', 'Ni Putu Emy Indrayani', 'Ni Putu Emy Indrayani', 'Cicilia Prima Widi Astuti', 'Olivia Santoso', 'Keren Hapukh', '', 1, 1, 1, 1, 0, '', '', '19-02-2021', '19-02-2021', '19-02-2021', '', '', '', NULL, 0, '', 1, 'Kania Nurbaiti', 0, '', 0, '', '', ''),
(32, 'Ni Putu Emy Indrayani', '08-2-2021', 1, 0, 0, 0, 0, 0, 'PT Bhumi Simanggaris Indah', '28-12-2020', 'Polis', '', '', 'Asli', '', '', '12.000.0001.95922', '', '', 'Inputted by Monitoring', 'Inputted by Monitoring', 'Ni Putu Emy Indrayani', 'Ni Putu Emy Indrayani', 'Cicilia Prima Widi Astuti', 'Olivia Santoso', 'Keren Hapukh', '', 1, 1, 1, 1, 0, '', '', '19-02-2021', '19-02-2021', '19-02-2021', '', '', '', NULL, 0, '', 1, 'Kania Nurbaiti', 0, '', 0, '', '', ''),
(33, 'Ni Putu Emy Indrayani', '08-2-2021', 1, 0, 0, 0, 0, 0, 'PT Bulungan Hijau Perkasa ', '28-12-2020', 'Polis', '', '', 'Asli', '', '', '12.000.0001.95923', '', '', 'Inputted by Monitoring', 'Inputted by Monitoring', 'Ni Putu Emy Indrayani', 'Ni Putu Emy Indrayani', 'Cicilia Prima Widi Astuti', 'Olivia Santoso', 'Keren Hapukh', '', 1, 1, 1, 1, 0, '', '', '19-02-2021', '19-02-2021', '19-02-2021', '', '', '', NULL, 0, '', 1, 'Kania Nurbaiti', 0, '', 0, '', '', ''),
(34, 'Ni Putu Emy Indrayani', '08-2-2021', 1, 0, 0, 0, 0, 0, 'PT Tirta Madu Sawit Jaya', '28-12-2020', 'Polis', '', '', 'Asli', '', '', '12.000.0001.95729', '', '', 'Inputted by Monitoring', 'Inputted by Monitoring', 'Ni Putu Emy Indrayani', 'Ni Putu Emy Indrayani', 'Cicilia Prima Widi Astuti', 'Olivia Santoso', 'Keren Hapukh', '', 1, 1, 1, 1, 0, '', '', '19-02-2021', '19-02-2021', '19-02-2021', '', '', '', NULL, 0, '', 1, 'Kania Nurbaiti', 0, '', 0, '', '', ''),
(35, 'Leonhard Bianda', '10-2-2021', 0, 0, 0, 1, 0, 0, 'PT Borneo Bhakti Sejahtera', '', 'Polis|Polis', '31-10-2021						|31-10-2021						', '0124011901483|0124011901415', 'Asli|Asli', '', 'bankers clause BCA >15%|bankers clause BCA >15%', '12.100.0000.10508						|12.100.0000.10519						', '34026070						|34026070						', '214.000.000.000|214.000.000.000', 'Leonhard Bianda', 'Mega Febrilia', 'Ni Putu Emy Indrayani', 'Florence', 'Ona', 'Olivia Santoso', 'Keren Hapukh', '', 1, 1, 1, 1, 0, '11-02-2021', '16-03-2021', '23-03-2021', '23-03-2021', '23-03-2021', '', 'Keren Hapukh', '', NULL, 0, '22.144.000.000|22.144.000.000', 1, 'Martanita Dika Puspita', 1, '17-02-2021', 1, '16-03-2021', '1|1', '|'),
(39, 'Bertha Elita Hia', '09-2-2021', 1, 0, 1, 0, 0, 1, 'PT. Catur Mitra Sejati Sentosa', '', 'Endors|Endors|Bukti Bayar', '31/12/2021						|31/12/2021						|-						', '-|-|-', 'Asli|Asli|Asli', '', 'Endors PAR, berkaitan dengan polis no: 022.4050.201.2020.001277.03|Endors EQ, berkaitan dengan polis no: 022.4050.202.2020.000257.03|Bukti bayar atas endors PAR dan EQ', '03						|03						|02852						', '52609013						|52609013						|52609013						', '17000000000|17000000000|-', 'Bertha Elita Hia', 'Dewi Virgina', 'Florence', 'Ni Putu Emy Indrayani', 'Cicilia Prima Widi Astuti', 'Olivia Santoso', 'Adi Fajar', '', 1, 1, 1, 3, 0, '09-02-2021', '16-02-2021', '23-02-2021', '25-02-2021', '26-02-2021', '', 'Adi Fajar', '15-04-2021', NULL, 0, '16479530000|16479530000|-', 1, 'Martanita Dika Puspita', 1, '09-02-2021', 0, '', '1|1', '||'),
(42, 'Florence', '09-2-2021', 0, 0, 0, 1, 0, 0, 'PT Agung Transina Raya', '14-01-2021|14-01-2021', 'Polis|Polis', '', 'D-2019-00668/000935/B/CWRI/ASM/VIII/2019|D-2019-00667/000934/B/CWRI/ASM/VIII/2019', 'Copy|Copy', '', 'P&I |P&I', 'A-2020-01270						|A-2020-01239						', '', '', 'Inputted by Monitoring', 'Inputted by Monitoring', 'Florence', 'Florence', 'Cicilia Prima Widi Astuti', 'Olivia Santoso', 'Adi Fajar', '', 1, 1, 1, 3, 0, '', '', '09-03-2021', '09-03-2021', '09-03-2021', '', 'Adi Fajar', '15-04-2021', 'Edit Tanggal ,by: Martanita Dika Puspita', 1, '', 1, 'Martanita Dika Puspita', 0, '', 1, '04-03-2021', '', ''),
(43, 'Florence', '09-2-2021', 0, 0, 0, 0, 0, 1, 'Catur Mitra Sejati Sentosa', '08-02-2021|08-02-2021', 'Bukti Bayar|Bukti Bayar', '', '-|-', 'Copy|Copy', '', 'Email Bu Merry tgl. 08-02-2021|Email Bu Merry tgl. 08-02-2021', '022.4050.201.2020.001277.00 												|022.4050.202.2020.000257.00 												', '', '', 'Inputted by Monitoring', 'Inputted by Monitoring', 'Florence', 'Florence', 'Cicilia Prima Widi Astuti', 'Olivia Santoso', 'Adi Fajar', '', 1, 1, 1, 2, 0, '', '', '23-02-2021', '27-05-2021', '27-05-2021', '', '', '', 'DOKUMEN SOFTCOPY. FISIK TIDAK DITERIMA OLEH PIC ASLI ,by: Olivia Santoso', 1, '', 1, 'Martanita Dika Puspita', 0, '', 0, '', '', ''),
(44, 'Florence', '09-2-2021', 0, 0, 0, 0, 0, 1, 'Catur Sentosa Anugerah', '08-02-2021|08-02-2021|08-02-2021|08-02-2021|08-02-2021|08-02-2021', 'Bukti Bayar|Bukti Bayar|Bukti Bayar|Bukti Bayar|Bukti Bayar|Bukti Bayar', '', '|||||', 'Copy|Copy|Copy|Copy|Copy|Copy', '', 'Lunas; Email Bu Febiola tgl. 08-02-2021|Lunas; Email Bu Febiola tgl. 08-02-2021|Lunas; Email Bu Febiola tgl. 08-02-2021|Lunas; Email Bu Febiola tgl. 08-02-2021|Lunas; Email Bu Febiola tgl. 08-02-2021|Lunas; Email Bu Febiola tgl. 08-02-2021', '022.4050.201.2020.001287.00 						|022.4050.202.2020.000265.00						|022.4050.201.2020.001272.00						|022.4050.202.2020.000251.00						|022.4050.201.2020.001271.00						|022.4050.202.2020.000250.00						', '', '', 'Inputted by Monitoring', 'Inputted by Monitoring', 'Florence', 'Florence', 'Cicilia Prima Widi Astuti', 'Olivia Santoso', 'Adi Fajar', '', 1, 1, 1, 2, 0, '', '', '23-02-2021', '27-05-2021', '27-05-2021', '', '', '', 'DOKUMEN SOFTCOPY. FISIK TIDAK DITERIMA OLEH PIC ASLI ,by: Olivia Santoso', 1, '', 1, 'Martanita Dika Puspita', 0, '', 0, '', '', ''),
(45, 'Florence', '09-2-2021', 1, 0, 0, 0, 0, 0, 'PT Adi Sarana Armada Tbk', '03-02-2021|03-02-2021|03-02-2021|03-02-2021|03-02-2021|03-02-2021|03-02-2021', 'Polis|Polis|Polis|Polis|Polis|Polis|Polis', '', '-|-|-|-|-|-|-', 'Asli|Asli|Asli|Asli|Asli|Asli|Asli', '', '||||||', '64022220000343  KI 11.1						|S090219000004  KI 11.1						|S090219000076  KI 11.1						|S090220000009  KI 11.1						|S090219000012  KI 11.1						|S090219000053  KI 11.1						|S090219000028  KI 11.1						', '', '', 'Inputted by Monitoring', 'Inputted by Monitoring', 'Florence', 'Florence', 'Cicilia Prima Widi Astuti', 'Olivia Santoso', 'Adi Fajar', '', 1, 1, 1, 3, 0, '', '', '23-02-2021', '25-02-2021', '26-02-2021', '', 'Adi Fajar', '15-04-2021', NULL, 0, '', 1, 'Martanita Dika Puspita', 0, '', 0, '', '', ''),
(46, 'Florence', '09-2-2021', 0, 0, 0, 0, 0, 1, 'PT Sekawan Intiperkasa', '04-02-2021|04-02-2021', 'Bukti Bayar|Bukti Bayar', '', '-|-', 'Asli|Asli', '', 'Sudah diinput, tinggal diserahkan ke asli, cek scan bukti bayar|Sudah diinput, tinggal diserahkan ke asli, cek scan bukti bayar', 'PUH2000261|PUH2000265', '', '', 'Inputted by Monitoring', 'Inputted by Monitoring', 'Florence', 'Florence', 'Cicilia Prima Widi Astuti', 'Olivia Santoso', 'Teguh Waspada', '', 1, 1, 1, 1, 0, '', '', '23-02-2021', '23-02-2021', '26-02-2021', '', '', '', NULL, 0, '', 1, 'Martanita Dika Puspita', 0, '', 0, '', '', ''),
(47, 'Florence', '09-2-2021', 0, 0, 0, 1, 0, 0, 'PT Bahtera Alam Sejahtera', '04-02-2021|04-02-2021|04-02-2021', 'Polis|Polis|Polis', '', '100040120010000013|100040120010000024|100040120010000035', 'Asli|Asli|Asli', '', '||', '100040121010000025|100040121010000036|100040121010000071', '', '', 'Inputted by Monitoring', 'Inputted by Monitoring', 'Florence', 'Florence', 'Cicilia Prima Widi Astuti', 'Olivia Santoso', 'Adi Fajar', '', 1, 1, 1, 3, 0, '', '', '23-02-2021', '23-02-2021', '23-02-2021', '', 'Adi Fajar', '15-04-2021', NULL, 0, '', 1, 'Martanita Dika Puspita', 0, '', 0, '', '', ''),
(48, 'Florence', '11-2-2021', 0, 0, 1, 1, 0, 0, 'Murni Sadar (Murni Teguh Memorial Hospital)', '05-02-2021|05-02-2021|05-02-2021|05-02-2021', 'Polis|Polis|Endors|Endors', '', '08.05.20.000013|25.05.20.000004||', 'Asli|Asli|Asli|Asli', '', '|||', '08.05.20.000200																											|25.05.20.00059																								|25.05.20.000035																								|08.05.20.000119																								', '', '', 'Inputted by Monitoring', 'Inputted by Monitoring', 'Florence', 'Florence', 'Cicilia Prima Widi Astuti', 'Olivia Santoso', 'Keren Hapukh', '', 1, 1, 1, 3, 0, '', '', '24-02-2021', '24-02-2021', '26-02-2021', '', 'Keren Hapukh', '17-06-2021', NULL, 0, '', 1, 'Martanita Dika Puspita', 0, '', 0, '', '', ''),
(49, 'Florence', '09-2-2021', 0, 0, 0, 1, 0, 0, 'PT Cibubur Indah Motor', '05-02-2021', 'Polis', '', '0101322000002-1', 'Asli', '', '', '0101322100009-2', '', '', 'Inputted by Monitoring', 'Inputted by Monitoring', 'Florence', 'Florence', 'Cicilia Prima Widi Astuti', 'Olivia Santoso', 'Adi Fajar', '', 1, 1, 1, 3, 0, '', '', '23-02-2021', '23-02-2021', '24-02-2021', '', 'Adi Fajar', '15-04-2021', NULL, 0, '', 1, 'Martanita Dika Puspita', 0, '', 0, '', '', ''),
(52, 'Florence', '09-2-2021', 0, 0, 0, 1, 0, 0, 'PT Pancaran Samudera Transport', '04-02-2021', 'Polis', '', '031900008650', 'Asli', '', '', '032000010635', '', '', 'Inputted by Monitoring', 'Inputted by Monitoring', 'Florence', 'Florence', 'Cicilia Prima Widi Astuti', 'Olivia Santoso', 'Teguh Waspada', '', 1, 1, 1, 1, 0, '', '', '23-02-2021', '23-02-2021', '24-02-2021', '', '', '', NULL, 0, '', 1, 'Martanita Dika Puspita', 0, '', 0, '', '', ''),
(53, 'Hizkia Ignatius Tambun', '11-2-2021', 0, 0, 0, 1, 0, 0, 'PT. Sejahtera Bahari Abadi', '', 'Polis|Polis|Polis', '17-09-2021						|17-09-2021						|17-09-2021						', '||', 'Asli|Asli|Asli', '', '||', '45040120012207						|45040120010488						|PUH2000314						', '51351096						|53505988						|53229456						', 'USD6.800.000,-|USD5.780.000,-|USD13.600.000,-', 'Hizkia Ignatius Tambun', 'Elza Widyasari', 'Ni Putu Emy Indrayani', 'Florence', 'Cicilia Prima Widi Astuti', 'Olivia Santoso', 'Teguh Waspada', '', 1, 1, 1, 1, 0, '11-02-2021', '18-02-2021', '01-03-2021', '01-03-2021', '02-03-2021', '', '', '', NULL, 0, 'USD9.800.000,-|USD8.500.000,-|USD19.980.000,-', 1, 'Martanita Dika Puspita', 1, '11-02-2021', 1, '01-03-2021', '0|0|0', '||'),
(54, 'Hizkia Ignatius Tambun', '11-2-2021', 1, 0, 0, 0, 1, 0, 'PT. Soechi Line Group', '', 'Covernote', 'terlampir						', 'terlampir', 'Asli', '', 'atas kapal-kapal terlampir', 'terlampir						', 'terlampir						', 'terlampir', 'Hizkia Ignatius Tambun', 'Elza Widyasari', 'Ni Putu Emy Indrayani', 'Florence', 'Cicilia Prima Widi Astuti', 'Olivia Santoso', 'Teguh Waspada', '', 1, 1, 1, 1, 0, '11-02-2021', '24-02-2021', '05-03-2021', '05-03-2021', '08-03-2021', '', '', '', 'Tolong diupload excel yg sudah diperbaiki ,by: Florence', 1, 'terlampir', 1, 'Martanita Dika Puspita', 1, '11-02-2021', 1, '02-03-2021', '1', 'Order Asuransi E-Orhar tgl 11-2-2021.xlsx'),
(55, 'Bertha Elita Hia', '10-2-2021', 0, 0, 0, 0, 0, 1, 'PT. Win Win Realty Centre', '', 'Bukti Bayar', '-', '-', 'Copy', '', 'Bukti bayar atas endorsement peningkatan sum insured dan revisi BC', '-', '17493529', '-', 'Bertha Elita Hia', 'Carissa Kurniawan', 'Florence', 'Ni Putu Emy Indrayani', '', '', '', '', 1, 1, 0, 0, 0, '10-02-2021', '24-02-2021', '03-06-2021', '', '', '', '', '', 'Bukti Bayar belum menggunakkan E orhar ( Bukti Bayar sudah di Upload di Cams ) ,by: Martanita Dika Puspita', 1, '-', 2, 'Martanita Dika Puspita', 1, '11-02-2021', 0, '', '', 'Monitoring - SCAN MIR.pdf'),
(56, 'Valiant Gunawan', '11-2-2021', 0, 0, 0, 0, 0, 1, 'PT. Persada Sokka ', '', 'Bukti Bayar', '						', '', 'Copy', '', 'Bukti Bayar atas polis asuransi Nomor :\r\n19081120000010\r\n19080420000014', '						', '41559816				', '', 'Valiant Gunawan', 'Dewi Virgina', 'Ni Putu Emy Indrayani', 'PIK Monitoring Operator', 'Cicilia Prima Widi Astuti', 'Olivia Santoso', 'Teguh Waspada', '', 1, 1, 1, 1, 0, '11-02-2021', '19-02-2021', '24-02-2021', '24-02-2021', '02-03-2021', '', '', '', NULL, 0, '', 1, 'Kania Nurbaiti', 1, '11-02-2021', 0, '', '0', ''),
(57, 'Junista', '16-2-2021', 1, 0, 0, 0, 0, 1, 'PT Pancaran Karya Shipping ', '', 'Polis|Bukti Bayar', '11-10-2021						|						', '|', 'Copy|Copy', '', 'Polis P&I|Bukti Bayar P& I', '75271						|						', '54370580						|54370580						', '10.000 USD|', 'Junista', 'Lidia', 'Ni Putu Emy Indrayani', 'Florence', 'Cicilia Prima Widi Astuti', 'Olivia Santoso', 'Teguh Waspada', '', 1, 1, 1, 3, 0, '16-02-2021', '23-03-2021', '07-04-2021', '08-04-2021', '08-04-2021', '', 'Teguh Waspada', '13-04-2021', NULL, 0, '|', 1, 'Kania Nurbaiti', 1, '16-02-2021', 1, '31-03-2021', '0', '|'),
(58, 'Junista', '16-2-2021', 1, 0, 1, 0, 0, 1, 'PT Pancaran Karya Shipping ', '', 'Polis|Endors|Bukti Bayar', '15-11-2021																		|15-11-2021																		|																		', '||', 'Asli|Asli|Asli', '', '||', '032000010417																		|032000010417																		|																		', '54370580																		|54370580																		|54370580																		', '7.500.000 USD||', 'Junista', 'Lidia', 'Ni Putu Emy Indrayani', 'Florence', 'Cicilia Prima Widi Astuti', 'Olivia Santoso', 'Teguh Waspada', '', 1, 1, 1, 3, 0, '16-02-2021', '23-03-2021', '07-04-2021', '08-04-2021', '08-04-2021', '', 'Teguh Waspada', '13-04-2021', 'Nilai Pertanggungan sebesar Marine Hull USD 7,500,000.00 ,by: Florence', 1, '136.549.000.000||', 1, 'Kania Nurbaiti', 1, '16-02-2021', 1, '31-03-2021', '0|1', '||'),
(59, 'Christy Purnama', '17-2-2021', 1, 0, 0, 0, 0, 0, 'PT Asia Pacific Rayon', '', 'Polis', '30062021', '', 'Asli', '', '+ enorsement tgl 04-12-20 dan kwitansi', '011900066344', '54147400', 'USD 914200000', 'Christy Purnama', 'Elza Widyasari', 'Florence', 'Ni Putu Emy Indrayani', 'Cicilia Prima Widi Astuti', 'Olivia Santoso', 'Adi Fajar', '', 1, 1, 1, 1, 0, '17-02-2021', '24-02-2021', '04-03-2021', '04-03-2021', '05-03-2021', '', '', '', NULL, 0, '8512111000000', 1, 'Martanita Dika Puspita', 1, '17-02-2021', 1, '03-03-2021', '1', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `msblokirrekening`
--

CREATE TABLE `msblokirrekening` (
  `id` int(5) NOT NULL,
  `username` varchar(255) NOT NULL,
  `dateTransaction` varchar(255) NOT NULL,
  `dateStart` varchar(255) NOT NULL,
  `dateEnd` varchar(255) NOT NULL,
  `ptname` varchar(255) NOT NULL,
  `norek` varchar(255) NOT NULL,
  `idr` varchar(255) NOT NULL,
  `tipevalas` varchar(255) NOT NULL,
  `valas` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `type2` varchar(255) NOT NULL,
  `type2detail` varchar(2555) NOT NULL,
  `permintaan` varchar(255) NOT NULL,
  `alasan` varchar(255) NOT NULL,
  `instruksi` varchar(255) NOT NULL,
  `keaslian` varchar(255) NOT NULL,
  `hcname` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `filess` varchar(255) NOT NULL,
  `picbo` varchar(255) NOT NULL,
  `spvbo` varchar(255) NOT NULL,
  `picboss` varchar(255) NOT NULL,
  `commentreject` varchar(255) NOT NULL,
  `recordrejected` int(5) NOT NULL,
  `slkopacc` int(5) NOT NULL,
  `slkhcacc` int(5) NOT NULL,
  `picboacc` int(5) NOT NULL,
  `picbokeaslianacc` int(5) NOT NULL,
  `spvboacc` int(5) NOT NULL,
  `picbossacc` int(5) NOT NULL,
  `slkhcaccdate` varchar(255) NOT NULL,
  `picboaccdate` varchar(255) NOT NULL,
  `picbokeaslianaccdate` varchar(255) NOT NULL,
  `spvboaccdate` varchar(255) NOT NULL,
  `picbossaccdate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `msblokirrekening`
--

INSERT INTO `msblokirrekening` (`id`, `username`, `dateTransaction`, `dateStart`, `dateEnd`, `ptname`, `norek`, `idr`, `tipevalas`, `valas`, `type`, `type2`, `type2detail`, `permintaan`, `alasan`, `instruksi`, `keaslian`, `hcname`, `file`, `filess`, `picbo`, `spvbo`, `picboss`, `commentreject`, `recordrejected`, `slkopacc`, `slkhcacc`, `picboacc`, `picbokeaslianacc`, `spvboacc`, `picbossacc`, `slkhcaccdate`, `picboaccdate`, `picbokeaslianaccdate`, `spvboaccdate`, `picbossaccdate`) VALUES
(84, 'Christine', '11-2-2021', '11-2-2021', '17-2-2021', 'PT Inti Prima Cemerlang', '205-006-2425', '2598058480.47', '', '', 'Pemblokiran Saldo', '', '', 'SLK', 'Dana Cadangan Minimal Angsuran Februari 2021', '', '', 'Wilbert Karel Wetik', 'Tabel Angsuran KI I IPC per Desember 2020.pdf', '', '', '', '', 'Dihapus saja...krn sdh diproses manual ,by: Wilbert Karel Wetik', 1, 1, 2, 0, 0, 0, 0, '17-03-2021', '', '', '', ''),
(89, 'Valiant Gunawan', '19-2-2021', '19-2-2021', '19-2-2021', 'PT. Margautama Nusantara', '2050065491', '6213531258.89', '', '', 'Pencabutan', '', '', 'SLK', 'Pembayaran bunga Kom 001 Pinj 003', '', '', 'Nyimas Wida', 'Buka tutup Blokir 19-02-2021.zip', '1613723174-2050065491CABUT.docx', 'MM Dicna Advenia N', 'Toni Fresly F M', 'MM Dicna Advenia N', '', 0, 1, 1, 1, 0, 1, 1, '19-02-2021', '19-02-2021', '', '19-02-2021', '19-02-2021'),
(90, 'Valiant Gunawan', '19-2-2021', '19-2-2021', '31-12-2080', 'PT. Margautama Nusantara', '2050065491', '4498767566.89', '', '', 'Pemblokiran Saldo', '', '', 'SLK', 'Saldo Minimum', '', '', 'Nyimas Wida', 'Buka tutup Blokir 19-02-2021.zip', '1613723272-2050065491-BLOKIR.docx', 'Silviana Dewi', 'Toni Fresly F M', 'Silviana Dewi', '', 0, 1, 1, 1, 0, 1, 1, '19-02-2021', '19-02-2021', '', '19-02-2021', '19-02-2021'),
(91, 'Maria', '19-2-2021', '19-2-2021', '31-12-2021', 'PT. Indah Jaya Textile Industry', '001-300-0040 (USD) dan 001-301-6078 (IDR)', '', '', '', 'Pemblokiran Rekening', 'Post Indicator', 'Tidak dapat melakukan Transaksi Debet|Tidak dapat melakukan Transaksi Kredit', 'SLK KCK', 'PKPU untuk melakukan freeze rekening Kredit Lokal ', 'Mohon bantuannya untuk menambahkan post indicator no debet dan no credit atas kedua rekenng diatas', '', 'Wilbert Karel Wetik', '', '', '', '', '', 'Dihapus, krn sdh diproses secara manual.. ,by: Wilbert Karel Wetik', 1, 1, 2, 0, 0, 0, 0, '17-03-2021', '', '', '', ''),
(92, 'Maria', '19-2-2021', '19-2-2021', '31-12-2080', 'PT. Spinmill Indah Industry', '205-000-0985 (USD) dan  205-000-1086 (IDR)', '', '', '', 'Pemblokiran Rekening', 'Post Indicator', 'Tidak dapat melakukan Transaksi Debet|Tidak dapat melakukan Transaksi Kredit', 'SLK KCK', 'PKPU', 'Mohon untuk dapat ditambahkan post indicator no debet dan no kredit atas kedua rekening di atas', '', 'Wilbert Karel Wetik', '', '', '', '', '', 'Dihapus, proses sudah dilakukan manual ,by: Wilbert Karel Wetik', 1, 1, 2, 0, 0, 0, 0, '17-03-2021', '', '', '', ''),
(93, 'Valiant Gunawan', '19-2-2021', '19-2-2021', '19-2-2021', 'PT. Makassar Metro Network', '0253705717', '7060884458.45', '', '', 'Pencabutan', '', '', 'SLK', 'Saldo Minimum', '', '', 'Nyimas Wida', 'Buka tutup blokir PT. MMN 19-02-2021.docx', '1613726704-0253705717-CABUT.docx', 'Widyadita Hasna Z', 'Elfin Alfiana', 'Widyadita Hasna Z', '', 0, 1, 1, 1, 0, 1, 1, '19-02-2021', '19-02-2021', '', '19-02-2021', '19-02-2021'),
(94, 'Valiant Gunawan', '19-2-2021', '19-2-2021', '31-12-2080', 'PT. Makassar Metro Network', '0253705717', '8436650958.45', '', '', 'Pemblokiran Saldo', '', '', 'SLK', 'Saldo Minimum', '', '', 'Nyimas Wida', 'Buka tutup blokir PT. MMN 19-02-2021.docx', '', 'Widyadita Hasna Z', 'Elfin Alfiana', 'Widyadita Hasna Z', '', 0, 1, 1, 1, 0, 1, 1, '19-02-2021', '19-02-2021', '', '19-02-2021', '19-02-2021'),
(95, 'Slk Operator 1', '22-2-2021', '22-2-2021', '31-12-2080', 'PT Sehat Jaya Sentosa', '0023333789', '10000000000', '', '', 'Pemblokiran Saldo', '', '', 'SLK-KCK', 'Jaminan cash coll 5% atas penggunaan fasilitas LC', 'SLK-KCK', '', 'Slk Head Cluster 1', '', '', '', '', '', '', 0, 1, 0, 0, 0, 0, 0, '', '', '', '', ''),
(96, 'Bertha Elita Hia', '23-2-2021', '23-2-2021', '23-2-2021', 'PT. Estrella Sebelas Indonesia ', '0064545678', '23350000', '', '', 'Pencabutan', '', '', 'SLK - KCK', 'Untuk keperluan pembayaran bunga pinjaman', 'SLK - KCK', '', 'Dewi Virgina', 'Re  Jatuh Tempo Pembayaran Pinjaman Whiz Hotel Feb 2021.msg', '', 'Silviana Dewi', 'Toni Fresly F M', 'Silviana Dewi', '', 0, 1, 1, 1, 0, 1, 1, '23-02-2021', '23-02-2021', '', '23-02-2021', '23-02-2021'),
(97, 'Bertha Elita Hia', '23-2-2021', '23-2-2021', '31-12-2080', 'PT. Estrella Sebelas Indonesia ', '0064545678', '12360000', '', '', 'Pemblokiran Saldo', '', '', 'SLK - KCK', 'Sebagai dana retention pembayaran pinjaman', 'dana diblokir sebagai dana retention pembayaran pinjaman', '', 'Dewi Virgina', 'Re  Jatuh Tempo Pembayaran Pinjaman Whiz Hotel Feb 2021.msg', '1614081678-0064545678-BLOKIR.docx', 'Silviana Dewi', 'Toni Fresly F M', 'Silviana Dewi', '', 0, 1, 1, 1, 0, 1, 1, '23-02-2021', '23-02-2021', '', '23-02-2021', '23-02-2021'),
(99, 'Nadila', '23-2-2021', '23-2-2021', '24-2-2021', 'PT SENTOSA LESTARI NUSANTARA', '655-032-323-9', '51035000', '', '', 'Pemblokiran Saldo', '', '', 'SLK', 'Untuk pembayaran tunggakan bunga tanggal 24-02-2021', 'Mohon bantuannya untuk memblokir saldo terlampir', '', 'Mega Febrilia', '1614092866-Sentosa.docx', '1614093795-6550323239-BLOKIR.docx', 'Silviana Dewi', 'Toni Fresly F M', 'Silviana Dewi', 'tidak bisa dijalankan krn ada transaksi hari ini ,by: Toni Fresly F M', 0, 1, 1, 1, 1, 1, 1, '23-02-2021', '23-02-2021', '23-2-2021', '23-02-2021', '23-02-2021'),
(100, 'Nadila', '23-2-2021', '23-2-2021', '24-2-2021', 'PT SURYA LINTAS NUSANTARA', '655-033-366-8', '237000000', '', '', 'Pemblokiran Saldo', '', '', 'SLK', 'Untuk pembayaran tunggakan bunga tanggal 24-02-2021', 'Mohon bantuannya untuk memblokir saldo terlampir', '', 'Mega Febrilia', '1614092911-Surya.docx', '1614093906-6550333668-BLOKIR.docx', 'Silviana Dewi', 'Toni Fresly F M', 'Silviana Dewi', 'tidak bisa dijalankan krn ada transaksi hari ini ,by: Toni Fresly F M', 0, 1, 1, 1, 1, 1, 1, '23-02-2021', '23-02-2021', '23-2-2021', '23-02-2021', '23-02-2021'),
(101, 'Nadila', '23-2-2021', '23-2-2021', '24-2-2021', 'PT AMOSYS INDONESIA', '270-322-218-8', '65500000', '', '', 'Pemblokiran Saldo', '', '', 'SLK', 'Untuk pembayaran tunggakan bunga tanggal 24-02-2021', 'Mohon bantuannya untuk memblokir saldo terlampir', '', 'Mega Febrilia', '1614092990-aMOSYS.docx', '1614093706-2703222188-BLOKIR.docx', 'Silviana Dewi', 'Toni Fresly F M', 'Silviana Dewi', 'tidak bisa dijalankan krn ada transaksi hari ini ,by: Toni Fresly F M', 0, 1, 1, 1, 1, 1, 1, '23-02-2021', '23-02-2021', '23-2-2021', '23-02-2021', '23-02-2021'),
(102, 'Nadila', '24-2-2021', '24-2-2021', '24-2-2021', 'PT AMOSYS INDONESIA', '270-322-218-8', '65500000', '', '', 'Pencabutan', '', '', 'SLK', 'Untuk pembayaran tunggakan bunga ', 'Mohon buka blokir atas pemblokiran dana terlampir', '', 'Mega Febrilia', '1614165588-BukaBlokirAmosys.docx', '1614169810-2703222188-CABUT.docx', 'Silviana Dewi', 'Toni Fresly F M', 'Silviana Dewi', '', 0, 1, 1, 1, 1, 1, 1, '24-02-2021', '24-02-2021', '24-2-2021', '24-02-2021', '24-02-2021'),
(103, 'Nadila', '24-2-2021', '24-2-2021', '24-2-2021', 'PT SURYA LINTAS NUSANTARA', '655-033-366-8', '237000000', '', '', 'Pencabutan', '', '', 'SLK', 'Untuk pembayaran tunggakan bunga ', 'Mohon buka blokir atas pemblokiran dana terlampir', '', 'Mega Febrilia', '1614165540-BukaBlokirSurya.docx', '1614170026-6550333668-CABUT.docx', 'Silviana Dewi', 'Toni Fresly F M', 'Silviana Dewi', '', 0, 1, 1, 1, 1, 1, 1, '24-02-2021', '24-02-2021', '24-2-2021', '24-02-2021', '24-02-2021'),
(104, 'Nadila', '24-2-2021', '24-2-2021', '24-2-2021', 'PT SENTOSA LESTARI NUSANTARA', '655-032-323-9', '51035000', '', '', 'Pencabutan', '', '', 'SLK', 'Untuk pembayaran tunggakan bunga ', 'Mohon buka blokir atas pemblokiran dana terlampir', '', 'Mega Febrilia', '1614166102-BukaBlokirSentosa.docx', '1614169921-6550323239-CABUT.docx', 'Silviana Dewi', 'Toni Fresly F M', 'Silviana Dewi', '', 0, 1, 1, 1, 1, 1, 1, '24-02-2021', '24-02-2021', '24-2-2021', '24-02-2021', '24-02-2021'),
(105, 'Leonhard Bianda', '25-2-2021', '25-2-2021', '31-12-2080', 'Group Karangjuang ', 'terlampir', 'terlampir', 'USD', 'terlampir', 'Pemblokiran Saldo', '', '', 'SLK', 'Top up bunga', '', '', 'Nyimas Wida', '1614260415-1.FEB2021.pdf', '1614265294-GROUPKARANGJUANG-BLOKIR.docx', 'Silviana Dewi', 'Toni Fresly F M', 'Silviana Dewi', 'Salah tanggal akhir ,by: Silviana Dewi', 0, 1, 1, 1, 1, 1, 1, '25-02-2021', '25-02-2021', '25-2-2021', '25-02-2021', '25-02-2021'),
(106, 'Putri Pramesti Tiarma', '25-2-2021', '25-2-2021', '25-2-2021', 'PT. Intercipta Sempana', '6550099789', '150000000000', '', '-', 'Pencabutan', 'Status1', 'Dijaminkan', 'buka blokir sebesar Rp 150.000.000.000 ', 'perubahan nilai agunan', 'buka blokir sebesar Rp 150.000.000.000 ', '', 'Elza Widyasari', '1614257391-ProkemasSPPK.pdf', '1614265886-6550099789-CABUT.docx', 'Silviana Dewi', 'Toni Fresly F M', 'Silviana Dewi', '', 0, 1, 1, 1, 1, 1, 1, '25-02-2021', '25-02-2021', '25-2-2021', '25-02-2021', '25-02-2021'),
(107, 'Putri Pramesti Tiarma', '25-2-2021', '25-2-2021', '31-12-2080', 'PT. Intercipta Sempana', '6550099789', '100000000000', '', '-', 'Pemblokiran Saldo', 'Status1', 'Dijaminkan', 'blokir Rp. 100.000.000.000', 'menjadi jaminan fasilitas kredit', 'blokir Rp. 100.000.000.000', '', 'Elza Widyasari', '1614259836-ProkemasSPPK.pdf', '1614265996-6550099789-BLOKIR.docx', 'Silviana Dewi', 'Toni Fresly F M', 'Silviana Dewi', '', 0, 1, 1, 1, 1, 1, 1, '25-02-2021', '25-02-2021', '25-2-2021', '25-02-2021', '25-02-2021'),
(108, 'Valiant Gunawan', '26-2-2021', '26-2-2021', '26-2-2021', 'PT. Makassar Metro Network', '0253705717', '8436650958.45', '', '0', 'Pencabutan', '', '', 'SLK', 'Bayar bunga Fas Sindikasi dan Bilateral', '', '', 'Nyimas Wida', 'Buka tutup blokir 26-02-2021.zip', '1614323117-MAKASSARMETRONETWORKPT.docx', 'MM Dicna Advenia N', 'Toni Fresly F M', 'MM Dicna Advenia N', '', 0, 1, 1, 1, 0, 1, 1, '26-02-2021', '26-02-2021', '', '26-02-2021', '26-02-2021'),
(109, 'Valiant Gunawan', '26-2-2021', '26-2-2021', '31-12-2080', 'PT. Makassar Metro Network', '0253705717', '4198323427.31', '', '0', 'Pemblokiran Saldo', '', '', 'SLK', 'Saldo minimum', '', '', 'Nyimas Wida', 'Buka tutup blokir 26-02-2021.zip', '1614323103-MAKASSARMETRONETWORKPT.docx', 'MM Dicna Advenia N', 'Toni Fresly F M', 'MM Dicna Advenia N', '', 0, 1, 1, 1, 0, 1, 1, '26-02-2021', '26-02-2021', '', '26-02-2021', '26-02-2021'),
(110, 'Valiant Gunawan', '26-2-2021', '26-2-2021', '26-2-2021', 'PT. Bintaro Serpong Damai', '2050003381', '318265224.70', '', '0', 'Pencabutan', '', '', 'SLK', 'Bayar bunga ', '', '', 'Nyimas Wida', 'Buka tutup blokir 26-02-2021.zip', '1616405027-BINTAROSERPONGDAMAIPT-CABUTBLOKIR.docx', 'Widyadita Hasna Z', 'Toni Fresly F M', 'MM Dicna Advenia N', '', 0, 1, 1, 1, 0, 1, 1, '26-02-2021', '26-02-2021', '', '26-02-2021', '22-03-2021'),
(111, 'Valiant Gunawan', '26-2-2021', '26-2-2021', '31-12-2080', 'PT. Bintaro Serpong Damai', '2050003381', '160775017.33', '', '0', 'Pemblokiran Saldo', '', '', 'SLK', 'saldo minimum', '', '', 'Nyimas Wida', 'Buka tutup blokir 26-02-2021.zip', '1614336247-BINTAROSERPONGDAMAIPT-BLOKIR.docx', 'Widyadita Hasna Z', 'Toni Fresly F M', 'Widyadita Hasna Z', '', 0, 1, 1, 1, 0, 1, 1, '26-02-2021', '26-02-2021', '', '26-02-2021', '26-02-2021'),
(112, 'Valiant Gunawan', '26-2-2021', '26-2-2021', '26-2-2021', 'PT. Jalan Tol Seksi Empat', '0253705938', '4085507864.08', '', '0', 'Pencabutan', '', '', 'SLK', 'Bayar bunga', '', '', 'Nyimas Wida', 'Buka tutup blokir 26-02-2021.zip', '1614335843-JALANTOLSEKSIEMPATPT-CABUTBLOKIR.docx', 'Widyadita Hasna Z', 'Toni Fresly F M', 'Widyadita Hasna Z', '', 0, 1, 1, 1, 0, 1, 1, '26-02-2021', '26-02-2021', '', '26-02-2021', '26-02-2021'),
(113, 'Valiant Gunawan', '26-2-2021', '26-2-2021', '31-12-2080', 'PT. Jalan Tol Seksi Empat', '0253705938', '2029287640.54', '', '0', 'Pemblokiran Saldo', '', '', 'SLK', 'Saldo Minimum', '', '', 'Nyimas Wida', 'Buka tutup blokir 26-02-2021.zip', '1614336433-JALANTOLSEKSIEMPATPT-BLOKIR.docx', 'Widyadita Hasna Z', 'Toni Fresly F M', 'Widyadita Hasna Z', '', 0, 1, 1, 1, 0, 1, 1, '26-02-2021', '26-02-2021', '', '26-02-2021', '26-02-2021');

-- --------------------------------------------------------

--
-- Struktur dari tabel `msborrow`
--

CREATE TABLE `msborrow` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `transdate` varchar(255) NOT NULL,
  `deadline` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `dokumen` varchar(255) DEFAULT NULL,
  `norek` varchar(255) DEFAULT NULL,
  `nojaminan` varchar(255) DEFAULT NULL,
  `nokomit` varchar(255) DEFAULT NULL,
  `kondisi` varchar(255) DEFAULT NULL,
  `nopolis` varchar(255) DEFAULT NULL,
  `periode` varchar(255) DEFAULT NULL,
  `polislama` varchar(255) DEFAULT NULL,
  `detail` varchar(1000) DEFAULT NULL,
  `detail2` varchar(1000) DEFAULT NULL,
  `keaslian` varchar(255) DEFAULT NULL,
  `flagkeaslian` varchar(255) DEFAULT '0',
  `alkhcname` varchar(255) NOT NULL,
  `pic1name` varchar(255) DEFAULT NULL,
  `pic2name` varchar(255) DEFAULT NULL,
  `pikhcname` varchar(255) DEFAULT NULL,
  `pikhcname2` varchar(255) DEFAULT NULL,
  `alkop` varchar(255) DEFAULT NULL,
  `alkhc` varchar(255) NOT NULL,
  `pikop` varchar(255) NOT NULL,
  `pikhc1` varchar(255) DEFAULT NULL,
  `pikhc2` varchar(255) DEFAULT NULL,
  `flagrejected` varchar(255) DEFAULT NULL,
  `flagrejectedpik` varchar(255) DEFAULT NULL,
  `flagpiktoalk` varchar(255) DEFAULT NULL,
  `alkhcname2` varchar(255) DEFAULT NULL,
  `pic1name2` varchar(255) DEFAULT NULL,
  `pic2name2` varchar(255) DEFAULT NULL,
  `pikhcname3` varchar(255) DEFAULT NULL,
  `alkop2` varchar(255) DEFAULT '0',
  `alkhc2` varchar(255) DEFAULT '0',
  `pikop2` varchar(255) DEFAULT '0',
  `pikhc12` varchar(255) DEFAULT '0',
  `flagrejected2` varchar(255) DEFAULT '0',
  `flagrejectedpik2` varchar(255) DEFAULT '0',
  `flagpiktoalk2` varchar(255) DEFAULT '0',
  `pikprogress` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `timestampprovisi` varchar(255) DEFAULT NULL,
  `typeextra` varchar(255) DEFAULT NULL,
  `pikmargin` varchar(255) DEFAULT NULL,
  `comreject` varchar(255) DEFAULT NULL,
  `waktu` varchar(255) DEFAULT NULL,
  `diserahkan` int(11) NOT NULL DEFAULT '0',
  `clusterhold` varchar(255) NOT NULL DEFAULT '0',
  `tgldiserahkan` varchar(255) DEFAULT NULL,
  `waktualk` varchar(255) DEFAULT NULL,
  `pikhc3` varchar(255) NOT NULL DEFAULT '0',
  `reminder` int(5) DEFAULT '0',
  `reminderdate` varchar(255) DEFAULT NULL,
  `lokasibg` varchar(255) DEFAULT NULL,
  `rekgiro` varchar(255) DEFAULT NULL,
  `adminis` varchar(255) DEFAULT NULL,
  `komisi` varchar(255) DEFAULT NULL,
  `bataswaktu` varchar(255) DEFAULT NULL,
  `jangkabg` varchar(255) DEFAULT NULL,
  `jenisjamin` varchar(255) DEFAULT NULL,
  `penerima` varchar(255) NOT NULL,
  `alamatpenerimajamin` varchar(255) DEFAULT NULL,
  `namapenerimajamin` varchar(255) DEFAULT NULL,
  `alamatjamin` varchar(255) DEFAULT NULL,
  `namajamin` varchar(255) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `dateborrow1` varchar(255) NOT NULL,
  `dateborrow2` varchar(255) NOT NULL,
  `dateborrow3` varchar(255) NOT NULL,
  `dateborrow4` varchar(255) NOT NULL,
  `notes` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `msborrow`
--

INSERT INTO `msborrow` (`id`, `username`, `transdate`, `deadline`, `company`, `dokumen`, `norek`, `nojaminan`, `nokomit`, `kondisi`, `nopolis`, `periode`, `polislama`, `detail`, `detail2`, `keaslian`, `flagkeaslian`, `alkhcname`, `pic1name`, `pic2name`, `pikhcname`, `pikhcname2`, `alkop`, `alkhc`, `pikop`, `pikhc1`, `pikhc2`, `flagrejected`, `flagrejectedpik`, `flagpiktoalk`, `alkhcname2`, `pic1name2`, `pic2name2`, `pikhcname3`, `alkop2`, `alkhc2`, `pikop2`, `pikhc12`, `flagrejected2`, `flagrejectedpik2`, `flagpiktoalk2`, `pikprogress`, `type`, `timestampprovisi`, `typeextra`, `pikmargin`, `comreject`, `waktu`, `diserahkan`, `clusterhold`, `tgldiserahkan`, `waktualk`, `pikhc3`, `reminder`, `reminderdate`, `lokasibg`, `rekgiro`, `adminis`, `komisi`, `bataswaktu`, `jangkabg`, `jenisjamin`, `penerima`, `alamatpenerimajamin`, `namapenerimajamin`, `alamatjamin`, `namajamin`, `file`, `dateborrow1`, `dateborrow2`, `dateborrow3`, `dateborrow4`, `notes`) VALUES
(1, 'Meltia Inapril', '5-2-2020', '5-5-2020', 'PT Kevindo Putra Sejati', 'Perjanjian Penyelesaian Utang', '2059004624', '', '0000001', 'Borrow', NULL, NULL, NULL, 'Koreksi Notaris (Dok No 52 tgl 29/09/2019)', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Adi Fajar', 'Choose PIK Operator', 'Iwati', NULL, '1', '1', '1', '1', '1', '0', '0', '1', NULL, NULL, NULL, NULL, '1', '0', '0', '1', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, ' ,by: Adi Fajar', '08:53', 0, '0', NULL, '16:04', '0', 0, 'February 14, 2020, 8:43 am', 'Adi Fajar', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(2, 'Sonia Wibisono', '6-2-2020', '6-2-2020', 'PT Namasindo Plas', 'TTDBJ + invoice', 'Agen Jaminan', '30000328', '', 'Borrow', NULL, NULL, NULL, 'tarik TTDBJ beserta invoice utk ditukar dengan 1 TTDBJ baru\r\nNo. 002/TTD/KCK/I/2016 tgl 04-01-2016\r\nNo. 177/TTD/KCK/V/2014 tgl 14-05-2014\r\nNo. 258/TTD/KCK/VIII/2015 tgl 10-08-2015', NULL, NULL, '0', 'Wilbert Karel Wetik', 'Keren Hapukh', 'Adi Fajar', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '1', '1', '1', '1', '0', '0', '0', '0', '2', NULL, NULL, NULL, NULL, '09:12', 0, '0', NULL, '09:11', '0', 0, 'February 11, 2020, 8:19 am', 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(3, 'Sonia Wibisono', '6-2-2020', '11-2-2020', 'PT Mega Central Finance (MCF 2)', 'Lampiran 1 Daftar Obyek Fidusia', 'Agen Jaminan', '30001470', '', 'Borrow', NULL, NULL, NULL, 'borrow utk revisi Lampiran 1 atas Daftar Obyek Fidusia per 31 Desember 2019', NULL, NULL, '0', 'Wilbert Karel Wetik', 'Keren Hapukh', 'Adi Fajar', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '1', '1', '1', '1', '0', '0', '0', '0', '1', NULL, NULL, NULL, NULL, '10:54', 0, '0', NULL, '09:14', '0', 0, 'February 11, 2020, 8:22 am', 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(5, 'Meltia Inapril', '7-2-2020', '7-5-2020', 'PT Catur Sentosa Adiprana', 'AJF dan SJF', '0359096137', '15625742', '0000004', 'Borrow', NULL, NULL, NULL, 'Koreksi Notaris (Dokumen AJF No. 02 tgl 03/12/18, SJF No. W10.00710169.AH.05.02 TAHUN 2018 tgl 19/12/18)', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Adi Fajar', 'Choose PIK Operator', 'Iwati', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '1', '0', '0', '1', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '08:50', 0, '0', NULL, '16:27', '0', 0, 'February 14, 2020, 8:43 am', 'Adi Fajar', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(6, 'Meltia Inapril', '7-2-2020', '7-5-2020', 'Ridwan Tandiawan Grup', 'SHT dan APHT', '2059009154', '21502166', '0000001', 'Borrow', NULL, NULL, NULL, 'Koreksi Notaris (Dok SHT No. 147/2010 tgl 13/12/10, APHT No. 144/ES/APHT/XI/2010 tgl 24/11/10)', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', '1', NULL, NULL, NULL, NULL, '1', '0', '0', '1', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, ' ,by: Teguh Waspada', '14:15', 0, '0', NULL, '16:29', '0', 0, 'February 13, 2020, 9:08 am', 'Teguh Waspada', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(7, 'Meltia Inapril', '7-2-2020', '7-5-2020', 'Ridwan Tandiawan Grup', 'SHT dan APHT', '2059009154', '21502000', '0000001', 'Borrow', NULL, NULL, NULL, 'Koreksi Notaris (Dok SHT No. 146/2010 tgl 13/12/10, APHT No. 145/ES/APHT/XI/2010 tgl 24/11/10)', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '1', '0', '0', '1', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '08:52', 0, '0', NULL, '16:30', '0', 0, 'February 13, 2020, 9:09 am', 'Teguh Waspada', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(8, 'Meltia Inapril', '7-2-2020', '7-5-2020', 'Ridwan Tandiawan Grup', 'SHT dan APHT', '2059009154', '21502083', '0000001', 'Borrow', NULL, NULL, NULL, 'Koreksi Notaris (Dok SHT No. 144/2010 tgl 13/12/10, APHT No. 147/ES/APHT/XI/2010 tgl 24/11/10)', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '1', '0', '0', '1', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '08:52', 0, '0', NULL, '16:31', '0', 0, 'February 13, 2020, 9:09 am', 'Teguh Waspada', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(9, 'Meltia Inapril', '7-2-2020', '7-5-2020', 'Ridwan Tandiawan Grup', 'SHT dan APHT', '2059009154', '21501895', '0000001', 'Borrow', NULL, NULL, NULL, 'Koreksi Notaris (Dok SHT No. 143/2010 tgl 13/12/10, APHT No. 148/ES/APHT/XI/2010 tgl 24/11/10)', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '1', '0', '0', '1', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '08:53', 0, '0', NULL, '16:32', '0', 0, 'February 13, 2020, 9:10 am', 'Teguh Waspada', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(10, 'Meltia Inapril', '7-2-2020', '7-5-2020', 'Ridwan Tandiawan Grup', 'SHT dan APHT', '2059009154', '21502240', '0000001', 'Borrow', NULL, NULL, NULL, 'Koreksi Notaris (Dok SHT No. 142/2010 tgl 13/12/10, APHT No. 149/ES/APHT/XI/2010 tgl 24/11/10)', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '1', '0', '0', '1', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '08:53', 0, '0', NULL, '16:34', '0', 0, 'February 13, 2020, 9:10 am', 'Teguh Waspada', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(11, 'Vinsensia Givy Gisela', '10-2-2020', '10-3-2020', 'PT Surya Darma Perkasa', 'Addendum ke 3 PK', '0359005531', '', '', 'Borrow', NULL, NULL, NULL, 'pinjam add PK No. 134/Add-KCK/2018 tgl 08-05-2017 untuk dikoreksi', NULL, NULL, '0', 'Lidia', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '1', '1', '1', '1', '0', '0', '0', '0', '1', NULL, NULL, NULL, NULL, '12:16', 0, '0', NULL, '11:35', '0', 0, 'February 13, 2020, 8:55 am', 'Teguh Waspada', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(12, 'Arief Satria Budiman', '11-2-2020', '29-2-2020', 'PT So Good Food', 'APHT', '2059005981', '42673343', '0000001', 'Borrow', NULL, NULL, NULL, 'APHT No. 039/2016 tgl 15-01-2016 melekat pada SHT 04894/2016\r\nu/ Scan ulang dokumen', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', '1', NULL, NULL, NULL, NULL, '1', '0', '0', '1', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, ' ,by: Teguh Waspada', '15:43', 0, '0', NULL, '10:14', '0', 0, 'February 13, 2020, 8:54 am', 'Teguh Waspada', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(13, 'Arief Satria Budiman', '11-2-2020', '29-2-2020', 'PT So Good Food', 'APHT', '2059005981', '42673343', '0000001', 'Borrow', NULL, NULL, NULL, 'APHT No. 040/2016 tgl 15-01-2016 melekat pada SHT 04893/2016\r\nu/ Scan ulang dokumen', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', '1', NULL, NULL, NULL, NULL, '1', '0', '0', '1', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, ' ,by: Teguh Waspada', '15:43', 0, '0', NULL, '10:18', '0', 0, 'February 13, 2020, 8:55 am', 'Teguh Waspada', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(14, 'Arief Satria Budiman', '11-2-2020', '11-8-2020', 'PT Muliaglass', 'Sertifikat', '2059071488', '28821213', '0000001', 'Borrow', NULL, NULL, NULL, 'Perpanjangan Sertifikat No. 32/Wangunharja', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Keren Hapukh', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', '1', NULL, NULL, NULL, NULL, '1', '0', '0', '1', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, 'koreksi keterangan untuk diinput borrow dokumen satu per satu ,by: Keren Hapukh', '15:16', 0, '0', NULL, '13:29', '0', 0, 'February 13, 2020, 9:39 am', 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(15, 'Arief Satria Budiman', '12-2-2020', '12-7-2020', 'PT Muliaglass', 'Sertifikat', '2059071488', '28821213', '0000001', 'Borrow', NULL, NULL, NULL, 'Perpanjangan Sertifikat No. 10/Sukaresmi', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Keren Hapukh', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '1', '0', '0', '1', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '15:17', 0, '0', NULL, '14:18', '0', 0, 'February 13, 2020, 9:39 am', 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(16, 'Arief Satria Budiman', '12-2-2020', '12-7-2020', 'PT Muliaglass', 'Sertifikat', '2059071488', '28821213', '0000001', 'Borrow', NULL, NULL, NULL, 'Perpanjangan Sertifikat No. 14/Sukaresmi', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Keren Hapukh', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '1', '0', '0', '1', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '15:18', 0, '0', NULL, '14:19', '0', 0, 'February 13, 2020, 9:39 am', 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(17, 'Arief Satria Budiman', '12-2-2020', '12-7-2020', 'PT Muliaglass', 'Sertifikat', '2059071488', '28821213', '0000001', 'Borrow', NULL, NULL, NULL, 'Perpanjangan Sertifikat No. 2047/Sukaresmi', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Keren Hapukh', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '1', '0', '0', '1', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '15:18', 0, '0', NULL, '14:19', '0', 0, 'February 13, 2020, 9:39 am', 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(18, 'Arief Satria Budiman', '12-2-2020', '12-7-2020', 'PT Muliaglass', 'Sertifikat', '2059071488', '28821213', '0000001', 'Borrow', NULL, NULL, NULL, 'Perpanjangan Sertifikat No. 2048/Sukaresmi', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Keren Hapukh', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '1', '0', '0', '1', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '15:18', 0, '0', NULL, '14:21', '0', 0, 'February 13, 2020, 9:40 am', 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(19, 'Arief Satria Budiman', '12-2-2020', '12-7-2020', 'PT Muliaglass', 'Sertifikat', '2059071488', '28821213', '0000001', 'Borrow', NULL, NULL, NULL, 'Perpanjangan Sertifikat No. 31/Wangunharja', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Keren Hapukh', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '1', '0', '0', '1', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '15:18', 0, '0', NULL, '14:21', '0', 0, 'February 13, 2020, 9:40 am', 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(20, 'Citra Arruum', '12-2-2020', '12-2-2020', 'PT. Daliatex Kusuma', 'Scan Asli Dokumen-Dokumen yg ada di keterangan', '0359302942', '-', '-', 'Borrow', NULL, NULL, NULL, '1. Scan Asli Dokumen Surat Persetujuan RUPS 25 Fberuari 2013\r\n2. Scan Asli RUPS penyerahan aset tgl 7 Desember 2006\r\n3. SP Dekom tgl 10 September 2009\r\n4.SP Dekom 14 Desember 2009\r\n5. SP Dekom 22 agustus 2005\r\n6. SHM No. 879 no jaminan 8806036\r\n', NULL, NULL, '0', 'Wilbert Karel Wetik', 'Adi Fajar', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '1', '1', '1', '1', '0', '0', '0', '0', '1', NULL, NULL, NULL, NULL, '15:07', 0, '0', NULL, '14:59', '0', 0, 'February 21, 2020, 18:18 pm', 'Adi Fajar', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(23, 'Arief Satria Budiman', '13-2-2020', '13-5-2020', 'PT Global Eco Chemicals Indonesia', 'Perubahan Pertama atas PK', '2059011001', '', '0000001', 'Borrow', NULL, NULL, NULL, 'ADD PK KE 1 No. 71 tgl 29-11-2019\r\nu/ koreksi notaris', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Keren Hapukh', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '1', '0', '0', '1', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '16:29', 0, '0', NULL, '14:28', '0', 0, 'February 17, 2020, 8:18 am', 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(24, 'Meltia Inapril', '13-2-2020', '14-2-2020', 'PT Arta Batrindo', 'SKMHT', '01689001678', '26350918', '0000001', 'Borrow', NULL, NULL, NULL, 'Untuk SCAN ulang, SKMHT No. 81 tgl 28/02/2018 ', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Adi Fajar', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '1', '0', '0', '1', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '16:28', 0, '0', NULL, '14:57', '0', 0, 'February 17, 2020, 8:46 am', 'Adi Fajar', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(25, 'Arief Satria Budiman', '13-2-2020', '13-8-2020', 'PT Central Mega Kencana', 'Sertifikat', '2689004517', '24571317', '0000001', 'Borrow', NULL, NULL, NULL, 'Perpanjangan Sertifikat No. 583/Harjamekar', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Adi Fajar', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, 'Arief Satria Budiman', NULL, 'Arief Satria Budiman', '1', '1', '1', '1', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '16:29', 0, '0', NULL, '16:22', '0', 0, 'February 17, 2020, 8:46 am', 'Adi Fajar', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(26, 'Arief Satria Budiman', '13-2-2020', '13-8-2020', 'PT Central Mega Kencana', 'Sertifikat', '2689004517', '24571317', '0000001', 'Borrow', NULL, NULL, NULL, 'Perpanjangan Sertifikat No. 584/Harjamekar', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Adi Fajar', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, 'Arief Satria Budiman', NULL, 'Arief Satria Budiman', '1', '1', '1', '1', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '16:29', 0, '0', NULL, '16:23', '0', 0, 'February 17, 2020, 8:46 am', 'Adi Fajar', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(27, 'Arief Satria Budiman', '18-2-2020', '18-5-2020', 'PT. ULTRA PRIMA ABADI', 'Perubahan PK', '0359006057', '', '0000003', 'Borrow', NULL, NULL, NULL, 'Perubahan PK No. 14 tgl 10-01-2019\r\nu/ koreksi notaris', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '1', '0', '0', '1', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, 'tambah keterangan koreksi notaris ,by: Cicilia Prima Widi Astuti', '10:33', 0, '0', NULL, '11:00', '0', 0, 'February 18, 2020, 17:14 pm', 'Teguh Waspada', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', ''),
(28, 'Carissa Kurniawan', '14-2-2020', '21-2-2020', 'PT Catur Sentosa Adiprana', 'CD Daftar Persediaan Periode Desember 2019', '', '10387728; 15625742', '', 'Borrow', NULL, NULL, NULL, '1 CD persediaan Desember 2019, untuk dimintakan datanya oleh GARK', NULL, NULL, '0', 'Dewi Virgina', 'Adi Fajar', 'Teguh Waspada', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '1', '1', '1', '1', '0', '0', '0', '0', '1', NULL, NULL, NULL, NULL, '13:50', 0, '0', NULL, '11:01', '0', 0, 'February 19, 2020, 14:07 pm', 'Adi Fajar', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', '', '', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mscams`
--

CREATE TABLE `mscams` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `transdate` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `norek` varchar(255) DEFAULT NULL,
  `nokom` varchar(255) DEFAULT NULL,
  `kategoridok5` varchar(255) DEFAULT NULL,
  `namadok5` varchar(255) DEFAULT NULL,
  `nomorjam5` varchar(255) DEFAULT NULL,
  `tipedok5` varchar(255) DEFAULT NULL,
  `nomordok5` varchar(255) DEFAULT NULL,
  `tahundok5` varchar(255) DEFAULT NULL,
  `fisikdok5` varchar(255) DEFAULT NULL,
  `ketdok5` varchar(1000) DEFAULT NULL,
  `file5` varchar(255) DEFAULT NULL,
  `acc5` varchar(255) DEFAULT NULL,
  `kategoridok4` varchar(255) DEFAULT NULL,
  `namadok4` varchar(255) DEFAULT NULL,
  `nomorjam4` varchar(255) DEFAULT NULL,
  `tipedok4` varchar(255) DEFAULT NULL,
  `nomordok4` varchar(255) DEFAULT NULL,
  `tahundok4` varchar(255) DEFAULT NULL,
  `fisikdok4` varchar(255) DEFAULT NULL,
  `ketdok4` varchar(1000) DEFAULT NULL,
  `file4` varchar(255) DEFAULT NULL,
  `acc4` varchar(255) DEFAULT NULL,
  `kategoridok3` varchar(255) DEFAULT NULL,
  `namadok3` varchar(255) DEFAULT NULL,
  `nomorjam3` varchar(255) DEFAULT NULL,
  `tipedok3` varchar(255) DEFAULT NULL,
  `nomordok3` varchar(255) DEFAULT NULL,
  `tahundok3` varchar(255) DEFAULT NULL,
  `fisikdok3` varchar(255) DEFAULT NULL,
  `ketdok3` varchar(1000) DEFAULT NULL,
  `file3` varchar(255) DEFAULT NULL,
  `acc3` varchar(255) DEFAULT NULL,
  `kategoridok2` varchar(255) DEFAULT NULL,
  `namadok2` varchar(255) DEFAULT NULL,
  `nomorjam2` varchar(255) DEFAULT NULL,
  `tipedok2` varchar(255) DEFAULT NULL,
  `nomordok2` varchar(255) DEFAULT NULL,
  `tahundok2` varchar(255) DEFAULT NULL,
  `fisikdok2` varchar(255) DEFAULT NULL,
  `ketdok2` varchar(1000) DEFAULT NULL,
  `file2` varchar(255) DEFAULT NULL,
  `acc2` varchar(255) DEFAULT NULL,
  `kategoridok1` varchar(255) DEFAULT NULL,
  `namadok1` varchar(255) DEFAULT NULL,
  `nomorjam1` varchar(255) DEFAULT NULL,
  `tipedok1` varchar(255) DEFAULT NULL,
  `nomordok1` varchar(255) DEFAULT NULL,
  `tahundok1` varchar(255) DEFAULT NULL,
  `fisikdok1` varchar(255) DEFAULT NULL,
  `ketdok1` varchar(1000) DEFAULT NULL,
  `file1` varchar(255) DEFAULT NULL,
  `acc1` varchar(255) DEFAULT NULL,
  `tanggaljan5` varchar(255) DEFAULT NULL,
  `renewaldok5` varchar(255) DEFAULT NULL,
  `tanggaljan4` varchar(255) DEFAULT NULL,
  `renewaldok4` varchar(255) DEFAULT NULL,
  `tanggaljan3` varchar(255) DEFAULT NULL,
  `renewaldok3` varchar(255) DEFAULT NULL,
  `tanggaljan2` varchar(255) DEFAULT NULL,
  `renewaldok2` varchar(255) DEFAULT NULL,
  `tanggaljan1` varchar(255) DEFAULT NULL,
  `renewaldok1` varchar(255) DEFAULT NULL,
  `tandaterima1` varchar(5) NOT NULL,
  `tandaterima2` varchar(5) NOT NULL,
  `tandaterima3` varchar(5) NOT NULL,
  `tandaterima4` varchar(5) NOT NULL,
  `tandaterima5` varchar(5) NOT NULL,
  `detail` varchar(1000) DEFAULT NULL,
  `detailpik` varchar(1000) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `filepik` varchar(255) DEFAULT NULL,
  `alkhcname` varchar(255) NOT NULL,
  `pic1name` varchar(255) DEFAULT NULL,
  `pic2name` varchar(255) DEFAULT NULL,
  `pikhcname` varchar(255) DEFAULT NULL,
  `pikhcname2` varchar(255) DEFAULT NULL,
  `alkop` varchar(255) DEFAULT NULL,
  `alkhc` varchar(255) NOT NULL,
  `pikop` varchar(255) NOT NULL,
  `pikhc1` varchar(255) DEFAULT NULL,
  `pikhc2` varchar(255) DEFAULT NULL,
  `flagrejected` varchar(255) DEFAULT NULL,
  `flagrejectedpik` varchar(255) DEFAULT NULL,
  `flagpiktoalk` int(11) NOT NULL DEFAULT '0',
  `pikprogress` varchar(255) NOT NULL,
  `comreject` varchar(255) DEFAULT NULL,
  `waktu` varchar(255) DEFAULT NULL,
  `diserahkan` int(11) NOT NULL DEFAULT '0',
  `clusterhold` varchar(255) NOT NULL DEFAULT '0',
  `tgldiserahkan` varchar(255) DEFAULT NULL,
  `waktualk` varchar(255) DEFAULT NULL,
  `waktupik` varchar(255) NOT NULL,
  `waktupikhc` varchar(255) NOT NULL,
  `pikhc3` varchar(255) NOT NULL DEFAULT '0',
  `reminder` int(5) DEFAULT '0',
  `reminderdate` varchar(255) DEFAULT NULL,
  `lokasibg` varchar(255) DEFAULT NULL,
  `rekgiro` varchar(255) DEFAULT NULL,
  `adminis` varchar(255) DEFAULT NULL,
  `komisi` varchar(255) DEFAULT NULL,
  `bataswaktu` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `typeextra` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `mscams`
--

INSERT INTO `mscams` (`id`, `username`, `transdate`, `company`, `norek`, `nokom`, `kategoridok5`, `namadok5`, `nomorjam5`, `tipedok5`, `nomordok5`, `tahundok5`, `fisikdok5`, `ketdok5`, `file5`, `acc5`, `kategoridok4`, `namadok4`, `nomorjam4`, `tipedok4`, `nomordok4`, `tahundok4`, `fisikdok4`, `ketdok4`, `file4`, `acc4`, `kategoridok3`, `namadok3`, `nomorjam3`, `tipedok3`, `nomordok3`, `tahundok3`, `fisikdok3`, `ketdok3`, `file3`, `acc3`, `kategoridok2`, `namadok2`, `nomorjam2`, `tipedok2`, `nomordok2`, `tahundok2`, `fisikdok2`, `ketdok2`, `file2`, `acc2`, `kategoridok1`, `namadok1`, `nomorjam1`, `tipedok1`, `nomordok1`, `tahundok1`, `fisikdok1`, `ketdok1`, `file1`, `acc1`, `tanggaljan5`, `renewaldok5`, `tanggaljan4`, `renewaldok4`, `tanggaljan3`, `renewaldok3`, `tanggaljan2`, `renewaldok2`, `tanggaljan1`, `renewaldok1`, `tandaterima1`, `tandaterima2`, `tandaterima3`, `tandaterima4`, `tandaterima5`, `detail`, `detailpik`, `file`, `filepik`, `alkhcname`, `pic1name`, `pic2name`, `pikhcname`, `pikhcname2`, `alkop`, `alkhc`, `pikop`, `pikhc1`, `pikhc2`, `flagrejected`, `flagrejectedpik`, `flagpiktoalk`, `pikprogress`, `comreject`, `waktu`, `diserahkan`, `clusterhold`, `tgldiserahkan`, `waktualk`, `waktupik`, `waktupikhc`, `pikhc3`, `reminder`, `reminderdate`, `lokasibg`, `rekgiro`, `adminis`, `komisi`, `bataswaktu`, `type`, `typeextra`) VALUES
(1, 'Maria Gretalita Niken Winaputri', '16-10-2019', 'PT. Ace Hardware Indonesia, Tbk', '2059001625', '001', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', 'PINJAMAN', 'SPPK', '-', 'Asli', '10747/GBK/2019', '2019', 'Hardcopy', '8/10/2019', '', '1', 'PINJAMAN', 'SPK', '-', 'Asli', '-', '2019', 'Hardcopy', '18/6/2019', '', '1', '', '', '', '', '', '', '-', '', '-', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 1, '0', 'TIDAK SESUAI FISIK DENGAN ORDERAN', '09:59', 0, '0', NULL, '', '', '', '1', 0, 'October 28, 2019, 1:31 pm', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'Maria Gretalita Niken Winaputri', '16-10-2019', 'Dynaplast Grup', '2059006805', '001', 'PINJAMAN', 'SPPJS (Surat pemberitahuan Ppj Sementara)', '-', 'Asli', '10399/GBK/2019', '2019', 'Hardcopy', '9/7/2019', '', '1', 'PINJAMAN', 'SPPK', '-', 'Asli', '10744/GBK/2019', '2019', 'Hardcopy', '4/10/2019', '', '1', 'PINJAMAN', 'SPK', '-', 'Asli', '-', '2019', 'Hardcopy', '17/9/2019', '', '1', 'PINJAMAN', 'LKK (Lembar Keputusan Kredit) / MPK / MEMORANDUM', '-', 'Asli', '10281/MO/GBK/2019', '2019', 'Hardcopy', '14/10/2019 (Memo Pembatalan King Plastic)', '', '1', 'PINJAMAN', 'LKK (Lembar Keputusan Kredit) / MPK / MEMORANDUM', '-', 'Asli', '1062/MO/SKI/2019', '2019', 'Hardcopy', '1/10/2019', '', '1', '-', '', '-', '', '-', '', '-', '', '-', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '09:37', 0, '0', NULL, '09:22', '', '', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'Maria Gretalita Niken Winaputri', '16-10-2019', 'PT. Kawan Lama Sejahtera', '0069011324', '001', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', 'PINJAMAN', 'LKK (Lembar Keputusan Kredit) / MPK / MEMORANDUM', '-', 'Asli', '10270/MO/GBK/2019', '2019', 'Hardcopy', '3/10/2019 (Hapus syarat peningkatan HT, konversi KL ke BG & PBMM, PBMM dpt digunakan TGI)', '', '0', '', '', '', '', '', '', '', '', '-', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '09:58', 0, '0', NULL, '09:39', '', '', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'Conny Yusran', '16-10-2019', 'PT. GENERAL FOOD INDUSTRY', '3469001050', '001', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', 'PINJAMAN', 'SPPJS (Surat pemberitahuan Ppj Sementara)', '', 'Asli', '10677', '2019', 'Hardcopy', '', '', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '09:58', 0, '0', NULL, '09:48', '', '', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 'Conny Yusran', '16-10-2019', 'PT. TIRTA FRESINDO JAYA', '2059003067', '016', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', 'PINJAMAN', 'Daftar Angsuran', '', 'Asli', '', '2019', 'Hardcopy', 'TABEL ANGS KI 6', '', '1', 'PINJAMAN', 'Daftar Angsuran', '', 'Asli', '', '2019', 'Hardcopy', 'TABEL ANGS KI 7', '', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '09:57', 0, '0', NULL, '09:50', '', '', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 'Nadia Wohon', '18-10-2019', 'PT Indoguna Utama', '2059007780', '001', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', 'PINJAMAN', 'Surat Lain - lain terkait Pinjaman', '', 'Harian', '', '2019', 'Softcopy', 'email konfirmasi GHK terhadap perjanjian pinjam pakai', '1571295560-CAMS_FWMemoKonversiKIGrupIndoguna&PersetujuanPinjamPakaiTanah(GrupMariaElizabethLiman).msg', '0', 'JAMINAN', 'Perjanjian Pengalihan Hak', '44334167', 'Harian', '68', '2019', 'Softcopy', 'Perjanjian Pinjam Pakai Tanah No. 68 tgl 31-08-2019', '1571295560-CAMS_AKTEPERJANJIANPINJAMPAKAITANAHNO.68TGL.31AGS19CIKUPA.PDF', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '09:48', 0, '0', NULL, '08:59', '', '', '1', 0, 'October 23, 2019, 8:27 am', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 'Nadia Wohon', '18-10-2019', 'PT Dunia Kimia Utama', '2059005442', '001', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', 'DEBITUR', 'Laporan Keuangan Internal', '', 'Harian', '', '2019', 'Softcopy', 'LKI per Juni 2019', '1571295639-CAMS_RELKinternalDKUMIIAIATI.msg', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '09:48', 0, '0', NULL, '09:00', '', '', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 'Nadia Wohon', '18-10-2019', 'PT Mahkota Indonesia', '0359302624', '001', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', 'DEBITUR', 'Laporan Keuangan Internal', '', 'Harian', '', '2019', 'Softcopy', 'LKI per Juni 2019', '1571295714-CAMS_RELKinternalDKUMIIAIATI.msg', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '09:48', 0, '0', NULL, '09:01', '', '', '1', 0, 'October 23, 2019, 8:27 am', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 'Nadia Wohon', '18-10-2019', 'PT Indonesian Acids Industry', '0359093545', '005', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', 'DEBITUR', 'Laporan Keuangan Internal', '', 'Harian', '', '2019', 'Softcopy', 'LKI per Juni 2019', '1571295771-CAMS_RELKinternalDKUMIIAIATI.msg', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '09:48', 0, '0', NULL, '09:02', '', '', '1', 0, 'October 23, 2019, 8:27 am', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 'Nadia Wohon', '18-10-2019', 'PT Indomaguro Tunas Unggul', '2059006635', '003', 'JAMINAN', 'Daftar Mesin/ Surat Pernyataan Mesin', '40283038', 'Asli', '191/ITU/VIII/2016', '2016', 'Hardcopy', 'Surat Pernyataan + Daftar Mesin', '', '0', 'JAMINAN', 'DO (Delivery Order) & daftar persediaan barang', '40282980', 'Asli', '169/ITU/VII/2016', '2016', 'Hardcopy', 'Surat Pernyataan + Daftar Persediaan', '', '0', 'JAMINAN', 'Daftar piutang/surat pernyataan penyerahan piutang', '40282964', 'Asli', '190/ITU/VII/2016', '2016', 'Hardcopy', 'Rincian Umur Piutang', '', '0', 'JAMINAN', 'Daftar piutang/surat pernyataan penyerahan piutang', '40282964', 'Asli', '168/ITU/VII/2016', '2016', 'Hardcopy', 'Surat Pernyataan + Daftar Piutang', '', '0', 'JAMINAN', 'Bilyet deposito', '40283020', 'Asli', 'AJ 563551', '2019', 'Hardcopy', 'Deposito + DOG', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '09:48', 0, '0', NULL, '09:41', '', '', '1', 0, 'October 23, 2019, 8:27 am', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(11, 'Nadia Wohon', '18-10-2019', 'PT Indomaguro Tunas Unggul', '2059006635', '003', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', 'JAMINAN', 'Surat persetujuan suami / istri', '40282972', 'Asli', '', '2016', 'Hardcopy', 'Surat Persetujuan Istri an. Poppi Kusumah tgl 16-08-16', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '09:49', 0, '0', NULL, '09:46', '', '', '1', 0, 'October 23, 2019, 8:27 am', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12, 'Endru Sanjaya', '18-10-2019', 'PT. Bumimulia Indah Lestari', '035-930-1644', '001', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', 'JAMINAN', 'Daftar piutang/surat pernyataan penyerahan piutang', '25848425', 'Asli', '001/VI/2019', '2019', 'Hardcopy', '', '', '0', 'JAMINAN', 'DO (Delivery Order) & daftar persediaan barang', '25848300', 'Asli', '001/VI/2019', '2019', 'Hardcopy', '', '', '0', 'PINJAMAN', 'LKK (Lembar Keputusan Kredit) / MPK / MEMORANDUM', '', 'Asli', '10277/MO/GBK/2019', '2019', 'Hardcopy', '', '', '0', '', '', '', '', '', '6 Bulanan', '', '6 Bulanan', '', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '10:34', 0, '0', NULL, '10:32', '', '', '1', 0, 'October 23, 2019, 8:27 am', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(13, 'Maria Gretalita Niken Winaputri', '18-10-2019', 'PT. Kawan Lama Sejahtera', '0069011324', '001', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', 'PINJAMAN', 'SPPJS (Surat pemberitahuan Ppj Sementara)', '-', 'Asli', '10722/GBK/2019', '2019', 'Hardcopy', '24/9/2019 SPP2', '', '0', 'PINJAMAN', 'LKK (Lembar Keputusan Kredit) / MPK / MEMORANDUM', '-', 'Asli', '10249/MO/GBK/2019', '2019', 'Hardcopy', '20/9/2019 \r\n -\r\n Penegasan MPK 640/MO/SKI/2019', '', '0', '', '', '', '', '', '', '-', '', '-', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '10:35', 0, '0', NULL, '10:34', '', '', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(14, 'Endru Sanjaya', '18-10-2019', 'PT. Haldin Pacific Semesta', '205-900-9901', '001', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', 'PINJAMAN', 'SPK', '', 'Asli', '', '2019', 'Hardcopy', '', '', '0', 'PINJAMAN', 'SPPK', '', 'Asli', '10544/GBK/2091', '2019', 'Hardcopy', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '10:35', 0, '0', NULL, '10:35', '', '', '1', 0, 'October 21, 2019, 1:37 pm', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(15, 'Endru Sanjaya', '18-10-2019', 'PT. Bukit Jaya Semesta', '205-900-2648', '002', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', 'JAMINAN', 'IMB', '51824423', 'Asli', '503/230/A/DPMPTSP', '2019', 'Hardcopy', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '10:39', 0, '0', NULL, '10:38', '', '', '1', 0, 'October 23, 2019, 8:28 am', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(16, 'Endru Sanjaya', '18-10-2019', 'PT. PKG Lautan Indonesia', '205-900-0084', '004', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', 'PINJAMAN', 'SPK', '', 'Asli', '', '2019', 'Hardcopy', '', '', '0', 'PINJAMAN', 'SPPK', '', 'Asli', '10528/GBK/2019', '2019', 'Hardcopy', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '10:49', 0, '0', NULL, '10:40', '', '', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(17, 'Endru Sanjaya', '18-10-2019', 'PT. Plasindo Lestari', '035-900-6448', '002', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', 'PINJAMAN', 'Addendum / Perubahan Perjanjian Kredit', '', 'Asli', '205.349/Add-KCK/2019', '2019', 'Hardcopy', '', '', '0', 'PINJAMAN', 'LKK (Lembar Keputusan Kredit) / MPK / MEMORANDUM', '', 'Asli', '10264/MO/GBK/2019', '2019', 'Hardcopy', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '10:49', 0, '0', NULL, '10:42', '', '', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(18, 'Endru Sanjaya', '18-10-2019', 'PT. Dunia Kimia Jaya', '035-930-1814', '002', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', 'PINJAMAN', 'LKK (Lembar Keputusan Kredit) / MPK / MEMORANDUM', '', 'Asli', '10231/MO/GBK/2019', '2019', 'Hardcopy', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '10:50', 0, '0', NULL, '10:44', '', '', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21, 'Endru Sanjaya', '17-10-2019', 'PT. Pacinesia Chemical Industry', '205-907-1372', '002', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', 'PINJAMAN', 'Surat Kuasa Transaksi (PBMM/Forex/Ekspor/Impor)', '', 'Asli', '90/FIN/PACI/2019', '2019', 'Hardcopy', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '10:50', 0, '0', NULL, '10:48', '', '', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(22, 'Maria Gretalita Niken Winaputri', '18-10-2019', 'PT. Polytech Indo Hausen', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', 'JAMINAN', 'Tanda terima jaminan', '14494249', 'Asli', '505/TTD/KCK/X/2019', '2019', 'Hardcopy', 'IMB Rawa Arum', '', '0', '', '', '', '', '', '', '', '', '-', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '10:50', 0, '0', NULL, '10:49', '', '', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(23, 'Maria Gretalita Niken Winaputri', '18-10-2019', 'PT. Panca Budi Pratama', '0359303507', '009', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', 'JAMINAN', 'Tanda terima jaminan', '43171651', 'Asli', '504/TTD/KCK/X/2019', '2019', 'Hardcopy', '7/10/2019 - IMB Blok FF 8N, AE, AF', '', '0', '', '', '', '', '', '', '', '', '-', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '10:54', 0, '0', NULL, '10:53', '', '', '1', 0, 'October 25, 2019, 9:22 am', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(24, 'Maria Gretalita Niken Winaputri', '18-10-2019', 'PT. Miller Weldindo', '0359303388', '002', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', 'PINJAMAN', 'SPPJS (Surat pemberitahuan Ppj Sementara)', '-', 'Asli', '11090/GBK/2018', '2018', 'Hardcopy', '10/12/2018 - SPP1', '', '0', '', '', '', '', '', '', '', '', '-', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '10:58', 0, '0', NULL, '10:56', '', '', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(25, 'Endru Sanjaya', '18-10-2019', 'PT. Chandra Asri Petrochemical', '035-930-3965', '002', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', 'DEBITUR', 'Surat Pernyataan beda nama / beda tanda tangan', '', 'Harian', '', '2019', 'Hardcopy', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '11:13', 0, '0', NULL, '11:02', '', '', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(26, 'Endru Sanjaya', '18-10-2019', 'PT. Margo Mulyo', '035-900-7541', '001', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '0', 'DEBITUR', 'Surat-surat BCA ke debitur', '', 'Harian', '10683/GBK/2019', '2019', 'Hardcopy', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '11:13', 0, '0', NULL, '11:11', '', '', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(27, 'Maria Gretalita Niken Winaputri', '18-10-2019', 'PT. Kabulinco Jaya', '2059002222', '001', '', '', '', '', '', '', '', '', '', '0', 'JAMINAN', 'Daftar piutang/surat pernyataan penyerahan piutang', '15690670', 'Asli', 'KJ-AR/BCA.001/03/19', '2019', 'Hardcopy', 'NON AKTIF', '', '0', 'JAMINAN', 'DO (Delivery Order) & daftar persediaan barang', '15690621', 'Asli', 'KJ-INV/BCA.002/03/19 ', '2019', 'Hardcopy', 'NON AKTIF', '', '0', 'JAMINAN', 'Daftar piutang/surat pernyataan penyerahan piutang', '15690670', 'Asli', 'KJ-AR/BCA.005/10/19', '2019', 'Hardcopy', 'Per Sept 2019', '', '0', 'JAMINAN', 'DO (Delivery Order) & daftar persediaan barang', '15690621', 'Asli', 'KJ-INV/BCA.006/10/19', '2019', 'Hardcopy', 'Per Sept 2019', '', '0', '', '', '-', '', '-', '', '31/1/2020', '3 Bulanan', '31/1/2020', '3 Bulanan', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Claudio Ucandra Negara', 'Finda Ariesta Mulia', 'Moch. Tri Wicaksono', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '11:22', 0, '0', NULL, '11:20', '', '', '1', 0, 'October 23, 2019, 8:28 am', NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `mscamscategory`
--

CREATE TABLE `mscamscategory` (
  `id` int(11) NOT NULL,
  `Category` varchar(255) DEFAULT NULL,
  `Name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `mscamscategory`
--

INSERT INTO `mscamscategory` (`id`, `Category`, `Name`) VALUES
(1, 'DEBITUR', 'AMDAL'),
(2, 'DEBITUR', 'Akte Perubahan'),
(3, 'DEBITUR', 'Akte cerai'),
(4, 'DEBITUR', 'Akte pembagian / keterangan waris'),
(5, 'DEBITUR', 'Akte pemisahan harta / perjanjian nikah'),
(6, 'DEBITUR', 'Anggaran Dasar / Akte pendirian perusahaan'),
(7, 'DEBITUR', 'BNRI (Berita Negara RI)'),
(8, 'DEBITUR', 'Covenant monitoring'),
(9, 'DEBITUR', 'Dokumen Identitas'),
(10, 'DEBITUR', 'Fotocopy WNI'),
(11, 'DEBITUR', 'Izin Tetap Usaha Perjalanan'),
(12, 'DEBITUR', 'KITAS/KITAP'),
(13, 'DEBITUR', 'KTP'),
(14, 'DEBITUR', 'Kartu Keluarga'),
(15, 'DEBITUR', 'Laporan Aging Schedule'),
(16, 'DEBITUR', 'Laporan Daftar Tenant'),
(17, 'DEBITUR', 'Laporan Keuangan Audited'),
(18, 'DEBITUR', 'Laporan Keuangan Internal'),
(19, 'DEBITUR', 'Laporan Kontak Sewa'),
(20, 'DEBITUR', 'Laporan Manajemen'),
(21, 'DEBITUR', 'Laporan Pendapatan'),
(22, 'DEBITUR', 'Laporan Penjualan'),
(23, 'DEBITUR', 'Laporan Penyelesaian Proyek'),
(24, 'DEBITUR', 'Laporan Perkembangan Proyek'),
(25, 'DEBITUR', 'Laporan Produksi'),
(26, 'DEBITUR', 'Laporan Volume Produksi'),
(27, 'DEBITUR', 'Memorandum of Understanding'),
(28, 'DEBITUR', 'NPWP'),
(29, 'DEBITUR', 'Passport'),
(30, 'DEBITUR', 'Pendaftaran ke Deperindag'),
(31, 'DEBITUR', 'Pengesahan/ persetujuan / pelaporan kehakiman'),
(32, 'DEBITUR', 'Profil Perusahaan + PK Bank Lain'),
(33, 'DEBITUR', 'Resi Perpj dr Inst Terkait ( Jk id dlm proses)'),
(34, 'DEBITUR', 'Ringkasan anggaran dasar (jatuh tempo pengurus)'),
(35, 'DEBITUR', 'SIM'),
(36, 'DEBITUR', 'SIUP'),
(37, 'DEBITUR', 'Surat Ijin Tempat / Surat Keterangan Tempat Usaha'),
(38, 'DEBITUR', 'Surat Ket Notaris yg menyatakan Akte Pendirian'),
(39, 'DEBITUR', 'Surat Keterangan Beda Nama (Dok Asli)'),
(40, 'DEBITUR', 'Surat Keterangan Domisili'),
(41, 'DEBITUR', 'Surat Keterangan Ganti Nama'),
(42, 'DEBITUR', 'Surat Lain-lain'),
(43, 'DEBITUR', 'Surat Penetapan pengangkatan Wali'),
(44, 'DEBITUR', 'Surat Pernyataan Penyerahan Anggaran Dasar'),
(45, 'DEBITUR', 'Surat Pernyataan ahli waris'),
(46, 'DEBITUR', 'Surat Pernyataan beda nama / beda tanda tangan'),
(47, 'DEBITUR', 'Surat pernyataan tidak pernah menikah secara hukum'),
(48, 'DEBITUR', 'Surat perpanjangan Pengangkatan Dealer'),
(49, 'DEBITUR', 'Surat-surat BCA ke debitur'),
(50, 'DEBITUR', 'TDP'),
(51, 'DEBITUR', 'Tanda Daftar Usaha Perdagangan'),
(52, 'DEBITUR', 'API /APIS/ APIT (Angka Pengenal Impor/ Sementara/'),
(53, 'JAMINAN', 'Surat persetujuan suami / istri'),
(54, 'PINJAMAN', 'Surat persetujuan Komisaris'),
(55, 'PINJAMAN', 'Addendum / Perubahan Perjanjian Kredit'),
(56, 'PINJAMAN', 'BCR / MIP'),
(57, 'PINJAMAN', 'Bilyet Bank Garansi'),
(58, 'PINJAMAN', 'Daftar Angsuran'),
(59, 'PINJAMAN', 'LKK (Lembar Keputusan Kredit) / MPK / MEMORANDUM'),
(60, 'PINJAMAN', 'Letter of Undertaking'),
(61, 'PINJAMAN', 'PK (Perjanjian Kredit)'),
(62, 'PINJAMAN', 'PPBG (Perjanjian Pemberian Bank Garansi)'),
(63, 'PINJAMAN', 'Pendapat Hukum (Legal Opinion)'),
(64, 'PINJAMAN', 'Perjanjian Forex/ISDA'),
(65, 'PINJAMAN', 'Perjanjian Lain-Lain'),
(66, 'PINJAMAN', 'Perjanjian Negosiasi Fasilitas LG'),
(67, 'PINJAMAN', 'Perjanjian Pemberian Fasilitas Intraday'),
(68, 'PINJAMAN', 'Perjanjian Pengelolaan Rekening'),
(69, 'PINJAMAN', 'Perjanjian Restrukturisasi'),
(70, 'PINJAMAN', 'Perubahan PPBG'),
(71, 'PINJAMAN', 'Polis Asuransi'),
(72, 'PINJAMAN', 'SPK'),
(73, 'PINJAMAN', 'SPPJS (Surat pemberitahuan Ppj Sementara)'),
(74, 'PINJAMAN', 'SPPK'),
(75, 'PINJAMAN', 'Sales Contract / SPJB/ Purchase agreement'),
(76, 'PINJAMAN', 'Stand by LC'),
(77, 'PINJAMAN', 'Surat Kuasa Transaksi (PBMM/Forex/Ekspor/Impor)'),
(78, 'PINJAMAN', 'Surat Lain - lain terkait Pinjaman'),
(79, 'PINJAMAN', 'Surat Pengantar Broker'),
(80, 'PINJAMAN', 'Surat Penunjukkan'),
(81, 'PINJAMAN', 'Surat Perintah Kerja'),
(82, 'PINJAMAN', 'Surat Perjanjian / kontrak Kerja Sama'),
(83, 'PINJAMAN', 'Surat Perjanjian Subordinasi Hutang'),
(84, 'PINJAMAN', 'Surat Pernyataan Pemegang Saham'),
(85, 'PINJAMAN', 'Surat Pernyataan dari Debitur Terkait Pinjaman'),
(86, 'PINJAMAN', 'Surat Persetujuaan RUPS untuk Perjanjian Kredit'),
(87, 'PINJAMAN', 'Surat kuasa penanda tanganan kredit'),
(88, 'PINJAMAN', 'Surat/Perjanjian Kesanggupan'),
(89, 'JAMINAN', 'APHT (Akte Pembebanan Hak Tanggungan)'),
(90, 'JAMINAN', 'Akta Hibah/Petikan Risalah Lelang'),
(91, 'JAMINAN', 'Akta Kuasa untuk Memasang Hipotik'),
(92, 'JAMINAN', 'Akta Pernyataan dan Kuasa - Kapal'),
(93, 'JAMINAN', 'Akta Pernyataan Bersama'),
(94, 'JAMINAN', 'Akte Borghtocht (PG/CG)'),
(95, 'JAMINAN', 'Akte Cessie'),
(96, 'JAMINAN', 'Akte Fidusia'),
(97, 'JAMINAN', 'Akte Hipotik'),
(98, 'JAMINAN', 'Akte jual beli'),
(99, 'JAMINAN', 'Appraisal Independent / BAP'),
(100, 'JAMINAN', 'BPKB (Bukti Pemilikan Kendaraan Bermotor)'),
(101, 'JAMINAN', 'Bank Garansi / Counter Guarantee'),
(102, 'JAMINAN', 'Bankers clause asuransi kerugian'),
(103, 'JAMINAN', 'Berita Acara Penyerahan Jaminan'),
(104, 'JAMINAN', 'Berita Acara Serah Terima (BAST)'),
(105, 'JAMINAN', 'Bilyet deposito'),
(106, 'JAMINAN', 'Bukti Bayar Premi'),
(107, 'JAMINAN', 'Cek keaslian dokumen kapal'),
(108, 'JAMINAN', 'Cover note notaris untuk jaminan dan pengikatan ja'),
(109, 'JAMINAN', 'Cover Note Asuransi'),
(110, 'JAMINAN', 'DO (Delivery Order) & daftar persediaan barang'),
(111, 'JAMINAN', 'Daftar Kendaraan'),
(112, 'JAMINAN', 'Daftar Mesin/ Surat Pernyataan Mesin'),
(113, 'JAMINAN', 'Daftar Obyek Gadai'),
(114, 'JAMINAN', 'Daftar Pemegang Saham'),
(115, 'JAMINAN', 'Daftar piutang/surat pernyataan penyerahan piutang'),
(116, 'JAMINAN', 'Faktur barang'),
(117, 'JAMINAN', 'Faktur kendaraan'),
(118, 'JAMINAN', 'Gambar blue print bangunan'),
(119, 'JAMINAN', 'Gambar situasi'),
(120, 'JAMINAN', 'Grosse akta balik nama'),
(121, 'JAMINAN', 'Grosse akta pendaftaran kapal laut'),
(122, 'JAMINAN', 'IMB'),
(123, 'JAMINAN', 'Konfirmasi pemblokiran dari BCA Kustodian'),
(124, 'JAMINAN', 'Kwitansi / faktur pembelian mesin & daftar mesin'),
(125, 'JAMINAN', 'Kwitansi Blanko'),
(126, 'JAMINAN', 'Kwitansi Pembelian'),
(127, 'JAMINAN', 'Kwitansi pembayaran uang muka kendaraan'),
(128, 'JAMINAN', 'Kwitansi pembelian emas'),
(129, 'JAMINAN', 'Memo permohonan blokir (Deposito/Giro/Saham)'),
(130, 'JAMINAN', 'Minuta SKMHT'),
(131, 'JAMINAN', 'PBB'),
(132, 'JAMINAN', 'Pas Tahunan - Kapal (Asli/ Copy)'),
(133, 'JAMINAN', 'Pemblokiran kendaraan bermotor'),
(134, 'JAMINAN', 'Pengecekan kendaraan bermotor'),
(135, 'JAMINAN', 'Pengumuman penjaminan di surat kabar'),
(136, 'JAMINAN', 'Perjanjian Gadai'),
(137, 'JAMINAN', 'Perjanjian Hak Tempat Usaha (PHTPU)'),
(138, 'JAMINAN', 'Perjanjian Keagenan dan Pembagian Hasil Agunan'),
(139, 'JAMINAN', 'Perjanjian Pengalihan Hak'),
(140, 'JAMINAN', 'Perjanjian Pengalihan atas Hak Sewa'),
(141, 'JAMINAN', 'Perjanjian Sewa - Kapal (Asli/ Copy)'),
(142, 'JAMINAN', 'Perjanjian Sewa Menyewa'),
(143, 'JAMINAN', 'Pernyataan direksi/RUPS penyerahan Asset'),
(144, 'JAMINAN', 'Persetujuan pemilik/pengelola u/ mengagunkan kios'),
(145, 'JAMINAN', 'Persetujuan saudara/anak u/ pengikatan jaminan'),
(146, 'JAMINAN', 'SKMHT (Surat Kuasa Memasang Hak Tanggungan)'),
(147, 'JAMINAN', 'SP bersedia tambah jaminan bila harga emas turun'),
(148, 'JAMINAN', 'SPPJB (Perjanjian Pengikatan Jual Beli)'),
(149, 'JAMINAN', 'Sertifikat'),
(150, 'JAMINAN', 'Sertifikat Hak Tanggungan'),
(151, 'JAMINAN', 'Sertifikat Hipotik (jaminan Kapal)'),
(152, 'JAMINAN', 'Sertifikat Kadar Emas'),
(153, 'JAMINAN', 'Sertifikat Keselamatan - Kapal (Asli/ Copy)'),
(154, 'JAMINAN', 'Sertifikat Konstruksi - Kapal'),
(155, 'JAMINAN', 'Sertifikat Pendaftaran Fidusia'),
(156, 'JAMINAN', 'Sertifikat deposito'),
(157, 'JAMINAN', 'Stand by LC'),
(158, 'JAMINAN', 'Surat Kelengkapan Peralatan - Kapal'),
(159, 'JAMINAN', 'Surat Kuasa menjaminkan'),
(160, 'JAMINAN', 'Surat Laut - Kapal (Asli/ Copy)'),
(161, 'JAMINAN', 'Surat Nilai Pertanggungan'),
(162, 'JAMINAN', 'Surat Pemblokiran utk Jaminan Kios'),
(163, 'JAMINAN', 'Surat Peminjaman Sementara'),
(164, 'JAMINAN', 'Surat Perjanjian Pengosongan'),
(165, 'JAMINAN', 'Surat Pernyataan penyewa/ perjanjian sewa'),
(166, 'JAMINAN', 'Surat Persetujuan Pengalihan Piutang'),
(167, 'JAMINAN', 'Surat Persetujuan dari Debitur dan Pemilik Tanah'),
(168, 'JAMINAN', 'Surat Ukur - Kapal (Asli/ Copy)'),
(169, 'JAMINAN', 'Surat blokir (Deposito/Giro/Saham)'),
(170, 'JAMINAN', 'Surat ijin pemakaian kios (SIPTU/SIPTB/dll)'),
(171, 'JAMINAN', 'Surat kelayakan berlayar'),
(172, 'JAMINAN', 'Surat keterangan dari penerima manfaat asuransi'),
(173, 'JAMINAN', 'Surat keterangan deregistration'),
(174, 'JAMINAN', 'Surat kuasa untuk ttd pengikatan jaminan'),
(175, 'JAMINAN', 'Surat pernyataan dari debitur'),
(176, 'JAMINAN', 'Surat pernyataan dari pemberi agunan'),
(177, 'JAMINAN', 'Surat pernyataan dari penerima manfaat asuransi'),
(178, 'JAMINAN', 'Surat pernyataan dari perusahaan asuransi'),
(179, 'JAMINAN', 'Surat persetujuan RUPS'),
(180, 'JAMINAN', 'Surat persetujuan untuk perpanjangan avalist'),
(181, 'JAMINAN', 'Surat saham /bukti kepemilikan saham'),
(182, 'JAMINAN', 'Surat tanda kebangsaan kapal'),
(183, 'JAMINAN', 'Surat ukur '),
(184, 'JAMINAN', 'Tanda terima jaminan'),
(185, 'DEBITUR', 'Akte Nikah'),
(186, 'CUSTOM', 'Custom'),
(187, 'JAMINAN', 'Covernote'),
(188, 'PINJAMAN', 'Covernote'),
(189, 'PINJAMAN', 'Penghapusan Flag Covid 19');

-- --------------------------------------------------------

--
-- Struktur dari tabel `msforum`
--

CREATE TABLE `msforum` (
  `id` int(11) NOT NULL,
  `stamp` bigint(20) NOT NULL,
  `username` varchar(255) NOT NULL,
  `curcol` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `msforum`
--

INSERT INTO `msforum` (`id`, `stamp`, `username`, `curcol`) VALUES
(1, 1551150024, 'Super Admin', 'Dear User,\r\nJika ada <b>masalah, saran, masukan, request</b>, silahkan masukkan ke forum ini untuk mempermudah <b>pengerjaan dan pendataan.</b>\r\nTerima kasih.'),
(2, 1551151249, 'Wilbert Karel Wetik', 'Dear All,..\r\nIni ada medianya lho,.. klo ada saran dan masukan boleh dibicarakan disini yaa..\r\n'),
(3, 1551151350, 'Ganesha Chrysta Dhewie', 'Dear Gengs,\r\nBoleh ga pas di kolom authorize ditambahkan kotak search kayak di bagian view order? Akan memudahkan dalam memeriksa kalau memungkinkan :)'),
(4, 1551151371, 'Dimas Qolifatul Fajerul', 'willem, untuk monitoring surat asli belum bisa di klik ya untuk rinciannya?\r\n'),
(5, 1551151596, 'Nadia Wohon', 'Dear Wil and Jeff,\r\nMau tambah masukan ya apabila tidak ada attachment pada order, mohon untuk diberikan tanda/ diberikan dijadikan field yg wajib diisi. Thankyou yaaa :)'),
(6, 1551151828, 'Sonia Wibisono', 'untuk ALK Operator dibikin bisa lihat keterangan RTGS juga dong :D'),
(7, 1551152765, 'Sonia Wibisono', 'will, tolong diinput manual ke monitor asli order no. 80,81,83,84,85,86 yg diorder menggunakan copy'),
(8, 1551153381, 'Dena Rahmania', 'Wil, tolong diinput manual ke monitor asli order no. 49 dan 50 yg diorder menggunakan copy :)'),
(9, 1551153771, 'Wilbert Karel Wetik', 'Aku Wil juga lho..\r\n'),
(10, 1551154156, 'Super Admin', 'Will, usul alamat url nya pakai computer name aja, cmbadle008, soalnya kalau IP takutnya ada pergantian IP dari KP, ubah shortcut semua user lho...'),
(11, 1551236291, 'Nadia Wohon', 'Dear Wil/ Jeff,\r\ntolong diinput manual monitor asli order di tgl 21-02-2019 no : 36, 38, 39, 40 dan di tgl 22-02-2019 no : 60 >> yg diorder menggunakan copy. Terima kasih :)'),
(12, 1551320489, 'Merina Annisa Noviani', 'hiii genks :) '),
(13, 1551321642, 'Yusuf Patandung', 'oii saya Ucup, mohon bantuannya \r\n'),
(14, 1551322940, 'Resnawati', 'Dear William dimana pun berada,\r\n\r\nuntuk monitorin surat asli, perlu ditambahkan monitoring penerimaan Fisik asli seperti di meeting kemarin.\r\nKarena saat ini, jika dari awal sudah asli statusnya langsung Done. \r\npadahal seharusnya ada tombol serah terima lagi :).'),
(15, 1551775570, 'Super Admin', '<b>Semangat Kevin!!!!!</b>'),
(16, 1551838391, 'Dewi Virgina', 'Pak kalau HC tdk bisa liat rekap surat asli dan copy yg blm diterima yah?\r\n'),
(17, 1551842782, 'Dimas Qolifatul Fajerul', 'dear Willem, atau admin. mohon bantuannya untuk menambahkan fitur upload dokumen di menu realisasi non smile. dan juga untuk fitur realisasi non smile mohon ditambahkan pihak supervisi jika nilai realisasinya mencapai atau melebih 10 milyar rupiah. terima kasih'),
(18, 1552286838, 'Nyimas Wida', '- kolom search agar ditambah kategori no ID\r\n- untuk buka dokumen download bisa di page yang berbeda gak? untuk memudahkan.\r\nThank you\r\n'),
(19, 1552354088, 'Nyimas Wida', 'Untuk HC ALK, bisa dibuat ada notifikasi seperti email gak?'),
(20, 1552376242, 'Bagus Risza Fahrodhi', 'Terima kasih Bapak Wilbert atas kebaikannya mengijinkan saya join dalam aplikasi dan forum ini. '),
(21, 1552442772, 'Wilbert Karel Wetik', '@mas Wida, notifikasi saat ini belum bisa ditampilkan diemail, ke depannya akan bisa dimunculkan bukan hanya diemail, tetapi juga di handphone sehingga HC akan lebih flexibel utk memberikan persetujuan txn'),
(22, 1552443239, 'Wilbert Karel Wetik', '@Dewi, lagi on track untuk ditambahkan di aplikasi, mudah2an bisa digunakan minggu depan'),
(23, 1552445155, 'Wilbert Karel Wetik', '@mas Wida, untuk membuka di page / screen komputer yang berbeda bisa dilakukan untuk membuka file attachment dengan meng-accept di file attachment untuk pilihan : \"Always open files on this type or Always open on system\"... '),
(24, 1552449847, 'Nyimas Wida', 'Mohon ditambahkan fitur berita dari HC ALK langsung ke PIK, jadi tidak perlu kembali ke Operator ALK. Thank you.'),
(25, 1552458049, 'Bagus Risza Fahrodhi', 'Gaesss saya tidak bisa ganti password, udah ganti ke password baru tapi kalo login bisanya cuman pake password lama. ada yg bisa bantu? bingung akutu'),
(26, 1552459399, 'Mega Febrilia', 'Dear Pak WK & Team, mau tambah masukan...kalau bisa field yang untuk attachment tersebut sbb :\r\n1. tidak perlu disave dulu (krn yg terjadi sekarang adalah kita harus save dulu, trs baru browse untuk input attachment file)\r\n2. attachment file bisa lebih dari 1 attachment, karena kalau kita zip2 folder wasting time Pak (note : untuk transaksi rollover PBBMM Grup Wilmar, hampir setiap hari dengan rata2 transaksi adalah 14 transaksi dari semua PT. Dalam setiap orderan tsb selain mencantumkan Surat Konfirmasi Roll Over, juga harus mencantumkan surat konfirmasi PBMM sebelumnya)\r\n\r\nThanks Pak.'),
(27, 1552879816, 'Mega Febrilia', 'Dear Admin,\r\n\r\nSatu lagi masukan...jika ada orderan yang direject untuk direvisi...kalau bisa form terakhir yang telah ALK lengkapi jangan hilang semua, tinggal diubah yang perlu direvisi saja. Karena yg saat ini terjadi jika ada rejectan, ada beberapa field yang hilang, pdhal sebelumnya telah diisi oleh ALK.\r\n\r\nTerima kasih.'),
(28, 1552879818, 'Novita Evani', 'Dear Super Admin, orderan saya yang di reject HC kenapa ga masuk ya? dan statusnya tetap di my Order sebagai pendingan'),
(29, 1553239296, 'Super Admin', 'Dear :\r\n@Mega : akan lebih mudah kali kita memiliki aplikasi Nuance pdf, harus diajukan sebagai budget, setiap anak ALK yg input e-Orhar memiliki aplikasi Nuance pdf\r\n@Mega lagi, form-nya e-Orharnya khan gak hilang ?\r\n@Novita : kasihan direject :) itu untuk txn apa yaa ?'),
(30, 1554696927, 'Muhammad Budi Sulistiyono', 'Pak WK\r\n\r\nsepertinya untuk di PIK perlu juga direview lagi mengenai approval HC apakah tetap 2 HC?\r\nsaran aku sih spt nya cukup 1 deh, karena dulu kan pertimbangannya spt di transaksi perlu countersign. Tapi kalau dilihat2 skrg, nota2 transaksi tetap countersign, trs di e-orhar juga dua approval, nah disini kok jadinya akan menambah lama waktu transaksi. Nah kalau 1 approval, maka untuk supervisor yg 1 lagi bisa melihat inquiry order utk memeriksa transaksinya, tanpa harus melakukan approve lagi di aplikasi order.'),
(31, 1555380983, 'Wilbert Karel Wetik', 'Dear Mas Bro,..\r\nBisa mas bro, tergantung dari kebutuhan unit kerja, apakah dengan di-approve oleh 1 HC PIK sudah cukup mengcover bahwa transaksi yang dijalankan sudah oke... Apabila akan mempercepat proses kita setuju dan nanti sepakati saja lagi pada saat meeting e-ORHAR pada 25 April 2019 ini\r\n'),
(32, 1555983801, 'Christy Purnama', 'Dear Pak WK,\r\nkolom berita untuk PIK  untuk apa ya? kan tidak bisa muncul juga informasinya nya di PIK kalau kita input di berita untuk PIK,\r\ngimana kalau dihilangkan saja supaya ALK tidak salah isi keterangan di berita untuk PIK'),
(33, 1557124645, 'Wilbert Karel Wetik', 'Dear Christy,\r\nKeterangan berisi informasi/keterangan mengenai transaksi yang akan dijalankan, sedangkan Berita untuk PIK waktu dibuat adalah sebagai bentuk pemberitahuan ke PIK (catatan khusus pic PIK) bahwa proses transaksi yang akan dijalankan merupakan transaksi urgent atau pemberitahuan lainnya yang diperlukan oleh ALK ke PIK. \r\nApabila Berita untuk PIK akan dihapuskan/dihilangkan bisa saja sepanjang keperluannya memang sama dengan Keterangan.'),
(34, 1559121409, 'Bagus Risza Fahrodhi', 'Nomor Rekening Debitor tidak muncul 29-May-2019 15:27:47\r\nDear Kevin dan Bpk Wilbert,\r\nsehubungan dengan ditemukannya kasus tidak tercantumnya nomor rekening Debitor (Tifa Finance dan Jayatama) yang sudah diisi oleh ALK pada form E-Orhar, mohon bantuannya agar field Nomor Rekening tersebut juga dimunculkan pada tampilan di operator dan HC Non Fin.\r\n\r\nTerima kasih atas bantuannya.\r\n'),
(35, 1561002204, 'Bagus Risza Fahrodhi', 'Dear Bpk Wilbert and Kevin,\r\nmohon bantuannya untuk menambahkan field mandatory Kategori Debitor dengan pilihan M/L pada Pemrek Non Finansial.\r\nterima kasih.'),
(36, 1564543276, 'Vinsensia Givy Gisela', 'Dear Kevin,\r\nMasukan, apakah bisa tombol delete (X) saat kepencet muncul notif misalnya \"Apakah Anda yakin?\" -> Yes or No\r\nTujuannya, kadang tidak sengaja/ komputer lemot jadi terpencet dan orderan yg sdh diinput jd hilang\r\nterima kasih'),
(37, 1564631799, 'Junista', 'Saran dong, bisa gak ya ditambahkan custom untuk orderan nonfin biar langsung masukin berdasarkan nama PT nya untuk update semuanya, tanpa perlu order berkali-kali '),
(38, 1564737283, 'Wilbert Karel Wetik', 'Dear Givy,..\r\nBisa, btw teknisi sedang sibuk, bersabar yaa,..\r\n'),
(39, 1564737448, 'Wilbert Karel Wetik', 'Dear Junista,\r\nBisa, btw teknisi sedang sibuk, bersabar yaa,... dan untuk sementara pake up date data jaminan saja yaa'),
(40, 1564972033, 'Dominggus Richardod', 'Dear Admin,\r\n\r\nBerikut beberapa usulan penambahan pada E-Orhar:\r\n1. Dapat mengubah status surat asli\r\nAlasan: Terdapat beberapa orderan yang memerlukan surat asli yang diisi none maupun sebaliknya, serta memo asli transaksi \r\nsindikasi yang penerimaanya memerlukan buku surat asli (cara lama), bukan dengan e-Orhar\r\n\r\n2. Penambahan sortir untuk data orderan diatas pukul 15:00.\r\nAlasan: Orderan yang di-approve diatas pukul 15:00 perlu di cek manual yakni ketika mengarahkan kursor ke centangan \r\norderan. Hal tersebut membuat pengumpulan data menjadi lebih sulit.\r\n\r\n3. PIK OP bisa mem-view All Order meskipun belum di approve (seperti yang ada di fungsi HC PIK)\r\nAlasan: Bisa membantu teman PIK OP lain untuk mengerjakan orderan dengan lebih baik.\r\n\r\n4. Menambahkan fitur kategori PBMM (dikeluarkan dari custom).\r\nAlasan: Banyaknya jumlah orderan custom untuk PBMM yang mana beberapa diantaranya memerlukan concern pengerjaan \r\nurgent, serta mempermudah sarana balancing transaksi PBMM di sore hari.\r\n\r\n\r\nDemikian permohonan ini disampaikan. Atas perhatian dan kerjasama nantinya kami mengucapkan terima kasih.\r\n:)\r\n'),
(41, 1567743028, 'Nyimas Wida', 'Dear Kevin, \r\nUntuk HC, minta tlg ditambahkan tanda, misal tanda seru atau field khusus transaksi yang RTGS, jadi HC bisa langsung aware.\r\n\r\nThank you ya Vin'),
(42, 1571710211, 'Moch. Tri Wicaksono', 'mohon diberikan \r\n1. notifikasi ketika Supervisi Asli sudah melakukan Verifikasi Orderan Non Aktif/Tarik/Roya, sehingga supervisi CAMS bisa melakukan Non Aktif Edosir.\r\n2. Untuk kolom tanggal Terbit pada eorhar CAMS diberikan Tanggal - Bulan - Tahun, karena saat ini yang berjalan bahwa SLK saat order terjadi dua kali penginputan tanggal terbit dokumen (1. Memberikan tahun, 2. Memberikan Tanggal bulan tahun dikolom Keterangan)\r\n3. Memberikan Peringatan atau Warning untuk beberapa kolom pada eorhar CAMS, seperti (Nomor Rekening, Nomor Komitmen, Nomor Jaminan khusus dokumen Jaminan)'),
(43, 1571891957, 'Monika Tiur Apriani', 'Dear all, usul utk jumlah kolom jumlah dokumen ditambah jadi 10 kolom (saat ini hanya 5 kolom) dan utk field no dokumen agar bisa di drag seperti field keterangan, karena kami kesulitan utk melihat no dokumen tks'),
(44, 1571974022, 'Wilbert Karel Wetik', 'Dear bro Wicak,\r\nTerima kasih atas masukannya, akan kita coba akomodir'),
(45, 1571974559, 'Wilbert Karel Wetik', 'Dear Sis Monik,\r\nUntuk penambahan kolom saat ini belum dapat dilakukan, utk drag pada filed dimaksud akan kita coba akomodir'),
(46, 1571974611, 'Finda Ariesta Mulia', 'Dear Tim,\r\nTerdapat beberapa anak SLK yang menuliskan tanggal secara detail di field keterangan, karena terkadang terdapat dokumen yang berjudul sama tanpa nomor tapi hanya berbeda tanggal.. \r\nSebaiknya, field Tahun dirubah menjadi field Tanggal.. \r\nTerima Kasih'),
(47, 1571975268, 'Wilbert Karel Wetik', 'Dear Sis Nyimak,\r\nTerima kasih ada masukannya, akan kita coba akomodir'),
(48, 1571975416, 'Wilbert Karel Wetik', 'Dear Sis Finda,\r\nAkan kita coba akomodir, sama seperti masukan dari bro Wicak'),
(49, 1571976851, 'Endru Sanjaya', 'dear Tim,\r\nsehubungan dengan permintaan dari Ibu Lili mengenai monitoring memo Forex, LC dan BG,\r\nmaka saya mengusulkan untuk di lakukan perubahan pada saat perpanjangan fasilitas / fasilitas baru sebagai berikut ;\r\ndi tambahkan check list memo Forex, memo LC, Memo BG, dan Provisi dengan tujuan di masukan ke bagian reminder,\r\ncheck list dapat di centang jika sudah melakukan atau membuat memo tersebut, jika check list tidak di centang maka harus menentukan tanggal reminder agar muncul reminder untuk staf SLK dan HC nya agar termonitoring untuk pembuatan memo dan pendebetan provisi atas perpanjangan fasilitas,'),
(50, 1571986881, 'Wilbert Karel Wetik', 'Dear bro Endru,\r\nSiap bro.. terima kasih atas masukannya, nanti akan kita coba akomodir walau nanti ini akan digantikan dengan fitur tambahan di e-Orhar berupa fitur e-Memo yang sedang kita persiapkan, dan ini akan melibatkan dan terkoneksi unit2 kerja terkait (JTS/STS, Treasury, DIB dan GBK) juga'),
(51, 1572318967, 'Endah Nurnendah', 'pa wil, kalau bisa  e orhar Fin & BG dapat dipisahkan , agar lebih mudah untuk memantaunya. Terima kasih  '),
(52, 1572488798, 'Keren Hapukh', 'Pak Wil dan Kevin, mohon untuk field tanggal terbit dokumen dicantumkan secara lengkap (tanggal-bulan-tahun). terima kasih.'),
(53, 1572595069, 'Wilbert Karel Wetik', 'Dear Sis Ecrot..\r\nTerima kasih atas masukannya,.. akan kita akomodir... '),
(54, 1572595167, 'Wilbert Karel Wetik', 'Dear Sis Keren banget,..\r\nTerima kasih atas masukannya,..sama seperti usulan dari bro Wicak, akana kita akomodir..'),
(55, 1573112197, 'Merlyn Halim', 'Dear Pak Wilbert dan Kevin, ada baiknya setiap orderan yang sudah di approve oleh HC dan Kabag Fin/Non-Fin/CAMS terlihat waktunya (mungkin keterangan waktunya bisa ditambahkan di checklist ALK HC dan PIK HC pada My Order), hal ini agar orderan dapat termonitor dengan baik. Terima Kasih ^^'),
(56, 1573183402, 'Wilbert Karel Wetik', 'Dear Sis Merlyn,\r\nTerima kasih atas masukan/sarannya, akan kita coba akomodir yaa'),
(57, 1574822744, 'Resnawati', 'Dear Kevin,\r\n\r\nSehubungan dengan diskusi beberapa waktu lalu.\r\nMohon bantuannya untuk menambahkan fitur monitoring Asli seluruh Staff juga di layar Supervisor agar dapat termonitoring aslinya juga oleh supervisor.\r\nTerimakasih'),
(58, 1575259916, 'Moch. Tri Wicaksono', 'mohon dibuat tampilan pada view order supervisi CAMS \"Pada Halaman Pertama - diliatkan tampilan Orderan dari Tanggal Order terlama yang belum Di Approve HC,Diterima Oleh PIC Operator dan Di Approve Supervisi CAMS\" sehingga memudahkan supervisi untuk mengontrol orderan mana saja yang belum dilakukan follow up/ditindaklanjuti. Terima kasih Kevin dan Pak Wilbert'),
(59, 1575880320, 'Lidia', 'Mohon di ubah yaaa, perihal permintaan pembukaan rek di KCK (non fin), ada pilihan kategori debitor : Medium/Large. mohon untuk di ganti menjadi Komersil/Korporasi. demikian, thanks.'),
(60, 1576814700, 'Resnawati', 'Dear All,\r\n\r\nmohon bantuannya, e-orhar semakin lemot. '),
(61, 1577432568, 'Wilbert Karel Wetik', 'Dear Resna,\r\nKemungkinan di jaringan LAN -nya, atau kemungkinan komputer servernya mengalami gangguan,, untuk hal ini akan dikoordinasikan dengan tempat APK'),
(62, 1577435100, 'Bagus Risza Fahrodhi', 'Dear Bpk Wilbert/ Kevin.\r\nmohon bantuan untuk melakukan perubahan menu pada Buka Rekening/Data Debitor bagian kolom Kategori Debitor agar dapat diberikan pilihan sbb :\r\n\"M - Komersil\" \r\n\"L - Korporasi\"\r\n\r\nterima kasih atas bantuannya.'),
(63, 1577436658, 'Wilbert Karel Wetik', 'Dear Lidia en Bagus,..\r\nOk kita akomodasi sesuai kebutuhan..'),
(64, 1577954834, 'Elza Widyasari', 'Dear Admin,\r\nuntuk view e-orhar mohon agar dapat diakses juga untuk seluruh staf SLK agar staf juga dapat melihat/cek transaksi yg lalu terutama utk back-up pic '),
(65, 1578987792, 'Wilbert Karel Wetik', 'Dear Elza,\r\nOk, akses utk staf SLK akan dibukakan utk masing2 Cluster...'),
(66, 1580973279, 'Adi Fajar', 'mau usul ya...supaya di tambahkan no dokumen dan tanggal dokumen atau tanggal terbit, karena ada yang no dokumennya sama tapi tanggal dokumennya beda.'),
(67, 1580973492, 'Adi Fajar', 'mau tanya dong..kalau ordernya 500 dokumen bagaimana?'),
(68, 1581325827, 'Gokmaria Hotnida', 'Usul dong untuk segera bisa diprint karena untuk SPV perlu pencatatan seperti di memo order no borrow untuk peminjaman dan no release untuk tarik dokumen. Pencetakan dan nomor2 tersebut sangat diperlukan saat balancing dengan laporan borrow bulanan, dan menjadi dasar pemeriksaan audit KP. '),
(69, 1581326648, 'Cicilia Prima Widi Astuti', 'dear Pak Wilbert, untuk penginputan borrow mohon ditambahkan kolom no.dokumen dan tanggal terbit, dan untuk VIEW order CAMS (SLK menyerahkan dok ke monitoring) mohon untuk yang ditampilkan hanya order yg ke monitoring saja. thank you :) '),
(70, 1581496238, 'Cicilia Prima Widi Astuti', 'dear Kevin dan Pak Wilbert, apakah bisa ditambahkan kolom ID Borrow untuk menu penyerahan dokumen covernote ke PIK Monitoring (untuk memindahkan borrow SLK ke monitoring sesuai dengan CN pengikatannya) ? thank you :)'),
(71, 1582021539, 'Cicilia Prima Widi Astuti', 'dear Kevin dan Pak Wilbert, untuk pengembalian borrow apakah bisa ditampilkan keterangan borrow pas awalnya? '),
(72, 1582187472, 'Iwati', 'Pak Alay, mau usul, tolong ditambahkan nama peminjam karena yang tercantum hanya Nip bukan nama peminjam untuk order pengembalian  dokumen asli.'),
(73, 1582532330, 'Cicilia Prima Widi Astuti', 'dear Kevin dan Pak Wilbert, menu order borrow dokumen untuk no dokumen dan tanggal terbit tidak muncul, mohon bantuannya ya. thank you :)'),
(74, 1582599000, 'Cicilia Prima Widi Astuti', 'Dear Kevin, mohon bantuannya penambahan fitur HC Swap (unit monitoring) untuk alih operator apabila ada yang tidak masuk. thank you :)'),
(75, 1582613515, 'Junista', 'Dear Pak Wk, mohon untuk ditambahkan tab untuk penarikan dokumen, kemudian untuk peminjaman dan penarikan BPKB juga agar bisa disesuaikan (ada kolom upload atau bisa perdokumen tanpa perlu input satu-satu). Sering kali debitur melakukan penarikan dan peminjaman BPKB namun pengembaliannya tidak bersamaan. kesulitan jika harus melakukan penginputan satu satu karena peminjaman maupun penarikan biasanya dalam jumlah yang banyak (tidak bisa diprediksi). mohon bantuannya ya :) tq'),
(76, 1584609127, 'Adi Fajar', 'Pak WK tolong di tambahkan jam orderan dong, karena untuk SLA Asli...terima kasih.'),
(77, 1589445362, 'Gokmaria Hotnida', 'Pak WK, tolong dong kalo bisa untuk dokumen yang sudah status kembali ke Asli di E orhar nya bisa dihapus. Karena datanya jadi banyak betul di e orhar antara yang masih belum kembali dan yang sudah dikembalikan. Tujuan nya agar bisa memudahkan Spv saat monitoring dengan lap R-7857. \r\nSekalian data dokumen yang batal diborrow juga bisa didelete, setelah direject malah jadinya menggantung seperti yang tampak di view borrow nomor 171, 293, 271. Terimakasih.'),
(78, 1593511729, 'Yedidia Panca Onesimus', 'usul dong, mohon ditambahkan kolom (field) \"next review date\" atau perubahan bunga, kondisi ini sangat dibutuhkan untuk order realisasi penarikan/perpanjangan aksep terkhusus yang menggunakan suku bunga floating (Jibor, Libor, SBDK dll).. thankyou admin'),
(79, 1595233070, 'Gokmaria Hotnida', 'Mohon bantuannya supaya unit monitoring juga bisa mwelakukan swap pic, karena saat pic monitoring cuti dan dokumen asli telah diserahkan oleh tim asli kepada pic monitoring lainnya tetapi pic lainnya tsb. tidak bisa mengklik status diterima, juga tidak bisa melakukan swap pic, sehingga status diterima pada aplikasi e orhar masih silang (seolah2 belum diserahkan). ');

-- --------------------------------------------------------

--
-- Struktur dari tabel `msinstruction`
--

CREATE TABLE `msinstruction` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `transdate` varchar(255) NOT NULL,
  `deadline` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `dokumen` varchar(255) DEFAULT NULL,
  `norek` varchar(255) DEFAULT NULL,
  `nojaminan` varchar(255) DEFAULT NULL,
  `nokomit` varchar(255) DEFAULT NULL,
  `kondisi` varchar(255) DEFAULT NULL,
  `nopolis` varchar(255) DEFAULT NULL,
  `periode` varchar(255) DEFAULT NULL,
  `polislama` varchar(255) DEFAULT NULL,
  `detail` varchar(1000) DEFAULT NULL,
  `detail2` varchar(1000) DEFAULT NULL,
  `keaslian` varchar(255) DEFAULT NULL,
  `flagkeaslian` varchar(255) DEFAULT '0',
  `alkhcname` varchar(255) NOT NULL,
  `pic1name` varchar(255) DEFAULT NULL,
  `pic2name` varchar(255) DEFAULT NULL,
  `pikhcname` varchar(255) DEFAULT NULL,
  `pikhcname2` varchar(255) DEFAULT NULL,
  `alkop` varchar(255) DEFAULT NULL,
  `alkhc` varchar(255) NOT NULL,
  `pikop` varchar(255) NOT NULL,
  `pikhc1` varchar(255) DEFAULT NULL,
  `pikhc2` varchar(255) DEFAULT NULL,
  `flagrejected` varchar(255) DEFAULT NULL,
  `flagrejectedpik` varchar(255) DEFAULT NULL,
  `flagpiktoalk` varchar(255) DEFAULT NULL,
  `alkhcname2` varchar(255) DEFAULT NULL,
  `pic1name2` varchar(255) DEFAULT NULL,
  `pic2name2` varchar(255) DEFAULT NULL,
  `pikhcname3` varchar(255) DEFAULT NULL,
  `alkop2` varchar(255) DEFAULT '0',
  `alkhc2` varchar(255) DEFAULT '0',
  `pikop2` varchar(255) DEFAULT '0',
  `pikhc12` varchar(255) DEFAULT '0',
  `flagrejected2` varchar(255) DEFAULT '0',
  `flagrejectedpik2` varchar(255) DEFAULT '0',
  `flagpiktoalk2` varchar(255) DEFAULT '0',
  `pikprogress` varchar(255) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `timestampprovisi` varchar(255) DEFAULT NULL,
  `typeextra` varchar(255) DEFAULT NULL,
  `pikmargin` varchar(255) DEFAULT NULL,
  `comreject` varchar(255) DEFAULT NULL,
  `waktu` varchar(255) DEFAULT NULL,
  `diserahkan` int(11) NOT NULL DEFAULT '0',
  `clusterhold` varchar(255) NOT NULL DEFAULT '0',
  `tgldiserahkan` varchar(255) DEFAULT NULL,
  `waktualk` varchar(255) DEFAULT NULL,
  `pikhc3` varchar(255) NOT NULL DEFAULT '0',
  `reminder` int(5) DEFAULT '0',
  `reminderdate` varchar(255) DEFAULT NULL,
  `lokasibg` varchar(255) DEFAULT NULL,
  `rekgiro` varchar(255) DEFAULT NULL,
  `adminis` varchar(255) DEFAULT NULL,
  `komisi` varchar(255) DEFAULT NULL,
  `bataswaktu` varchar(255) DEFAULT NULL,
  `jangkabg` varchar(255) DEFAULT NULL,
  `jenisjamin` varchar(255) DEFAULT NULL,
  `alamatpenerimajamin` varchar(255) DEFAULT NULL,
  `namapenerimajamin` varchar(255) DEFAULT NULL,
  `alamatjamin` varchar(255) DEFAULT NULL,
  `namajamin` varchar(255) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `msinstruction`
--

INSERT INTO `msinstruction` (`id`, `username`, `transdate`, `deadline`, `company`, `dokumen`, `norek`, `nojaminan`, `nokomit`, `kondisi`, `nopolis`, `periode`, `polislama`, `detail`, `detail2`, `keaslian`, `flagkeaslian`, `alkhcname`, `pic1name`, `pic2name`, `pikhcname`, `pikhcname2`, `alkop`, `alkhc`, `pikop`, `pikhc1`, `pikhc2`, `flagrejected`, `flagrejectedpik`, `flagpiktoalk`, `alkhcname2`, `pic1name2`, `pic2name2`, `pikhcname3`, `alkop2`, `alkhc2`, `pikop2`, `pikhc12`, `flagrejected2`, `flagrejectedpik2`, `flagpiktoalk2`, `pikprogress`, `type`, `timestampprovisi`, `typeextra`, `pikmargin`, `comreject`, `waktu`, `diserahkan`, `clusterhold`, `tgldiserahkan`, `waktualk`, `pikhc3`, `reminder`, `reminderdate`, `lokasibg`, `rekgiro`, `adminis`, `komisi`, `bataswaktu`, `jangkabg`, `jenisjamin`, `alamatpenerimajamin`, `namapenerimajamin`, `alamatjamin`, `namajamin`, `file`) VALUES
(1, 'Conny Yusran', '13-2-2020', NULL, 'PT. ULTRA PRIMA ABADI', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mohon dilakukan koreksi akta Perjanjian Kredit sesuai lampiran, untuk menjawab komen PIC', NULL, NULL, '0', 'David Ardian', 'Arief Satria Budiman', 'Cicilia Prima Widi Astuti', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '11:20', 0, '0', NULL, '10:58', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1581584334-koreksiaktaPPKPTUltraPrimaAbadi.msg'),
(3, 'Hizkia Ignatius Tambun', '14-2-2020', NULL, 'PT. Wahana Mas Mulia', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Mohon bantuan untuk koreksi PK Notaril', NULL, NULL, '0', 'Lidia', 'Arief Satria Budiman', 'Cicilia Prima Widi Astuti', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '10:44', 0, '0', NULL, '10:38', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1581669836-KoreksiPKPTWahanaMasMulia.msg'),
(5, 'Hizkia Ignatius Tambun', '26-2-2020', NULL, 'PT. Buana Megah', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Koreksi tahun pada SHT\r\n', NULL, NULL, '0', 'Lidia', 'Arief Satria Budiman', 'Cicilia Prima Widi Astuti', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '17:07', 0, '0', NULL, '16:59', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1582729167-KoreksiSHTPT.BuanaMegah.xlsx'),
(6, 'Merina Annisa Noviani', '28-2-2020', NULL, 'PT Arista Jaya Lestari', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'koreksi dokumen :\r\n\r\nNo jaminan         : 47649868\r\nDokumen            : SKMHT No. 118 tgl 24-08-2019\r\n', NULL, NULL, '0', 'Lidia', 'Arief Satria Budiman', 'Cicilia Prima Widi Astuti', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '16:52', 0, '0', NULL, '16:11', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ''),
(7, 'Merina Annisa Noviani', '28-2-2020', NULL, 'PT Arista Jaya Lestari', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'koreksi APHT PT Arista Jaya Lestari dengan rincian sbb :\r\n\r\nNo jaminan         : 46895611\r\nDokumen            : APHT No 145/2018\r\n', NULL, NULL, '0', 'Lidia', 'Arief Satria Budiman', 'Cicilia Prima Widi Astuti', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '16:51', 0, '0', NULL, '16:26', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ''),
(8, 'Yedidia Panca Onesimus', '2-3-2020', NULL, 'PT Tunas Dwipa Matra', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Koreksi AJF No. 108 tgl. 24-08-2018 & Koreksi SJF No. W9.00189136 tgl. 06-12-2018 :\r\npada akta yang menyebutkan daftar persediaan No. 116/FIN/VII/18 tertulis tgl. 10-07-2018 seharusnya tanggal 12-07-2018.', NULL, NULL, '0', 'Lidia', 'Arief Satria Budiman', 'Cicilia Prima Widi Astuti', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '11:23', 0, '0', NULL, '11:22', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ''),
(10, 'Caecilia Novadena', '6-3-2020', NULL, 'PT Dharma Satya Nusantara', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Koreksi atas Corporate Guarantee No.17', NULL, NULL, '0', 'Nyimas Wida', 'Cicilia Prima Widi Astuti', 'Arief Satria Budiman', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '14:56', 0, '0', NULL, '14:28', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1583497689-SuratOrderNotarisKoreksiCorporateGuarantee.pdf'),
(11, 'Carissa Kurniawan', '16-3-2020', NULL, 'PT Mulia Intipelangi', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'non aktif covernote No. 06/III/S.Ket./2020 tgl 03/03/2020 dengan digantikan dengan covernote yang diserahkan hari ini', NULL, NULL, '0', 'Dewi Virgina', 'Meltia Inapril', 'Arief Satria Budiman', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '14:02', 0, '0', NULL, '12:13', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ''),
(12, 'Nadia Wohon', '18-3-2020', NULL, 'PT Indoguna Utama', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Mohon koreksi dokumen sesuai comment dari PI KCK sbb :\r\nTerdapat kesalahan pada SHT No. 05665/2016 tgl 30-11-2016, tercantum SHGB No. 0687/Pondok Bambu, seharusnya SHM No. 0687/Pondok Bambu\r\n\r\nNomor Jaminan : 11331469', NULL, NULL, '0', 'Wilbert Karel Wetik', 'Cicilia Prima Widi Astuti', 'Meltia Inapril', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '10:29', 0, '0', NULL, '10:26', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1584519980-SHT_30_NOV_2016_05665-2016.tif'),
(13, 'Nadia Wohon', '18-3-2020', NULL, 'PT Indoguna Utama', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Mohon koreksi dokumen sesuai konfirmasi PI KCK di bawah ini :\r\n\r\nTerdapat kesalahan pada SHT No. 1478/2009 tgl 25-05-2009, tercantum APHT No. 98/2009, seharusnya APHT No. 90/2009\r\n(agunan SHM No. 687/Pondok Bambu)\r\n\r\nNomor jaminan : 11331469', NULL, NULL, '0', 'Wilbert Karel Wetik', 'Cicilia Prima Widi Astuti', 'Meltia Inapril', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '10:34', 0, '0', NULL, '10:31', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1584520303-HT687.zip'),
(14, 'Merina Annisa Noviani', '19-3-2020', NULL, 'PT Hiba Prima Sejahtera', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'revisi halaman 6 SKMHT perihal tanggal RUPS seharusnya 18 Agustus 2016 (terlampir RUPS)\r\nNo. Jaminan : 40358285', NULL, NULL, '0', 'Lidia', 'Arief Satria Budiman', 'Choose PIK Operator', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '10:17', 0, '0', NULL, '10:03', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1584605037-SKMHTHPS.zip'),
(15, 'Maria Gretalita Niken Winaputri', '31-3-2020', NULL, 'PT. Arta Batrindo', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Mohon direvisi pada PPK No. 76 tgl 28-02-2018, sbb : \"â€¦yang telah beberapa kali diubah dan terakhir diubah dengan PPK No. 137 tgl 26-04-2017â€¦\"\r\nseharusnya\r\n\"...... dan terakhir diubah dengan PPK No. 81 tgl 20-11-2017\"', NULL, NULL, '0', 'David Ardian', 'Cicilia Prima Widi Astuti', 'Arief Satria Budiman', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '10:27', 0, '0', NULL, '10:25', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1585643147-RevisiPPKArta.zip'),
(17, 'Hindrawati', '1-4-2020', NULL, 'PT. Indomulti Jaya Steel', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Koreksi SHGB No. 24/Tambak Sarioso (No. Jaminan 36648053) \r\nSesuai dengan email terlampir', NULL, NULL, '0', 'Dewi Virgina', 'Meltia Inapril', 'Arief Satria Budiman', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '14:38', 0, '0', NULL, '14:04', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1585742692-KoreksiSHGBPTIndomultiJayaSteel.msg'),
(18, 'Hindrawati', '1-4-2020', NULL, 'PT. Timur Jaya Indosteel', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Koreksi APJF dan SPJF Piutang (No. Jaminan 19060722) dan Persediaan (No. Jaminan 10245090)\r\nSesuai dengan email terlampir', NULL, NULL, '0', 'Dewi Virgina', 'Meltia Inapril', 'Arief Satria Budiman', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '14:39', 0, '0', NULL, '14:07', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1585742842-KoreksiAPJFdanSPJFPTTimurJayaIndoSteel.msg'),
(19, 'Hindrawati', '1-4-2020', NULL, 'PT. Sinar Karya Duta Abadi', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Koreksi SKMHT No. 159 (No. Jaminan 37637626)\r\nSesuai dengan email terlampir', NULL, NULL, '0', 'Dewi Virgina', 'Meltia Inapril', 'Arief Satria Budiman', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '14:40', 0, '0', NULL, '14:09', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1585742984-KoreksiSKMHTPTSinarKaryaDutaAbadi.msg'),
(20, 'Hizkia Ignatius Tambun', '8-4-2020', NULL, 'PT. Triwarga Dian Sakti', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'PPK ke 15 akta no. 18 tgl 15-10-2018 kurang mencantumkan satu SPPJS nomor 40450 tgl 30-8-2018', NULL, NULL, '0', 'Lidia', 'Arief Satria Budiman', 'Cicilia Prima Widi Astuti', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '08:00', 0, '0', NULL, '18:17', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1586276226-KoreksiSPPJSpadaPKNo.18tgl15-10-2018.xlsx'),
(21, 'Monika Istiana Dewi', '8-4-2020', NULL, 'PT DWIJAYA SENTOSA ABADI', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Borrow dokumen, sbb :\r\n-APHT  No: 213/2010 tgl 19 Agu 2010\r\n-SHT Nomor 4999/2010\r\nuntuk dilakukan koreksi ke notaris\r\nterlampir pada email.', NULL, NULL, '0', 'Dewi Virgina', 'Meltia Inapril', 'Arief Satria Budiman', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '16:47', 0, '0', NULL, '16:46', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1586357172-KoreksiAktaPTDwijayaSentosaAbadi.msg'),
(24, 'Hindrawati', '30-4-2020', NULL, 'PT. Steel Pipe Industry of Indonesia Tbk', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Koreksi PK Add 5 No. 92 tgl 15-10-2014\r\nSesuai dengan email terlampir ', NULL, NULL, '0', 'Dewi Virgina', 'Meltia Inapril', 'Arief Satria Budiman', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '15:51', 0, '0', NULL, '13:34', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1588246499-KoreksiPKAdd5PTSteelPipeIndustryofIndonesiaTbk.msg'),
(25, 'Hindrawati', '30-4-2020', NULL, 'PT. Steel Pipe Industry of Indonesia Tbk', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Koreksi PK Add 10 No. 94 tgl 25-10-2016\r\nSesuai dengan email terlampir', NULL, NULL, '0', 'Dewi Virgina', 'Meltia Inapril', 'Arief Satria Budiman', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '15:52', 0, '0', NULL, '13:37', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1588246669-KoreksiPKAdd10PTSteelPipeIndustryofIndonesiaTbk.msg'),
(26, 'Valiant Gunawan', '15-5-2020', NULL, 'PT. Margabumi Matraraya', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Mohon untuk dapat di upload di CAMS dokumen berikut dibawah ini :\r\n1. Surat Pernyataan Kesanggupan dari pemegang saham (PT. Tirtobumi) seperti terlampir\r\n2. Perubahan Surat Pernyataan Kesanggupan No. 02 tgl. 01-08-2017', NULL, NULL, '0', 'Nyimas Wida', 'Arief Satria Budiman', 'Cicilia Prima Widi Astuti', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, 'surat pernyataan 92 sdh ada di CAMS, yg tidak ada no 02 dan surat pernyataan dibawah tangan ,by: Nyimas Wida', '14:57', 0, '0', NULL, '10:52', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1589451328-Suratpernyataankesanggupan.zip'),
(28, 'Hizkia Ignatius Tambun', '29-5-2020', NULL, 'PT. Sejahtera Bahari Abadi', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'perbedaan luas agunan T/B kantor yang dijaminkan\r\npada Akta Perubahan Dan Pernyataan Kembali Atas Perjanjian Kredit No. 19 tgl 9-4-2020 Pasal 10.1.1 tertulis 3.039m2, mohon\r\nagar disesuaikan dengan SHMSRS no. 7048-7055 / Karet Tengsin  total luasnya adalah 2.705,44m2\r\n', NULL, NULL, '0', 'Elza Widyasari', 'Arief Satria Budiman', 'Cicilia Prima Widi Astuti', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '11:45', 0, '0', NULL, '08:35', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1590743572-Koreksi.zip'),
(29, 'Endru Sanjaya', '17-6-2020', NULL, 'PT. Colorpak Flexible Indonesia dan PT. Colorpak Indonesia', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Pembetulan penyebutan tanggal perpanjangan sementara menjadi 01-09-2016 ', NULL, NULL, '0', 'David Ardian', 'Arief Satria Budiman', 'Meltia Inapril', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', '1', NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, 'tolong di swap, OP nya arief & meltia ,by: Arief Satria Budiman', '14:44', 0, '0', NULL, '09:12', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1592378256-KoreksiAddPKPTColorpakIndonesia.msg'),
(30, 'Endru Sanjaya', '17-6-2020', NULL, 'PT. Colorpak Flexible Indonesia dan PT. Colorpak Indonesia', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Pembetulan penyebutan tanggal SP dekom menjadi 16-09-2014 ', NULL, NULL, '0', 'David Ardian', 'Meltia Inapril', 'Arief Satria Budiman', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', '1', NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, 'tolong di swap, OP nya arief & meltia ,by: Arief Satria Budiman', '14:45', 0, '0', NULL, '09:12', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1592378270-KoreksiAddPKPTColorpakIndonesia.msg'),
(31, 'Nur Rahmah Hastiati', '19-6-2020', NULL, 'PT Gemilang Berlian Indah', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'koreksi no Gambar Situasi  dari No. 487/T3HT/1993 , menjadi No. 484/T3HT/1993 pada SHT dan APHT sesuai dengan SHM No. 1318/Pasiran Tgl 21-01-1994. \r\n\r\n', NULL, NULL, '0', 'Lidia', 'Arief Satria Budiman', 'Cicilia Prima Widi Astuti', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '16:45', 0, '0', NULL, '16:43', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1592577831-SKMHTPeringkatke1_29Jan2008_66.zip'),
(33, 'Junista', '24-6-2020', NULL, 'PT Bahtera Energi Samudera Tuah ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Mohon koreksi sesuai email terlampir ', NULL, NULL, '0', 'Elza Widyasari', 'Arief Satria Budiman', 'Meltia Inapril', NULL, NULL, '1', '1', '1', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, ' ,by: Elza Widyasari', '12:42', 0, '0', NULL, '09:19', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1592983166-RECNatasnamaDBSESLOSLdanBEST&DraftHipotik.msg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `msjaminan`
--

CREATE TABLE `msjaminan` (
  `id` int(11) NOT NULL,
  `unionid` varchar(255) DEFAULT NULL,
  `jenis` varchar(255) DEFAULT NULL,
  `bukti` varchar(255) DEFAULT NULL,
  `mpk` varchar(255) DEFAULT NULL,
  `appr` varchar(255) DEFAULT NULL,
  `nilai` varchar(255) DEFAULT NULL,
  `nokta` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `kjpp` varchar(255) DEFAULT NULL,
  `rek` varchar(255) DEFAULT NULL,
  `komit` varchar(255) DEFAULT NULL,
  `nokomit` varchar(255) DEFAULT NULL,
  `keterangan` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `msjaminan`
--

INSERT INTO `msjaminan` (`id`, `unionid`, `jenis`, `bukti`, `mpk`, `appr`, `nilai`, `nokta`, `date`, `kjpp`, `rek`, `komit`, `nokomit`, `keterangan`) VALUES
(1, '1', 'deposito', '', NULL, NULL, NULL, 'No. 8 tgl 18-10-2018', '24-5-2019', NULL, '205-900-924-3', NULL, 'com 2', NULL),
(2, '1', '', '', NULL, NULL, NULL, '', '24-5-2019', NULL, '', NULL, '', NULL),
(3, '1', '', '', NULL, NULL, NULL, '', '24-5-2019', NULL, '', NULL, '', NULL),
(4, '1', '', '', NULL, NULL, NULL, '', '24-5-2019', NULL, '', NULL, '', NULL),
(5, '1', '', '', NULL, NULL, NULL, '', '24-5-2019', NULL, '', NULL, '', NULL),
(6, '2', 'deposito', 'AJ 436062', NULL, NULL, NULL, '8 tgl 18-10-2018', '22-5-2019', NULL, '205-900-924-3', NULL, '2', NULL),
(7, '2', '', '', NULL, NULL, NULL, '', '27-5-2019', NULL, '', NULL, '', NULL),
(8, '2', '', '', NULL, NULL, NULL, '', '27-5-2019', NULL, '', NULL, '', NULL),
(9, '2', '', '', NULL, NULL, NULL, '', '27-5-2019', NULL, '', NULL, '', NULL),
(10, '2', '', '', NULL, NULL, NULL, '', '27-5-2019', NULL, '', NULL, '', NULL),
(11, '6', 'Kendaraan', '415/FIN/HRC/V/2019', NULL, NULL, NULL, '', '17-5-2019', NULL, '205-900-737-2', NULL, 'kom 3', NULL),
(12, '6', '', '', NULL, NULL, NULL, '', '27-5-2019', NULL, '', NULL, '', NULL),
(13, '6', '', '', NULL, NULL, NULL, '', '27-5-2019', NULL, '', NULL, '', NULL),
(14, '6', '', '', NULL, NULL, NULL, '', '27-5-2019', NULL, '', NULL, '', NULL),
(15, '6', '', '', NULL, NULL, NULL, '', '27-5-2019', NULL, '', NULL, '', NULL),
(16, '7', 'PERSEDIAAN BARANG', '51', NULL, NULL, NULL, '', '27-5-2019', NULL, '397-902-078-4', NULL, '001', NULL),
(17, '7', 'PIUTANG', '52', NULL, NULL, NULL, '', '27-5-2019', NULL, '397-902-078-4', NULL, '001', NULL),
(18, '7', '', '', NULL, NULL, NULL, '', '27-5-2019', NULL, '', NULL, '', NULL),
(19, '7', '', '', NULL, NULL, NULL, '', '27-5-2019', NULL, '', NULL, '', NULL),
(20, '7', '', '', NULL, NULL, NULL, '', '27-5-2019', NULL, '', NULL, '', NULL),
(21, '9', 'Fidusia Hak Tagih PDAM', '', NULL, NULL, NULL, '179', '27-5-2019', NULL, '205-901-031-4', NULL, '001, 002, 003', NULL),
(22, '9', 'Fidusia Hak Tagih Asuransi', '', NULL, NULL, NULL, '178', '27-5-2019', NULL, '205-901-031-4', NULL, '001, 002, 003', NULL),
(23, '9', 'Fidusia Hak Tagih BG/Surety Bond', '', NULL, NULL, NULL, '180', '27-5-2019', NULL, '205-901-031-4', NULL, '001, 002, 003', NULL),
(24, '9', 'Corporate Guarantee MHAL', '-', NULL, NULL, NULL, '-', '29-4-2019', NULL, '205-901-031-4', NULL, '001, 002, 003', NULL),
(25, '9', '', '', NULL, NULL, NULL, '', '28-5-2019', NULL, '', NULL, '', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `msmoncategory`
--

CREATE TABLE `msmoncategory` (
  `id` int(11) NOT NULL,
  `Category` varchar(255) DEFAULT NULL,
  `Name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `msmoncategory`
--

INSERT INTO `msmoncategory` (`id`, `Category`, `Name`) VALUES
(1, 'DEBITUR', 'AMDAL'),
(2, 'DEBITUR', 'Akte Perubahan'),
(3, 'DEBITUR', 'Akte cerai'),
(4, 'DEBITUR', 'Akte pembagian / keterangan waris'),
(5, 'DEBITUR', 'Akte pemisahan harta / perjanjian nikah'),
(6, 'DEBITUR', 'Anggaran Dasar / Akte pendirian perusahaan'),
(7, 'DEBITUR', 'BNRI (Berita Negara RI)'),
(8, 'DEBITUR', 'Covenant monitoring'),
(9, 'DEBITUR', 'Dokumen Identitas'),
(10, 'DEBITUR', 'Fotocopy WNI'),
(11, 'DEBITUR', 'Izin Tetap Usaha Perjalanan'),
(12, 'DEBITUR', 'KITAS/KITAP'),
(13, 'DEBITUR', 'KTP'),
(14, 'DEBITUR', 'Kartu Keluarga'),
(15, 'DEBITUR', 'Laporan Aging Schedule'),
(16, 'DEBITUR', 'Laporan Daftar Tenant'),
(17, 'DEBITUR', 'Laporan Keuangan Audited'),
(18, 'DEBITUR', 'Laporan Keuangan Internal'),
(19, 'DEBITUR', 'Laporan Kontak Sewa'),
(20, 'DEBITUR', 'Laporan Manajemen'),
(21, 'DEBITUR', 'Laporan Pendapatan'),
(22, 'DEBITUR', 'Laporan Penjualan'),
(23, 'DEBITUR', 'Laporan Penyelesaian Proyek'),
(24, 'DEBITUR', 'Laporan Perkembangan Proyek'),
(25, 'DEBITUR', 'Laporan Produksi'),
(26, 'DEBITUR', 'Laporan Volume Produksi'),
(27, 'DEBITUR', 'Memorandum of Understanding'),
(28, 'DEBITUR', 'NPWP'),
(29, 'DEBITUR', 'Passport'),
(30, 'DEBITUR', 'Pendaftaran ke Deperindag'),
(31, 'DEBITUR', 'Pengesahan/ persetujuan / pelaporan kehakiman'),
(32, 'DEBITUR', 'Profil Perusahaan + PK Bank Lain'),
(33, 'DEBITUR', 'Resi Perpj dr Inst Terkait ( Jk id dlm proses)'),
(34, 'DEBITUR', 'Ringkasan anggaran dasar (jatuh tempo pengurus)'),
(35, 'DEBITUR', 'SIM'),
(36, 'DEBITUR', 'SIUP'),
(37, 'DEBITUR', 'Surat Ijin Tempat / Surat Keterangan Tempat Usaha'),
(38, 'DEBITUR', 'Surat Ket Notaris yg menyatakan Akte Pendirian'),
(39, 'DEBITUR', 'Surat Keterangan Beda Nama (Dok Asli)'),
(40, 'DEBITUR', 'Surat Keterangan Domisili'),
(41, 'DEBITUR', 'Surat Keterangan Ganti Nama'),
(42, 'DEBITUR', 'Surat Lain-lain'),
(43, 'DEBITUR', 'Surat Penetapan pengangkatan Wali'),
(44, 'DEBITUR', 'Surat Pernyataan Penyerahan Anggaran Dasar'),
(45, 'DEBITUR', 'Surat Pernyataan ahli waris'),
(46, 'DEBITUR', 'Surat Pernyataan beda nama / beda tanda tangan'),
(47, 'DEBITUR', 'Surat pernyataan tidak pernah menikah secara hukum'),
(48, 'DEBITUR', 'Surat perpanjangan Pengangkatan Dealer'),
(49, 'DEBITUR', 'Surat-surat BCA ke debitur'),
(50, 'DEBITUR', 'TDP'),
(51, 'DEBITUR', 'Tanda Daftar Usaha Perdagangan'),
(52, 'DEBITUR', 'API /APIS/ APIT (Angka Pengenal Impor/ Sementara/'),
(53, 'JAMINAN', 'Surat persetujuan suami / istri'),
(54, 'PINJAMAN', 'Surat persetujuan Komisaris'),
(55, 'PINJAMAN', 'Addendum / Perubahan Perjanjian Kredit'),
(56, 'PINJAMAN', 'BCR / MIP'),
(57, 'PINJAMAN', 'Bilyet Bank Garansi'),
(58, 'PINJAMAN', 'Daftar Angsuran'),
(59, 'PINJAMAN', 'LKK (Lembar Keputusan Kredit) / MPK / MEMORANDUM'),
(60, 'PINJAMAN', 'Letter of Undertaking'),
(61, 'PINJAMAN', 'PK (Perjanjian Kredit)'),
(62, 'PINJAMAN', 'PPBG (Perjanjian Pemberian Bank Garansi)'),
(63, 'PINJAMAN', 'Pendapat Hukum (Legal Opinion)'),
(64, 'PINJAMAN', 'Perjanjian Forex/ISDA'),
(65, 'PINJAMAN', 'Perjanjian Lain-Lain'),
(66, 'PINJAMAN', 'Perjanjian Negosiasi Fasilitas LG'),
(67, 'PINJAMAN', 'Perjanjian Pemberian Fasilitas Intraday'),
(68, 'PINJAMAN', 'Perjanjian Pengelolaan Rekening'),
(69, 'PINJAMAN', 'Perjanjian Restrukturisasi'),
(70, 'PINJAMAN', 'Perubahan PPBG'),
(71, 'PINJAMAN', 'Polis Asuransi'),
(72, 'PINJAMAN', 'SPK'),
(73, 'PINJAMAN', 'SPPJS (Surat pemberitahuan Ppj Sementara)'),
(74, 'PINJAMAN', 'SPPK'),
(75, 'PINJAMAN', 'Sales Contract / SPJB/ Purchase agreement'),
(76, 'PINJAMAN', 'Stand by LC'),
(77, 'PINJAMAN', 'Surat Kuasa Transaksi (PBMM/Forex/Ekspor/Impor)'),
(78, 'PINJAMAN', 'Surat Lain - lain terkait Pinjaman'),
(79, 'PINJAMAN', 'Surat Pengantar Broker'),
(80, 'PINJAMAN', 'Surat Penunjukkan'),
(81, 'PINJAMAN', 'Surat Perintah Kerja'),
(82, 'PINJAMAN', 'Surat Perjanjian / kontrak Kerja Sama'),
(83, 'PINJAMAN', 'Surat Perjanjian Subordinasi Hutang'),
(84, 'PINJAMAN', 'Surat Pernyataan Pemegang Saham'),
(85, 'PINJAMAN', 'Surat Pernyataan dari Debitur Terkait Pinjaman'),
(86, 'PINJAMAN', 'Surat Persetujuaan RUPS untuk Perjanjian Kredit'),
(87, 'PINJAMAN', 'Surat kuasa penanda tanganan kredit'),
(88, 'PINJAMAN', 'Surat/Perjanjian Kesanggupan'),
(89, 'JAMINAN', 'APHT (Akte Pembebanan Hak Tanggungan)'),
(90, 'JAMINAN', 'Akta Hibah/Petikan Risalah Lelang'),
(91, 'JAMINAN', 'Akta Kuasa untuk Memasang Hipotik'),
(92, 'JAMINAN', 'Akta Pernyataan dan Kuasa - Kapal'),
(93, 'JAMINAN', 'Akta Pernyataan Bersama'),
(94, 'JAMINAN', 'Akte Borghtocht (PG/CG)'),
(95, 'JAMINAN', 'Akte Cessie'),
(96, 'JAMINAN', 'Akte Fidusia'),
(97, 'JAMINAN', 'Akte Hipotik'),
(98, 'JAMINAN', 'Akte jual beli'),
(99, 'JAMINAN', 'Appraisal Independent / BAP'),
(100, 'JAMINAN', 'BPKB (Bukti Pemilikan Kendaraan Bermotor)'),
(101, 'JAMINAN', 'Bank Garansi / Counter Guarantee'),
(102, 'JAMINAN', 'Bankers clause asuransi kerugian'),
(103, 'JAMINAN', 'Berita Acara Penyerahan Jaminan'),
(104, 'JAMINAN', 'Berita Acara Serah Terima (BAST)'),
(105, 'JAMINAN', 'Bilyet deposito'),
(106, 'JAMINAN', 'Bukti Bayar Premi'),
(107, 'JAMINAN', 'Cek keaslian dokumen kapal'),
(108, 'JAMINAN', 'Cover note notaris untuk jaminan dan pengikatan ja'),
(109, 'JAMINAN', 'Cover Note Asuransi'),
(110, 'JAMINAN', 'DO (Delivery Order) & daftar persediaan barang'),
(111, 'JAMINAN', 'Daftar Kendaraan'),
(112, 'JAMINAN', 'Daftar Mesin/ Surat Pernyataan Mesin'),
(113, 'JAMINAN', 'Daftar Obyek Gadai'),
(114, 'JAMINAN', 'Daftar Pemegang Saham'),
(115, 'JAMINAN', 'Daftar piutang/surat pernyataan penyerahan piutang'),
(116, 'JAMINAN', 'Faktur barang'),
(117, 'JAMINAN', 'Faktur kendaraan'),
(118, 'JAMINAN', 'Gambar blue print bangunan'),
(119, 'JAMINAN', 'Gambar situasi'),
(120, 'JAMINAN', 'Grosse akta balik nama'),
(121, 'JAMINAN', 'Grosse akta pendaftaran kapal laut'),
(122, 'JAMINAN', 'IMB'),
(123, 'JAMINAN', 'Konfirmasi pemblokiran dari BCA Kustodian'),
(124, 'JAMINAN', 'Kwitansi / faktur pembelian mesin & daftar mesin'),
(125, 'JAMINAN', 'Kwitansi Blanko'),
(126, 'JAMINAN', 'Kwitansi Pembelian'),
(127, 'JAMINAN', 'Kwitansi pembayaran uang muka kendaraan'),
(128, 'JAMINAN', 'Kwitansi pembelian emas'),
(129, 'JAMINAN', 'Memo permohonan blokir (Deposito/Giro/Saham)'),
(130, 'JAMINAN', 'Minuta SKMHT'),
(131, 'JAMINAN', 'PBB'),
(132, 'JAMINAN', 'Pas Tahunan - Kapal (Asli/ Copy)'),
(133, 'JAMINAN', 'Pemblokiran kendaraan bermotor'),
(134, 'JAMINAN', 'Pengecekan kendaraan bermotor'),
(135, 'JAMINAN', 'Pengumuman penjaminan di surat kabar'),
(136, 'JAMINAN', 'Perjanjian Gadai'),
(137, 'JAMINAN', 'Perjanjian Hak Tempat Usaha (PHTPU)'),
(138, 'JAMINAN', 'Perjanjian Keagenan dan Pembagian Hasil Agunan'),
(139, 'JAMINAN', 'Perjanjian Pengalihan Hak'),
(140, 'JAMINAN', 'Perjanjian Pengalihan atas Hak Sewa'),
(141, 'JAMINAN', 'Perjanjian Sewa - Kapal (Asli/ Copy)'),
(142, 'JAMINAN', 'Perjanjian Sewa Menyewa'),
(143, 'JAMINAN', 'Pernyataan direksi/RUPS penyerahan Asset'),
(144, 'JAMINAN', 'Persetujuan pemilik/pengelola u/ mengagunkan kios'),
(145, 'JAMINAN', 'Persetujuan saudara/anak u/ pengikatan jaminan'),
(146, 'JAMINAN', 'SKMHT (Surat Kuasa Memasang Hak Tanggungan)'),
(147, 'JAMINAN', 'SP bersedia tambah jaminan bila harga emas turun'),
(148, 'JAMINAN', 'SPPJB (Perjanjian Pengikatan Jual Beli)'),
(149, 'JAMINAN', 'Sertifikat'),
(150, 'JAMINAN', 'Sertifikat Hak Tanggungan'),
(151, 'JAMINAN', 'Sertifikat Hipotik (jaminan Kapal)'),
(152, 'JAMINAN', 'Sertifikat Kadar Emas'),
(153, 'JAMINAN', 'Sertifikat Keselamatan - Kapal (Asli/ Copy)'),
(154, 'JAMINAN', 'Sertifikat Konstruksi - Kapal'),
(155, 'JAMINAN', 'Sertifikat Pendaftaran Fidusia'),
(156, 'JAMINAN', 'Sertifikat deposito'),
(157, 'JAMINAN', 'Stand by LC'),
(158, 'JAMINAN', 'Surat Kelengkapan Peralatan - Kapal'),
(159, 'JAMINAN', 'Surat Kuasa menjaminkan'),
(160, 'JAMINAN', 'Surat Laut - Kapal (Asli/ Copy)'),
(161, 'JAMINAN', 'Surat Nilai Pertanggungan'),
(162, 'JAMINAN', 'Surat Pemblokiran utk Jaminan Kios'),
(163, 'JAMINAN', 'Surat Peminjaman Sementara'),
(164, 'JAMINAN', 'Surat Perjanjian Pengosongan'),
(165, 'JAMINAN', 'Surat Pernyataan penyewa/ perjanjian sewa'),
(166, 'JAMINAN', 'Surat Persetujuan Pengalihan Piutang'),
(167, 'JAMINAN', 'Surat Persetujuan dari Debitur dan Pemilik Tanah'),
(168, 'JAMINAN', 'Surat Ukur - Kapal (Asli/ Copy)'),
(169, 'JAMINAN', 'Surat blokir (Deposito/Giro/Saham)'),
(170, 'JAMINAN', 'Surat ijin pemakaian kios (SIPTU/SIPTB/dll)'),
(171, 'JAMINAN', 'Surat kelayakan berlayar'),
(172, 'JAMINAN', 'Surat keterangan dari penerima manfaat asuransi'),
(173, 'JAMINAN', 'Surat keterangan deregistration'),
(174, 'JAMINAN', 'Surat kuasa untuk ttd pengikatan jaminan'),
(175, 'JAMINAN', 'Surat pernyataan dari debitur'),
(176, 'JAMINAN', 'Surat pernyataan dari pemberi agunan'),
(177, 'JAMINAN', 'Surat pernyataan dari penerima manfaat asuransi'),
(178, 'JAMINAN', 'Surat pernyataan dari perusahaan asuransi'),
(179, 'JAMINAN', 'Surat persetujuan RUPS'),
(180, 'JAMINAN', 'Surat persetujuan untuk perpanjangan avalist'),
(181, 'JAMINAN', 'Surat saham /bukti kepemilikan saham'),
(182, 'JAMINAN', 'Surat tanda kebangsaan kapal'),
(183, 'JAMINAN', 'Surat ukur '),
(184, 'JAMINAN', 'Tanda terima jaminan'),
(185, 'DEBITUR', 'Akte Nikah'),
(186, 'CUSTOM', 'Custom'),
(187, 'JAMINAN', 'Covernote'),
(188, 'PINJAMAN', 'Covernote');

-- --------------------------------------------------------

--
-- Struktur dari tabel `msmonitoring`
--

CREATE TABLE `msmonitoring` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `transdate` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `norek` varchar(255) DEFAULT NULL,
  `nokom` varchar(255) DEFAULT NULL,
  `kategoridok5` varchar(255) DEFAULT NULL,
  `namadok5` varchar(255) DEFAULT NULL,
  `nomorjam5` varchar(255) DEFAULT NULL,
  `nomordok5` varchar(255) DEFAULT NULL,
  `tahundok5` varchar(255) DEFAULT NULL,
  `fisikdok5` varchar(255) DEFAULT NULL,
  `ketdok5` varchar(255) DEFAULT NULL,
  `file5` varchar(255) DEFAULT NULL,
  `acc5` varchar(255) DEFAULT NULL,
  `kategoridok4` varchar(255) DEFAULT NULL,
  `namadok4` varchar(255) DEFAULT NULL,
  `nomorjam4` varchar(255) DEFAULT NULL,
  `nomordok4` varchar(255) DEFAULT NULL,
  `tahundok4` varchar(255) DEFAULT NULL,
  `fisikdok4` varchar(255) DEFAULT NULL,
  `ketdok4` varchar(255) DEFAULT NULL,
  `file4` varchar(255) DEFAULT NULL,
  `acc4` varchar(255) DEFAULT NULL,
  `kategoridok3` varchar(255) DEFAULT NULL,
  `namadok3` varchar(255) DEFAULT NULL,
  `nomorjam3` varchar(255) DEFAULT NULL,
  `nomordok3` varchar(255) DEFAULT NULL,
  `tahundok3` varchar(255) DEFAULT NULL,
  `fisikdok3` varchar(255) DEFAULT NULL,
  `ketdok3` varchar(255) DEFAULT NULL,
  `file3` varchar(255) DEFAULT NULL,
  `acc3` varchar(255) DEFAULT NULL,
  `kategoridok2` varchar(255) DEFAULT NULL,
  `namadok2` varchar(255) DEFAULT NULL,
  `nomorjam2` varchar(255) DEFAULT NULL,
  `nomordok2` varchar(255) DEFAULT NULL,
  `tahundok2` varchar(255) DEFAULT NULL,
  `fisikdok2` varchar(255) DEFAULT NULL,
  `ketdok2` varchar(255) DEFAULT NULL,
  `file2` varchar(255) DEFAULT NULL,
  `acc2` varchar(255) DEFAULT NULL,
  `kategoridok1` varchar(255) DEFAULT NULL,
  `namadok1` varchar(255) DEFAULT NULL,
  `nomorjam1` varchar(255) DEFAULT NULL,
  `nomordok1` varchar(255) DEFAULT NULL,
  `tahundok1` varchar(255) DEFAULT NULL,
  `fisikdok1` varchar(255) DEFAULT NULL,
  `ketdok1` varchar(255) DEFAULT NULL,
  `file1` varchar(255) DEFAULT NULL,
  `acc1` varchar(255) DEFAULT NULL,
  `tipedok1` varchar(255) NOT NULL,
  `tipedok2` varchar(255) NOT NULL,
  `tipedok3` varchar(255) NOT NULL,
  `tipedok4` varchar(255) NOT NULL,
  `tipedok5` varchar(255) NOT NULL,
  `detail` varchar(1000) DEFAULT NULL,
  `detailpik` varchar(1000) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `filepik` varchar(255) DEFAULT NULL,
  `alkhcname` varchar(255) NOT NULL,
  `pic1name` varchar(255) DEFAULT NULL,
  `pic2name` varchar(255) DEFAULT NULL,
  `pikhcname` varchar(255) DEFAULT NULL,
  `pikhcname2` varchar(255) DEFAULT NULL,
  `asli1name` varchar(255) NOT NULL,
  `asli2name` varchar(255) NOT NULL,
  `alkop` varchar(255) DEFAULT NULL,
  `alkhc` varchar(255) NOT NULL,
  `pikop` varchar(255) NOT NULL,
  `pikhc1` varchar(255) DEFAULT NULL,
  `pikhc2` varchar(255) DEFAULT NULL,
  `flagrejected` varchar(255) DEFAULT NULL,
  `flagrejectedpik` varchar(255) DEFAULT NULL,
  `flagpiktoalk` int(11) NOT NULL DEFAULT '0',
  `pikprogress` varchar(255) NOT NULL,
  `comreject` varchar(255) DEFAULT NULL,
  `waktu` varchar(255) DEFAULT NULL,
  `diserahkan` int(11) NOT NULL DEFAULT '0',
  `clusterhold` varchar(255) NOT NULL DEFAULT '0',
  `tgldiserahkan` varchar(255) DEFAULT NULL,
  `waktualk` varchar(255) DEFAULT NULL,
  `pikhc3` varchar(255) NOT NULL DEFAULT '0',
  `reminder` int(5) DEFAULT '0',
  `reminderdate` varchar(255) DEFAULT NULL,
  `lokasibg` varchar(255) DEFAULT NULL,
  `rekgiro` varchar(255) DEFAULT NULL,
  `adminis` varchar(255) DEFAULT NULL,
  `komisi` varchar(255) DEFAULT NULL,
  `bataswaktu` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `typeextra` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `msmonitoring`
--

INSERT INTO `msmonitoring` (`id`, `username`, `transdate`, `company`, `norek`, `nokom`, `kategoridok5`, `namadok5`, `nomorjam5`, `nomordok5`, `tahundok5`, `fisikdok5`, `ketdok5`, `file5`, `acc5`, `kategoridok4`, `namadok4`, `nomorjam4`, `nomordok4`, `tahundok4`, `fisikdok4`, `ketdok4`, `file4`, `acc4`, `kategoridok3`, `namadok3`, `nomorjam3`, `nomordok3`, `tahundok3`, `fisikdok3`, `ketdok3`, `file3`, `acc3`, `kategoridok2`, `namadok2`, `nomorjam2`, `nomordok2`, `tahundok2`, `fisikdok2`, `ketdok2`, `file2`, `acc2`, `kategoridok1`, `namadok1`, `nomorjam1`, `nomordok1`, `tahundok1`, `fisikdok1`, `ketdok1`, `file1`, `acc1`, `tipedok1`, `tipedok2`, `tipedok3`, `tipedok4`, `tipedok5`, `detail`, `detailpik`, `file`, `filepik`, `alkhcname`, `pic1name`, `pic2name`, `pikhcname`, `pikhcname2`, `asli1name`, `asli2name`, `alkop`, `alkhc`, `pikop`, `pikhc1`, `pikhc2`, `flagrejected`, `flagrejectedpik`, `flagpiktoalk`, `pikprogress`, `comreject`, `waktu`, `diserahkan`, `clusterhold`, `tgldiserahkan`, `waktualk`, `pikhc3`, `reminder`, `reminderdate`, `lokasibg`, `rekgiro`, `adminis`, `komisi`, `bataswaktu`, `type`, `typeextra`) VALUES
(17, 'Aris Fredy', '08-2-2021', 'PT The Master Steel Manufactory', '0359302195', '0', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', 'JAMINAN', 'Cover note notaris untuk jaminan dan pengikatan ja', '10465631', '11/I/S.ket/2021', '14/01/2021', 'Hardcopy', '', '', '1', 'JAMINAN', 'Cover note notaris untuk jaminan dan pengikatan ja', '9033523,8966939', '12/I/S.Ket/2021', '14/01/2021', 'Hardcopy', '', '', '1', '', '', '', '', '', NULL, NULL, NULL, '', 'Carissa Kurniawan', 'Arief Satria Budiman', 'Monika Tiur Apriani', 'Cicilia Prima Widi Astuti', 'Monika Tiur Apriani', '', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '10:27', 0, '0', NULL, '10:24', '1', 0, 'February 8, 2021, 10:30 am', 'Monika Tiur Apriani', NULL, NULL, NULL, NULL, NULL, NULL),
(18, 'Bertha Elita Hia', '09-2-2021', 'PT. Catur Mitra Sejati Sentosa', '1989000266 / 2059001633', 'Seluruh komitmen', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '0', 'PINJAMAN', 'Covernote', '52609013', '064/CN.NOT/II/2021', '09/02/2021', 'Hardcopy', 'Covernote terkait:\r\n1. Add PK\r\n2. Pengikatan fidusia', '', '1', '', '', '', '', '', NULL, NULL, NULL, '', 'Dewi Virgina', 'Arief Satria Budiman', 'Ni Putu Emy Indrayani', 'Cicilia Prima Widi Astuti', 'Arief Satria Budiman', '', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '13:49', 0, '0', NULL, '13:39', '1', 0, 'February 9, 2021, 2:02 pm', 'Ni Putu Emy Indrayani', NULL, NULL, NULL, NULL, NULL, NULL),
(19, 'Leonhard Bianda', '10-2-2021', 'Fangiono Grup', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '0', 'PINJAMAN', 'Covernote', '', '007/CN/II/2021', '08-02-2021', 'Hardcopy', 'CN Add PK', '', '0', '', '', '', '', '', NULL, NULL, NULL, NULL, 'Mega Febrilia', 'Arief Satria Budiman', 'Monika Tiur Apriani', NULL, NULL, '', '', '1', '0', '0', '0', '0', '1', '0', 1, '0', ' ,by: Monika Tiur Apriani', '08:30', 0, '0', NULL, '13:42', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20, 'Leonhard Bianda', '10-2-2021', 'Borneo Agri Grup', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', 'PINJAMAN', 'Covernote', '', '008/CN/II/2021', '08-02-2021', 'Hardcopy', 'CN Add PK', '', '1', '', '', '', '', '', NULL, NULL, NULL, '', 'Mega Febrilia', 'Arief Satria Budiman', 'Monika Tiur Apriani', 'Cicilia Prima Widi Astuti', 'Arief Satria Budiman', '', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '08:30', 0, '0', NULL, '13:45', '1', 0, 'February 18, 2021, 11:34 am', 'Monika Tiur Apriani', NULL, NULL, NULL, NULL, NULL, NULL),
(21, 'Nadila', '11-2-2021', 'PT UNGGUL WIDYA TEKNOLOGI LESTARI', '035-900-433-9', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', 'JAMINAN', 'Covernote', '36614576', '05/II/S.Ket/2021', '04/02/2021', 'Hardcopy', 'CN atas perpanjangan SHGU No.02/Air Berau dan SHGU No.03/Bunga Tanjung', '', '1', '', '', '', '', '', NULL, NULL, NULL, '', 'Mega Febrilia', 'Arief Satria Budiman', 'Monika Tiur Apriani', 'Cicilia Prima Widi Astuti', 'Arief Satria Budiman', '', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '08:31', 0, '0', NULL, '14:37', '1', 0, 'February 18, 2021, 11:32 am', 'Monika Tiur Apriani', NULL, NULL, NULL, NULL, NULL, NULL),
(22, 'Merina Annisa Noviani', '2-2-2021', 'PT Intiroda Makmur', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'JAMINAN', 'Covernote', '43389055', '09/I/Not/2021', '14-01-2021', 'Hardcopy', 'ppj sertifikat', NULL, '1', '', '', '', '', '', NULL, NULL, NULL, '', 'Elza Widyasari', 'Monika Tiur Apriani', 'Arief Satria Budiman', 'Cicilia Prima Widi Astuti', 'Monika Tiur Apriani', '', '', '1', '1', '1', '1', '1', '0', '0', 1, '0', NULL, NULL, 0, '0', NULL, '13:17', '1', 0, 'February 2, 2021, 3:12 pm', 'Monika Tiur Apriani', NULL, NULL, NULL, NULL, NULL, NULL),
(23, 'Merina Annisa Noviani', '29-1-2021', 'PT Pel Karya Bintang Timur', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'PINJAMAN', 'Covernote', '53738712 dan  53738647 ', '121/NS-NOT/XI/2020', '04-11-2020', 'Hardcopy', 'pengikatan kapal KI 44', NULL, '1', '', '', '', '', '', NULL, NULL, NULL, '', 'Elza Widyasari', 'Monika Tiur Apriani', 'Arief Satria Budiman', 'Cicilia Prima Widi Astuti', 'Monika Tiur Apriani', '', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '14:56', 0, '0', NULL, '14:30', '1', 0, 'January 29, 2021, 3:38 pm', 'Monika Tiur Apriani', NULL, NULL, NULL, NULL, NULL, NULL),
(24, 'Sonia Wibisono', '28-1-2021', 'PT Ketrosden Triasmitra', 'Agen Jaminan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'JAMINAN', 'Covernote', NULL, '19/SW/I/2021', '26/01/2021', 'Hardcopy', 'no jaminan:\r\n30001644 - SKMHT No. 57 - SHGB 00005/Tanjungpakis\r\n30001645 - SKMHT No. 58 - SHGB 1/Bungko\r\n30001646 - SKMHT No. 59 - SHGB 7/Pegagan Kidul\r\n30001647 - SKMHT No. 60 - SHGB 4/Sendangsikucing\r\n30001649 - SKMHT No. 61 - SHGB 1/Ngemboh', NULL, '1', '', '', '', '', '', NULL, NULL, NULL, '', 'Wilbert Karel Wetik', 'Arief Satria Budiman', 'Monika Tiur Apriani', 'Cicilia Prima Widi Astuti', 'Arief Satria Budiman', '', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '14:39', 0, '0', NULL, '14:36', '1', 0, 'January 29, 2021, 9:38 am', 'Monika Tiur Apriani', NULL, NULL, NULL, NULL, NULL, NULL),
(25, 'Vinsensia Givy Gisela', '26-1-2021', 'PT Trans Power Marine Tbk.', '2059012295', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'PINJAMAN', 'Covernote', 'sedang dibuat', '010', '25-01-2021', 'Hardcopy', 'Covernote kapal', NULL, '1', '', '', '', '', '', NULL, NULL, NULL, '', 'Elza Widyasari', 'Arief Satria Budiman', 'Monika Tiur Apriani', 'Cicilia Prima Widi Astuti', 'Arief Satria Budiman', '', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '14:58', 0, '0', NULL, '14:50', '1', 0, 'January 26, 2021, 3:54 pm', 'Monika Tiur Apriani', NULL, NULL, NULL, NULL, NULL, NULL),
(26, 'Junista', '01-2-2021', 'PT Pancaran Samudera Shipyard', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'JAMINAN', 'Cover note notaris untuk jaminan dan pengikatan ja', '54057294', '05', '22-01-2021', 'Hardcopy', NULL, NULL, '1', '', '', '', '', '', NULL, NULL, NULL, '', 'Elza Widyasari', 'Arief Satria Budiman', 'Monika Tiur Apriani', 'Cicilia Prima Widi Astuti', 'Arief Satria Budiman', '', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '09:27', 0, '0', NULL, NULL, '1', 0, 'February 1, 2021, 9:42 am', 'Monika Tiur Apriani', NULL, NULL, NULL, NULL, NULL, NULL),
(27, 'Merina Annisa Noviani', '02-2-2021', 'PT Arista Jaya Lestari', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'JAMINAN', 'Covernote', '52369311', '34//S.KEt./2021', '29-01-2021', 'Hardcopy', 'SHGB 1354Jemur Wonosari', NULL, '1', '', '', '', '', '', NULL, NULL, NULL, '', 'Elza Widyasari', 'Monika Tiur Apriani', 'Arief Satria Budiman', 'Cicilia Prima Widi Astuti', 'Monika Tiur Apriani', '', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '10:43', 0, '0', NULL, '10:32', '1', 0, 'February 2, 2021, 10:51 am', 'Monika Tiur Apriani', NULL, NULL, NULL, NULL, NULL, NULL),
(28, 'Friskilla Clara Swita Abadi Taede', '02-2-2021', 'PT Nana Yamano Technik', '2059071666', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'PINJAMAN', 'Covernote', '14291025', '006/CN/II/2021', '01-02-2021', 'Hardcopy', NULL, NULL, '1', '', '', '', '', '', NULL, NULL, NULL, '', 'Nyimas Wida', 'Arief Satria Budiman', 'Monika Tiur Apriani', 'Cicilia Prima Widi Astuti', 'Ni Putu Emy Indrayani', '', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '09:12', 0, '0', NULL, '15:50', '1', 0, 'February 2, 2021, 9:40 am', 'Monika Tiur Apriani', NULL, NULL, NULL, NULL, NULL, NULL),
(29, 'Hanindha Putri Hardannie', '01-2-2021', 'PT Adi Sarana Armada Tbk', '2059001978', '-', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'JAMINAN', 'Covernote', '54336268', '07', '27/01/2021', 'Hardcopy', 'CN AJF Kendaraan ', NULL, '1', '', '', '', '', '', NULL, NULL, NULL, '', 'Elza Widyasari', 'Arief Satria Budiman', 'Monika Tiur Apriani', 'Cicilia Prima Widi Astuti', 'Arief Satria Budiman', '', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '11:17', 0, '0', NULL, '10:54', '1', 0, 'February 2, 2021, 10:34 am', 'Monika Tiur Apriani', NULL, NULL, NULL, NULL, NULL, NULL),
(31, 'Nadia Wohon', '04-2-2021', 'PT Perkasa Internusa Mandiri', '2059004641', '001', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', 'PINJAMAN', 'Covernote', '54366786', NULL, '03-02-2021', 'Hardcopy', NULL, NULL, '1', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Arief Satria Budiman', 'Ni Putu Emy Indrayani', 'Cicilia Prima Widi Astuti', 'Arief Satria Budiman', '', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '15:34', 0, '0', NULL, '15:33', '1', 0, 'February 23, 2021, 10:13 am', 'Arief Satria Budiman', NULL, NULL, NULL, NULL, NULL, NULL),
(32, 'Dena Rahmania', '15-2-2021', 'PT Indoroti Prima Cemerlang', '2059006597', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '0', 'PINJAMAN', 'Covernote', '', '002/CN/I/2021', '20-01-2021', 'Hardcopy', '', '', '0', '', '', '', '', '', NULL, NULL, NULL, NULL, 'David Ardian', 'Arief Satria Budiman', 'Monika Tiur Apriani', NULL, NULL, '', '', '1', '0', '0', '0', '0', '1', '0', 0, '0', 'Ganti PIC ,by: David Ardian', NULL, 0, '0', NULL, '09:44', '0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(33, 'Christy Purnama', '17-2-2021', 'PT Indobaruna Bulk Transport', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '0', 'JAMINAN', 'Cover note notaris untuk jaminan dan pengikatan ja', '54385448 dan 54386305', '016', '08022021', 'Hardcopy', '', '', '1', '', '', '', '', '', NULL, NULL, NULL, '', 'Elza Widyasari', 'Arief Satria Budiman', 'Ni Putu Emy Indrayani', 'Cicilia Prima Widi Astuti', 'Arief Satria Budiman', '', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '09:25', 0, '0', NULL, '10:17', '1', 0, 'February 17, 2021, 9:59 am', 'Ni Putu Emy Indrayani', NULL, NULL, NULL, NULL, NULL, NULL),
(35, 'Jonathan', '17-2-2021', 'Erajaya Group', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '0', 'PINJAMAN', 'Covernote', '29053196', '8/SW/II/2021', '11/02/2021', 'Hardcopy', '', '', '1', '', '', '', '', '', NULL, NULL, NULL, '', 'Carissa Kurniawan', 'Arief Satria Budiman', 'Ni Putu Emy Indrayani', 'Cicilia Prima Widi Astuti', 'Monika Tiur Apriani', '', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '10:35', 0, '0', NULL, '10:33', '1', 0, 'February 17, 2021, 10:54 am', 'Ni Putu Emy Indrayani', NULL, NULL, NULL, NULL, NULL, NULL),
(36, 'Leonhard Bianda', '18-2-2021', 'Fangiono Grup', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', 'PINJAMAN', 'Covernote', '', '007/CN/II/2021', '08-02-2021', 'Hardcopy', 'CN Add PK', '', '1', '', '', '', '', '', NULL, NULL, NULL, '', 'Mega Febrilia', 'Arief Satria Budiman', 'Monika Tiur Apriani', 'Cicilia Prima Widi Astuti', 'Arief Satria Budiman', '', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '12:58', 0, '0', NULL, '11:31', '1', 0, 'February 18, 2021, 11:33 am', 'Monika Tiur Apriani', NULL, NULL, NULL, NULL, NULL, NULL),
(37, 'Leonhard Bianda', '18-2-2021', 'PT TH Indo Plantations', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', 'PINJAMAN', 'Covernote', 'tertulis di CN', '005/CN/I/2021', '29-01-2021', 'Hardcopy', 'CN ', '', '1', '', '', '', '', '', NULL, NULL, NULL, '', 'Mega Febrilia', 'Arief Satria Budiman', 'Monika Tiur Apriani', 'Cicilia Prima Widi Astuti', 'Arief Satria Budiman', '', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '12:59', 0, '0', NULL, '11:44', '1', 0, 'February 18, 2021, 11:33 am', 'Arief Satria Budiman', NULL, NULL, NULL, NULL, NULL, NULL),
(39, 'Maria', '17-2-2021', 'PT. Ketrosden Triasmitra', 'Agen Jaminan', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', 'JAMINAN', 'Cover note notaris untuk jaminan dan pengikatan ja', '30001647', '40/DM/Not-PPAT/II/2021', '09/02/2021', 'Hardcopy', 'CN atas APHT Sertifikat No. 4/Sdendangsikucing an PT. JMP', '', '1', '', '', '', '', '', NULL, NULL, NULL, '', 'David Ardian', 'Monika Tiur Apriani', 'Arief Satria Budiman', 'Ona', 'Ni Putu Emy Indrayani', '', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '13:49', 0, '0', NULL, '13:45', '1', 0, 'February 17, 2021, 1:58 pm', 'Monika Tiur Apriani', NULL, NULL, NULL, NULL, NULL, NULL),
(40, 'Nadila', '19-2-2021', 'FKS GRUP', '205-901-210-4', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '0', 'JAMINAN', 'Covernote', '53894747', '023/NOT/XI/2020', '03/11/2020', 'Hardcopy', 'CN APHT di Lampung an FKSMA (draft sudah diemail tgl 04-11-2020, terlampir)\r\n- Asli CN baru diserahkan karena sebelumnya ada penahanan dokumen oleh Notaris', '1613640464-FKSAPHT_Lampung.msg', '1', 'JAMINAN', 'Covernote', '53894838', '57/NRHP/XI/2020', '30/11/2020', 'Hardcopy', 'CN APHT di Makassar an MT (draft sudah diemail tgl 04-12-2020, terlampir)\r\n- Asli CN baru diserahkan karena sebelumnya ada penahanan dokumen oleh Notaris', '1613640464-FKSDraftPengikatan_Makassar.msg', '1', 'JAMINAN', 'Covernote', '53895199', '4/NB/NOT/XI/2020', '24/11/2020', 'Hardcopy', 'CN APHT di Cilegon an PDSU (draft sudah diemail tgl 24-11-2020, terlampir)\r\n- Asli CN baru diserahkan karena sebelumnya ada penahanan dokumen oleh Notaris', '1613640464-FKSPengikatanJaminan_Cilegon.msg', '1', '', '', '', '', '', NULL, NULL, NULL, '', 'Mega Febrilia', 'Arief Satria Budiman', 'Monika Tiur Apriani', 'Cicilia Prima Widi Astuti', 'Monika Tiur Apriani', '', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '11:29', 0, '0', NULL, '11:27', '1', 0, 'February 19, 2021, 11:15 am', 'Arief Satria Budiman', NULL, NULL, NULL, NULL, NULL, NULL),
(41, 'Vinsensia Givy Gisela', '18-2-2021', 'PT Mandiri Tunas Finance', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', 'PINJAMAN', 'Covernote', '1156 1834', '13', '11-02-2021', 'Hardcopy', 'Covernote PK + AJF', '', '1', '', '', '', '', '', NULL, NULL, NULL, '', 'Elza Widyasari', 'Arief Satria Budiman', 'Monika Tiur Apriani', 'Cicilia Prima Widi Astuti', 'Arief Satria Budiman', '', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '15:55', 0, '0', NULL, '15:54', '1', 0, 'February 18, 2021, 3:57 pm', 'Monika Tiur Apriani', NULL, NULL, NULL, NULL, NULL, NULL),
(42, 'Christa Amelia', '19-2-2021', 'PT BPR Irian Sentosa', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '0', 'PINJAMAN', 'Covernote', '', '22', '21-12-2020', 'Hardcopy', 'revisi covernote no 22/SA/XII/2020 bagian jangka waktu penyerahan dari 270hari menjadi 90 hari. covernote untuk PT BPR Irian Sentosa, BPR Modern Express, BPR Palu Lokadana Utama', '', '1', '', '', '', '', '', NULL, NULL, NULL, '', 'Elza Widyasari', 'Arief Satria Budiman', 'Ni Putu Emy Indrayani', 'Cicilia Prima Widi Astuti', 'Ni Putu Emy Indrayani', '', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '09:44', 0, '0', NULL, '09:29', '1', 0, 'February 19, 2021, 10:01 am', 'Ni Putu Emy Indrayani', NULL, NULL, NULL, NULL, NULL, NULL),
(43, 'Christa Amelia', '19-2-2021', 'PT Astra Multi Finance', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', 'PINJAMAN', 'Covernote', '54415518', '05/2021', '17-02-2021', 'Hardcopy', '', '', '1', '', '', '', '', '', NULL, NULL, NULL, '', 'Elza Widyasari', 'Arief Satria Budiman', 'Monika Tiur Apriani', 'Cicilia Prima Widi Astuti', 'Ni Putu Emy Indrayani', '', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '09:45', 0, '0', NULL, '09:31', '1', 0, 'February 19, 2021, 10:00 am', 'Monika Tiur Apriani', NULL, NULL, NULL, NULL, NULL, NULL),
(44, 'Bertha Elita Hia', '22-2-2021', 'PT. Inti Menara Jaya', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '1', 'JAMINAN', 'Cover note notaris untuk jaminan dan pengikatan ja', '53713962', '020/II/CN/NKCB/2021', '19/02/2021', 'Hardcopy', 'Covernote perpanjangan SKMHT', '', '1', '', '', '', '', '', NULL, NULL, NULL, '', 'Dewi Virgina', 'Arief Satria Budiman', 'Monika Tiur Apriani', 'Cicilia Prima Widi Astuti', 'Arief Satria Budiman', '', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, '10:01', 0, '0', NULL, '09:33', '1', 0, 'February 22, 2021, 10:45 am', 'Arief Satria Budiman', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `msmonreturn`
--

CREATE TABLE `msmonreturn` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `username2` varchar(255) DEFAULT NULL,
  `transdate` varchar(255) NOT NULL,
  `deadline` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `dokumen` varchar(255) DEFAULT NULL,
  `norek` varchar(255) DEFAULT NULL,
  `nojaminan` varchar(255) DEFAULT NULL,
  `nokomit` varchar(255) DEFAULT NULL,
  `kondisi` varchar(255) DEFAULT NULL,
  `nopolis` varchar(255) DEFAULT NULL,
  `periode` varchar(255) DEFAULT NULL,
  `polislama` varchar(255) DEFAULT NULL,
  `detail` varchar(1000) DEFAULT NULL,
  `detail2` varchar(1000) DEFAULT NULL,
  `keaslian` varchar(255) DEFAULT NULL,
  `flagkeaslian` varchar(255) DEFAULT '0',
  `alkhcname` varchar(255) NOT NULL,
  `pic1name` varchar(255) DEFAULT NULL,
  `pic2name` varchar(255) DEFAULT NULL,
  `pikhcname` varchar(255) DEFAULT NULL,
  `pikhcname2` varchar(255) DEFAULT NULL,
  `alkop` varchar(255) DEFAULT NULL,
  `alkhc` varchar(255) NOT NULL,
  `pikop` varchar(255) NOT NULL,
  `pikhc1` varchar(255) DEFAULT NULL,
  `pikhc2` varchar(255) DEFAULT NULL,
  `flagrejected` varchar(255) DEFAULT NULL,
  `flagrejectedpik` varchar(255) DEFAULT NULL,
  `flagpiktoalk` varchar(255) DEFAULT NULL,
  `alkhcname2` varchar(255) DEFAULT NULL,
  `pic1name2` varchar(255) DEFAULT NULL,
  `pic2name2` varchar(255) DEFAULT NULL,
  `pikhcname3` varchar(255) DEFAULT NULL,
  `alkop2` varchar(255) DEFAULT '0',
  `alkhc2` varchar(255) DEFAULT '0',
  `pikop2` varchar(255) DEFAULT '0',
  `pikhc12` varchar(255) DEFAULT '0',
  `flagrejected2` varchar(255) DEFAULT '0',
  `flagrejectedpik2` varchar(255) DEFAULT '0',
  `flagpiktoalk2` varchar(255) DEFAULT '0',
  `pikprogress` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `timestampprovisi` varchar(255) DEFAULT NULL,
  `typeextra` varchar(255) DEFAULT NULL,
  `pikmargin` varchar(255) DEFAULT NULL,
  `comreject` varchar(255) DEFAULT NULL,
  `waktu` varchar(255) DEFAULT NULL,
  `diserahkan` int(11) NOT NULL DEFAULT '0',
  `clusterhold` varchar(255) NOT NULL DEFAULT '0',
  `tgldiserahkan` varchar(255) DEFAULT NULL,
  `waktualk` varchar(255) DEFAULT NULL,
  `pikhc3` varchar(255) NOT NULL DEFAULT '0',
  `reminder` int(5) DEFAULT '0',
  `reminderdate` varchar(255) DEFAULT NULL,
  `lokasibg` varchar(255) DEFAULT NULL,
  `rekgiro` varchar(255) DEFAULT NULL,
  `adminis` varchar(255) DEFAULT NULL,
  `komisi` varchar(255) DEFAULT NULL,
  `bataswaktu` varchar(255) DEFAULT NULL,
  `jangkabg` varchar(255) DEFAULT NULL,
  `jenisjamin` varchar(255) DEFAULT NULL,
  `alamatpenerimajamin` varchar(255) DEFAULT NULL,
  `namapenerimajamin` varchar(255) DEFAULT NULL,
  `alamatjamin` varchar(255) DEFAULT NULL,
  `namajamin` varchar(255) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `datereturn1` varchar(255) NOT NULL,
  `datereturn2` varchar(255) NOT NULL,
  `datereturn3` varchar(255) NOT NULL,
  `datereturn4` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `msmonreturn`
--

INSERT INTO `msmonreturn` (`id`, `username`, `username2`, `transdate`, `deadline`, `company`, `dokumen`, `norek`, `nojaminan`, `nokomit`, `kondisi`, `nopolis`, `periode`, `polislama`, `detail`, `detail2`, `keaslian`, `flagkeaslian`, `alkhcname`, `pic1name`, `pic2name`, `pikhcname`, `pikhcname2`, `alkop`, `alkhc`, `pikop`, `pikhc1`, `pikhc2`, `flagrejected`, `flagrejectedpik`, `flagpiktoalk`, `alkhcname2`, `pic1name2`, `pic2name2`, `pikhcname3`, `alkop2`, `alkhc2`, `pikop2`, `pikhc12`, `flagrejected2`, `flagrejectedpik2`, `flagpiktoalk2`, `pikprogress`, `type`, `timestampprovisi`, `typeextra`, `pikmargin`, `comreject`, `waktu`, `diserahkan`, `clusterhold`, `tgldiserahkan`, `waktualk`, `pikhc3`, `reminder`, `reminderdate`, `lokasibg`, `rekgiro`, `adminis`, `komisi`, `bataswaktu`, `jangkabg`, `jenisjamin`, `alamatpenerimajamin`, `namapenerimajamin`, `alamatjamin`, `namajamin`, `file`, `datereturn1`, `datereturn2`, `datereturn3`, `datereturn4`) VALUES
(1, 'u061452', 'Meltia Inapril', '21-2-2020', '5-2-2020', 'PT Kevindo Putra Sejati', 'Perjanjian Penyelesaian Utang', '2059004624', '', '0000001', '', NULL, NULL, NULL, '', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Adi Fajar', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '16:02', 0, '0', NULL, '14:42', '0', 0, NULL, 'Adi Fajar', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', ''),
(5, 'u061452', 'Meltia Inapril', '16-4-2020', '7-2-2020', 'PT Catur Sentosa Adiprana', 'AJF dan SJF', '0359096137', '15625742', '0000004', '', NULL, NULL, NULL, '', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Adi Fajar', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '08:19', 0, '0', NULL, '13:43', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', ''),
(6, 'u061452', 'Meltia Inapril', '18-2-2020', '7-2-2020', 'Ridwan Tandiawan Grup', 'SHT dan APHT', '2059009154', '21502166', '0000001', '', NULL, NULL, NULL, 'salah pinjam', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '17:22', 0, '0', NULL, '17:21', '0', 0, NULL, 'Teguh Waspada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', ''),
(7, 'u061452', 'Meltia Inapril', '24-4-2020', '7-2-2020', 'Ridwan Tandiawan Grup', 'SHT dan APHT', '2059009154', '21502000', '0000001', '', NULL, NULL, NULL, 'tidak jadi koreksi, APHT No. 145/ES/APHT/XI/2020 pada SHT No. 146/2010', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '09:04', 0, '0', NULL, '08:49', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', ''),
(8, 'u061452', 'Meltia Inapril', '24-4-2020', '7-2-2020', 'Ridwan Tandiawan Grup', 'SHT dan APHT', '2059009154', '21502083', '0000001', '', NULL, NULL, NULL, 'tidak jadi dikoreksi, APHT No. 147/ES/APHT/XI/2010 pada SHT 144/2010', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '09:04', 0, '0', NULL, '08:50', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', ''),
(9, 'u061452', 'Meltia Inapril', '24-4-2020', '7-2-2020', 'Ridwan Tandiawan Grup', 'SHT dan APHT', '2059009154', '21501895', '0000001', '', NULL, NULL, NULL, 'tidak jadi koreksi, APHT No. 148/ES/APHT/XI/2010 pada SHT No. 143/2010', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '09:04', 0, '0', NULL, '08:52', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', ''),
(10, 'u061452', 'Meltia Inapril', '24-4-2020', '7-2-2020', 'Ridwan Tandiawan Grup', 'SHT dan APHT', '2059009154', '21502240', '0000001', '', NULL, NULL, NULL, 'tidak jadi koreksi, APHT No. 149/ES/APHT/XI/2010 pada SHT No. 142/2010', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '09:04', 0, '0', NULL, '08:53', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', ''),
(12, 'u066709', 'Arief Satria Budiman', '17-2-2020', '11-2-2020', 'PT So Good Food', 'APHT', '2059005981', '42673343', '0000001', '', NULL, NULL, NULL, 'APHT 039/2016 tgl 15/01/2016 (APHT melekat)\r\nSHT 04894/2016 tgl 27/09/2016', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '14:49', 0, '0', NULL, '10:03', '0', 0, NULL, 'Teguh Waspada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', ''),
(13, 'u066709', 'Arief Satria Budiman', '17-2-2020', '11-2-2020', 'PT So Good Food', 'APHT', '2059005981', '42673343', '0000001', '', NULL, NULL, NULL, 'APHT 040/2016 tgl 15/01/2016 (APHT melekat)\r\nSHT 04894/2016 tgl 27/09/2016', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '14:49', 0, '0', NULL, '10:04', '0', 0, NULL, 'Teguh Waspada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', ''),
(14, 'u066709', 'Arief Satria Budiman', '11-1-2021', '11-2-2020', 'PT Muliaglass', 'Sertifikat', '2059071488', '28821213', '0000001', '', NULL, NULL, NULL, 'return Sertifikat No. 32/Wangunharja', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Olivia Santoso', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '17:56', 0, '0', NULL, '10:53', '0', 0, NULL, 'Teguh Waspada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'January 11, 2021, 10:53 am', 'January 11, 2021, 5:56 pm', 'January 12, 2021, 3:12 pm', 'January 19, 2021, 11:07 am'),
(15, 'u066709', 'Arief Satria Budiman', '11-1-2021', '12-2-2020', 'PT Muliaglass', 'Sertifikat', '2059071488', '28821213', '0000001', '', NULL, NULL, NULL, 'return Sertifikat No. 10/Sukaresmi', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Olivia Santoso', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '17:56', 0, '0', NULL, '10:54', '0', 0, NULL, 'Teguh Waspada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'January 11, 2021, 10:54 am', 'January 11, 2021, 5:56 pm', 'January 12, 2021, 3:13 pm', 'January 19, 2021, 11:07 am'),
(16, 'u066709', 'Arief Satria Budiman', '11-1-2021', '12-2-2020', 'PT Muliaglass', 'Sertifikat', '2059071488', '28821213', '0000001', '', NULL, NULL, NULL, 'return Sertifikat No. 14/Sukaresmi', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Olivia Santoso', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '17:57', 0, '0', NULL, '10:56', '0', 0, NULL, 'Teguh Waspada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'January 11, 2021, 10:56 am', 'January 11, 2021, 5:57 pm', 'January 12, 2021, 3:14 pm', 'January 19, 2021, 11:07 am'),
(17, 'u066709', 'Arief Satria Budiman', '11-1-2021', '12-2-2020', 'PT Muliaglass', 'Sertifikat', '2059071488', '28821213', '0000001', '', NULL, NULL, NULL, 'return No. 2047/Sukaresmi', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Olivia Santoso', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '17:57', 0, '0', NULL, '10:56', '0', 0, NULL, 'Teguh Waspada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'January 11, 2021, 10:56 am', 'January 11, 2021, 5:57 pm', 'January 12, 2021, 3:14 pm', 'January 19, 2021, 11:07 am'),
(18, 'u066709', 'Arief Satria Budiman', '11-1-2021', '12-2-2020', 'PT Muliaglass', 'Sertifikat', '2059071488', '28821213', '0000001', '', NULL, NULL, NULL, 'return sertifikat No. 2048/Sukaresmi', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Olivia Santoso', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '17:57', 0, '0', NULL, '10:57', '0', 0, NULL, 'Teguh Waspada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'January 11, 2021, 10:57 am', 'January 11, 2021, 5:57 pm', 'January 12, 2021, 3:15 pm', 'January 19, 2021, 11:07 am'),
(19, 'u066709', 'Arief Satria Budiman', '11-1-2021', '12-2-2020', 'PT Muliaglass', 'Sertifikat', '2059071488', '28821213', '0000001', '', NULL, NULL, NULL, 'return Sertifikat No. 31/Wangunharja', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Olivia Santoso', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '17:57', 0, '0', NULL, '10:58', '0', 0, NULL, 'Teguh Waspada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'January 11, 2021, 10:58 am', 'January 11, 2021, 5:57 pm', 'January 12, 2021, 3:15 pm', 'January 19, 2021, 11:07 am'),
(23, 'u066709', 'Arief Satria Budiman', '26-3-2020', '13-2-2020', 'PT Global Eco Chemicals Indonesia', 'Perubahan Pertama atas PK', '2059011001', '-', '0000001', '', NULL, NULL, NULL, 'ADD PK KE 1 no. 71 tgl 29-11-2019', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Keren Hapukh', 'Choose PIK Operator', 'Iwati', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '15:54', 0, '0', NULL, '12:34', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', 'February 24, 2021, 11:20 am'),
(24, 'u061452', 'Meltia Inapril', '18-2-2020', '13-2-2020', 'PT Arta Batrindo', 'SKMHT', '01689001678', '26350918', '0000001', '', NULL, NULL, NULL, 'Sudah Selesai Scan', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Adi Fajar', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '16:49', 0, '0', NULL, '16:28', '0', 0, NULL, 'Adi Fajar', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', ''),
(25, 'Arief Satria Budiman', 'Arief Satria Budiman', '12-3-2021', '13-2-2020', 'PT Central Mega Kencana', 'Sertifikat', '2689004517', '24571317', '0000001', '', NULL, NULL, NULL, 'SHGB 1495/Menteng Dalam \r\nsudah diserahkan ke ASLI tgl 12/03/2021', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Karimuda Saputra S L', 'Olivia Santoso', 'Ratna Irana M P', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '17:02', 0, '0', NULL, '16:57', '0', 0, NULL, 'Karimuda Saputra S L', NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', 'April 21, 2021, 4:57 pm', 'April 21, 2021, 5:02 pm', 'April 21, 2021, 5:03 pm', 'April 21, 2021, 5:03 pm'),
(26, 'Arief Satria Budiman', 'Arief Satria Budiman', '12-3-2021', '', 'PT Central Mega Kencana', 'Sertifikat', '2689004517', '24571317', '0000001', '', NULL, NULL, NULL, 'Sertifikat No. 584/Harjamekar sudah diserahkan ke ASLI tgl 12/03/2021', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Adi Fajar', 'Olivia Santoso', 'Ratna Irana M P', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '14:29', 0, '0', NULL, '11:13', '0', 0, NULL, 'Olivia Santoso', NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', 'April 22, 2021, 11:13 am', 'April 22, 2021, 2:29 pm', 'April 22, 2021, 6:07 pm', 'April 22, 2021, 7:42 pm'),
(27, 'u066709', 'Arief Satria Budiman', '29-4-2020', '18-2-2020', 'PT. ULTRA PRIMA ABADI', 'Perubahan PK', '0359006057', '-', '0000003', '', NULL, NULL, NULL, 'Perubahan PK No. 14 tgl 10-01-2019\r\nu/ koreksi notaris', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '17:22', 0, '0', NULL, '15:58', '0', 0, NULL, 'Teguh Waspada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', ''),
(29, 'u066709', 'Arief Satria Budiman', '29-4-2020', '18-2-2020', 'PT Ultra Prima Abadi', 'Perubahan PK', '0359006057', '-', '0000003', '', NULL, NULL, NULL, 'Perubahan PK No. 100 tgl 26-09-2018\r\nu/ koreksi notaris', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '17:22', 0, '0', NULL, '15:58', '0', 0, NULL, 'Teguh Waspada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', ''),
(30, 'u066709', 'Arief Satria Budiman', '29-4-2020', '18-2-2020', 'PT Ultra Prima Abadi', 'Perubahan PK', '0359006057', '-', '0000003', '', NULL, NULL, NULL, 'Perubahan PK No. 100 tgl 23-05-2019\r\nu/ koreksi notaris', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '17:22', 0, '0', NULL, '15:59', '0', 0, NULL, 'Teguh Waspada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', ''),
(31, 'u066709', 'Arief Satria Budiman', '9-6-2020', '14-2-2020', 'PT Dirgaputra Ekapratama', 'SHGB', '3429371881', '27831320', '0000001', '', NULL, NULL, NULL, 'SHGB 188/Jatinegara\r\npengembalian borrow', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Keren Hapukh', 'Olivia Santoso', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '14:22', 0, '0', NULL, '11:31', '0', 0, NULL, 'Olivia Santoso', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', ''),
(33, 'u066709', 'Arief Satria Budiman', '4-3-2020', '17-2-2020', 'PT. Wahana Mas Mulia', 'Perubahan PK', '02059010331', '', '0000001', '', NULL, NULL, NULL, 'Perubahan PK No. 100 tgl 24-06-2019', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Adi Fajar', 'Choose PIK Operator', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '14:09', 0, '0', NULL, '14:08', '0', 0, NULL, 'Adi Fajar', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', ''),
(34, 'u061452', 'Meltia Inapril', '24-4-2020', '17-2-2020', 'Ridwan Tandiawan Grup', 'SHT (APHT MELEKAT)', '2059009154', '21502182', '0000001', '', NULL, NULL, NULL, 'tidak jadi koreksi, APHT No. 146/ES/APHT/XI/2010 pada SHT No. 145/2010', NULL, NULL, '0', 'Cicilia Prima Widi Astuti', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'Custom', NULL, NULL, NULL, NULL, '09:05', 0, '0', NULL, '08:54', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `msnews`
--

CREATE TABLE `msnews` (
  `id` int(11) NOT NULL,
  `stamp` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `news` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `msnews`
--

INSERT INTO `msnews` (`id`, `stamp`, `name`, `title`, `news`) VALUES
(1, '1558074825', 'Kevin Cahyadi', 'Update E-Orhar', '+ Silahkan membuka aplikasi melalui link : <a url>http://10.21.218.28/home.php</a>\r\n+ Terdapat pilihan baru di bagian Fin : Bank Garansi\r\n+ Kolom baru : Keterangan pada bagian Jaminan baru - Non Fin\r\n+ Fin : Filter by kategori\r\n\r\nJika ada masalah tolong langsung kontak Kevin Cahyadi, Thanks\r\n'),
(2, '1565271630', 'Kevin Cahyadi', 'Update E-orhar', '+ ALKOP: FIX Revisi Provisi ( Tanggal Hilang )\r\n\r\n+ Silahkan membuka aplikasi melalui link : <a url>http://10.21.218.28/home.php</a>\r\n\r\nJika ada masalah tolong langsung kontak Kevin Cahyadi, Thanks\r\n'),
(3, '1571206431', 'Kevin Cahyadi', 'Update E-Orhar 16 Oktober', 'Update E-Orhar \r\n-Fitur order CAMS dari SLK ( Masih Uji coba hanya untuk Cluster pak David ).\r\n-SLK sekarang dapat merubah orderan yang belum di proses PIK serta order Future.\r\n-dsb..\r\n\r\nJika ada masalah tolong segera kontak Kevin Cahyadi / Pak Wilbert,\r\nTerima Kasih.'),
(4, '1571656474', 'Kevin Cahyadi', 'Update E-Orhar CAMS', 'Update E-Orhar untuk bagian CAMS\r\n- Order SLK ke CAMS sekarang dapat dilanjutkan ke ASLI\r\n- Menu navigasi baru dijadikan satu agar rapi\r\n- Tampilan RTGS pada SLK HC\r\n- Pilihan Yes / No pada semua Authorize\r\n- PIK Supervisor 2 sekarang dapat menerima orderan CAMS dan ASLI\r\n\r\nJika ada masalah tolong segera kontak Kevin Cahyadi / Pak Wilbert,\r\nTerima Kasih.'),
(5, '1571656473', 'Kevin Cahyadi', 'Update E-Orhar Borrow - Return & PIK Monitoring', 'Update E-Orhar Selasa 4 Feb 2020 \r\n-Untuk Borrow & Return\r\n-Untuk bagian PIK Monitoring\r\n( Mohon untuk tidak dipakai dulu sebelum ada notifikasi lebih lanjut. )\r\n\r\nJika ada masalah tolong segera kontak Kevin Cahyadi / Pak Wilbert,\r\nTerima Kasih.'),
(6, '1582097914', 'SIC KCK', 'Update E-Orhar Borrow & Return', 'Update E-Orhar Selasa 4 Feb 2020 \r\n-Untuk Borrow & Return\r\n-Untuk bagian PIK Monitoring\r\n\r\nJika ada masalah tolong segera kontak Pak Alfa dan Pak Walid\r\nTerima Kasih.');

-- --------------------------------------------------------

--
-- Struktur dari tabel `msnonfintrans`
--

CREATE TABLE `msnonfintrans` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `dbt` varchar(255) DEFAULT NULL,
  `idj` varchar(255) DEFAULT NULL,
  `rek` varchar(255) DEFAULT NULL,
  `cis` varchar(255) DEFAULT NULL,
  `akte1` varchar(255) DEFAULT NULL,
  `noakte1` varchar(255) DEFAULT NULL,
  `dateakte1` varchar(255) DEFAULT NULL,
  `noakte2` varchar(255) DEFAULT NULL,
  `dateakte2` varchar(255) DEFAULT NULL,
  `sekon` varchar(255) DEFAULT NULL,
  `tipeomset` varchar(255) DEFAULT NULL,
  `omset` varchar(255) DEFAULT NULL,
  `datempk` varchar(255) DEFAULT NULL,
  `tipempk` varchar(255) DEFAULT NULL,
  `mpk` varchar(255) DEFAULT NULL,
  `tipeapr` varchar(255) DEFAULT NULL,
  `apr` varchar(255) DEFAULT NULL,
  `kjpp` varchar(255) DEFAULT NULL,
  `tipeikat` varchar(255) DEFAULT NULL,
  `ikat` varchar(255) DEFAULT NULL,
  `dateikat` varchar(255) DEFAULT NULL,
  `tambah` varchar(255) DEFAULT NULL,
  `komitmen` varchar(255) DEFAULT NULL,
  `nokom` varchar(255) DEFAULT NULL,
  `kategori` varchar(255) DEFAULT NULL,
  `file1` varchar(255) DEFAULT NULL,
  `file2` varchar(255) DEFAULT NULL,
  `file3` varchar(255) DEFAULT NULL,
  `file4` varchar(255) DEFAULT NULL,
  `file5` varchar(255) DEFAULT NULL,
  `filepik` varchar(255) DEFAULT NULL,
  `uraian` varchar(2000) DEFAULT NULL,
  `detail` varchar(2000) DEFAULT NULL,
  `unik` varchar(255) DEFAULT NULL,
  `alkhc` varchar(255) DEFAULT NULL,
  `pikop` varchar(255) DEFAULT NULL,
  `pikhc1` varchar(255) DEFAULT NULL,
  `pikhc2` varchar(255) DEFAULT NULL,
  `alkhcname` varchar(255) DEFAULT NULL,
  `pik1name` varchar(255) DEFAULT NULL,
  `pik2name` varchar(255) DEFAULT NULL,
  `pikname` varchar(255) NOT NULL,
  `pikhc1name` varchar(255) DEFAULT NULL,
  `pikhc2name` varchar(255) DEFAULT NULL,
  `rejectedalkhc` varchar(255) DEFAULT NULL,
  `rejectedpikop` varchar(255) DEFAULT NULL,
  `rejectedpikhc` varchar(255) DEFAULT NULL,
  `comreject` varchar(255) DEFAULT NULL,
  `timealk` varchar(255) DEFAULT NULL,
  `waktuHC` varchar(255) NOT NULL,
  `waktuPIKO` varchar(255) NOT NULL,
  `waktuPIKHC` varchar(255) NOT NULL,
  `omzet` int(11) NOT NULL DEFAULT '0',
  `reminder` int(5) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `msnonfintrans`
--

INSERT INTO `msnonfintrans` (`id`, `name`, `type`, `date`, `dbt`, `idj`, `rek`, `cis`, `akte1`, `noakte1`, `dateakte1`, `noakte2`, `dateakte2`, `sekon`, `tipeomset`, `omset`, `datempk`, `tipempk`, `mpk`, `tipeapr`, `apr`, `kjpp`, `tipeikat`, `ikat`, `dateikat`, `tambah`, `komitmen`, `nokom`, `kategori`, `file1`, `file2`, `file3`, `file4`, `file5`, `filepik`, `uraian`, `detail`, `unik`, `alkhc`, `pikop`, `pikhc1`, `pikhc2`, `alkhcname`, `pik1name`, `pik2name`, `pikname`, `pikhc1name`, `pikhc2name`, `rejectedalkhc`, `rejectedpikop`, `rejectedpikhc`, `comreject`, `timealk`, `waktuHC`, `waktuPIKO`, `waktuPIKHC`, `omzet`, `reminder`) VALUES
(1, 'Merlyn Halim', 'Jaminan Baru', '24-5-2019', 'PT Gunung Raja Paksi', NULL, '205-900-924-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'orhar-240519-1426-GRPblokirdepositoLC24-05-2019.pdf', '', '', '', '', 'orhar-ec2sHp1H-eorharmerlyngunungrajapaksi27mei2019.docx', NULL, '', '1558682808', '1', '1', '1', '1', 'Dewi Virgina', 'Nurlaili Putri', 'Nike Elvira', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, NULL, '', '', '', 0, 0),
(2, 'Merlyn Halim', 'Jaminan Baru', '27-5-2019', 'PT Gunung Raja Paksi', NULL, '205-900-930-8', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'orhar-270519-0913-BilyetGunungRajaPaksi.pdf', '', '', '', '', 'orhar-Dv1qZ6JZ-RegisjaminanAJ436062_Merlyn_27Mei19.docx', NULL, '', '1558923227', '1', '1', '1', '1', 'Dewi Virgina', 'Nurlaili Putri', 'Nike Elvira', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, NULL, '', '', '', 0, 0),
(4, 'Citra Arruum', 'Update Jaminan', '27-5-2019', 'PT. Bina Karya Prima', '3247020', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 'orhar-270519-1005-covernotesigningperpanjanganskmht24Mei2019.pdf', '', '', '', 'orhar-W8ZHD8iE-Updatejaminanperpanjanganskmht_Citra_27Mei19.docx', 'Mohon bantuannya untuk dapat mengupdate data terkait dengan nomor dan tanggal di ILS karena adanya perpanjangan skmht PT. Bina Karya Prima tanggal 24 Mei 2019.', 'Mohon bantuannya untuk dapat mengupdate data terkait dengan nomor dan tanggal di ILS karena adanya perpanjangan skmht PT. Bina Karya Prima tanggal 24 Mei 2019.', NULL, '1', '1', '1', '1', 'Wilbert Karel Wetik', 'Nurlaili Putri', 'Fitri Dwi', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, NULL, '', '', '', 0, 0),
(5, 'Bertha Elita Hia', 'PemRek', '27-5-2019', 'PT Sapta Tunggal Mulia', NULL, NULL, '045-467-250', NULL, NULL, NULL, NULL, NULL, '889031/26 & 818211/18', 'None', '-', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', 'orhar-270519-1400-NonFIn-PTSaptaTunggalMulia-DebiturBaru.zip', '', 'orhar-U1QpNNef-PT.septatunggalmulia.docx', NULL, '1. Pembukaan rek pinjaman baru (rek. ILS)\r\n2. Registrasi data debitur\r\n3. Registrasi 5 nomor jaminan ([1]agunan cessie; [2]agunan CG PT Intiland Infinita; [3] Saham Ir Syahrir; [4] Saham Adi Wahyu P; [5] Saham PT Estrella 10\r\n4. Registrasi data jaminan', NULL, '1', '1', '1', '1', 'Dewi Virgina', 'Fitri Dwi', 'Nike Elvira', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, NULL, '', '', '', 0, 0),
(6, 'Merina Annisa Noviani', 'Jaminan Baru', '27-5-2019', 'PT HRC Prima Sejahtera', NULL, '205-900-737-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'orhar-270519-1030-image2019-05-27-101836.pdf', '', '', '', '', 'orhar-bzxEeQfq-Regisjaminankendaraan_Merina_27Mei19.docx', NULL, 'regis jaminan KI 4.14', '1558927808', '1', '1', '1', '1', 'Elza Widyasari', 'Nurlaili Putri', 'Nike Elvira', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, NULL, '', '', '', 0, 0),
(7, 'Conny Yusran', 'Jaminan Baru', '27-5-2019', 'PT. FORTUNA PACIFIC', NULL, '397-902-078-4', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'orhar-270519-1605-persediaan2019-05-27-160158.pdf', 'orhar-270519-1605-piutang2019-05-27-160114.pdf', 'orhar-270519-1605-cnfortuna2019-05-27-155021.pdf', '', '', 'orhar-fxhWRXmZ-Regisjaminanpersediaandanpiutang_Conny_27Mei19.docx', NULL, 'Create jaminan untuk failitas KL. nilai jaminan persediaan Rp. 700,000,000.- nilai jaminan piutang Rp. 1,800,000,000.- no dan tgl pengikatan terlampir', '1558947912', '1', '1', '1', '1', 'David Ardian', 'Nurlaili Putri', 'Nike Elvira', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, '16:05', '', '', '', 0, 0),
(8, 'Christy Purnama', 'Update Jaminan', '28-5-2019', 'PT Gajah Tunggal Tbk', '50064054', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', 'orhar-270519-1629-ILS.docx', '', '', 'orhar-lYkgZNGY-Pemisahanjaminanpiutangdanpersediaan_Christy_28Mei19.docx', '', 'pemisahan jaminan persediaan dan piutang nomor jaminan 50064054 menjadi 2 nomor jaminan', NULL, '1', '1', '1', '1', 'Elza Widyasari', 'Nurlaili Putri', 'Nike Elvira', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, '16:29', '', '', '', 0, 0),
(9, 'Sonia Wibisono', 'Jaminan Baru', '28-5-2019', 'PT Air Semarang Barat', NULL, '205-901-031-4', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'orhar-280519-1044-revisicnairsemarang.zip', 'orhar-1559031335-SP+DaftarHakTagihAsuransi270519.pdf', 'orhar-1559031335-SP+DaftarHakTagihSuretyBond270519.pdf', 'orhar-280519-1336-CGMHAL.pdf', '', 'orhar-oZpu0jQh-regist4jaminan50824945,50825033,50825124,50825181.docx', NULL, 'registrasi jaminan sesuai terlampir\r\n\r\njaminan yang belum diikat:\r\n- Fidusia Hak Tagih Klaim Penjaminan PII >> rencana diikat akhir Juli\r\n- Piutang ke PDAM >> paling lambat 2 bulan setelah COD', '1559013336', '1', '1', '1', '1', 'Wilbert Karel Wetik', 'Fitri Dwi', 'Nurlaili Putri', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, '10:15', '', '', '', 0, 0),
(10, 'Carissa Kurniawan', 'Hapus Jaminan', '28-5-2019', 'PT Catur Sentosa Adiprana', '10387553', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'orhar-1559033651-MPK.pdf', '', '', '', '', 'orhar-Vv6aUVIN-caturhapusjaminan28052019.docx', NULL, 'agunan Kosambi Timur sudah tidak menjadi jaminan per tgl 24-05-2019', NULL, '1', '1', '1', '1', 'Dewi Virgina', 'Fitri Dwi', 'Nike Elvira', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, '10:54', '', '', '', 0, 0),
(11, 'Carissa Kurniawan', 'Hapus Jaminan', '28-5-2019', 'PT Catur Sentosa Adiprana', '13304555', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'orhar-1559033714-MPK.pdf', '', '', '', '', 'orhar-98KMKI2i-caturhapusjaminan28052019..docx', NULL, 'agunan Jatirangga sudah tidak menjadi jaminan per tgl 24.05.2019', NULL, '1', '1', '1', '1', 'Dewi Virgina', 'Fitri Dwi', 'Nike Elvira', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, '10:55', '', '', '', 0, 0),
(12, 'Carissa Kurniawan', 'Hapus Jaminan', '28-5-2019', 'PT Catur Mitra Sejati Sentosa', '40080996', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', 'orhar-88aG8FkN-hapusjaminanno.40080996.docx', NULL, 'agunan Pamulang Barat sudah tidak menjadi jaminan karena KI 7 sudah lunas ', NULL, '1', '1', '1', '1', 'Dewi Virgina', 'Fitri Dwi', 'Nike Elvira', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, '10:56', '', '', '', 0, 0),
(13, 'Merina Annisa Noviani', 'Jaminan Baru', '28-5-2019', 'PT Hiba Prima Sejahtera', NULL, '2059008875', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'orhar-1559034392-REVISIDAFTARKENDARAAN+SPBCAHPSKI4.15.pdf', '', '', '', '', 'orhar-wWGnNPDq-Regisjaminankendaraanhibaprima_Merina_28Mei19.docx', NULL, 'regis jaminan Kendaraan KI 4.15', '1559016392', '1', '1', '1', '1', 'Elza Widyasari', 'Nike Elvira', 'Nurlaili Putri', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, '11:06', '', '', '', 0, 0),
(14, 'Carissa Kurniawan', 'Update Jaminan', '28-5-2019', 'PT Catur Sentosa Adiprana', '49370992', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', 'orhar-1559035679-laporanappraisalCatur.pdf', '', '', 'orhar-U0q69A6C-updateappraisal,nojaminan49370992.docx', '', 'update nilai appraisal sesuai dengan laporan appraisal terlampir', NULL, '1', '1', '1', '1', 'Dewi Virgina', 'Fitri Dwi', 'Nike Elvira', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, '11:27', '', '', '', 0, 0),
(15, 'Kevin Keisha Pratama', 'Data Debitur', '10-6-2019', 'PT Oto Multiartha', NULL, '0359004364;0069000551', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', 'orhar-280519-1444-orhar-1559038090-NPWP_PTOTOMULTIARTHA(1).TIF', '', 'orhar-lq4O0GJz-UbahnpwpdebiturPTOTO_Kevin_11jun19.docx', NULL, 'Update Nomor NPWP Debitur (terlampir)', NULL, '1', '1', '1', '1', 'Elza Widyasari', 'Nurlaili Putri', 'Kurnia Amatilah', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, '12:08', '', '', '', 0, 0),
(16, 'Kevin Keisha Pratama', 'Update Jaminan', '28-5-2019', 'PT Oto Multiartha', '24776221', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'orhar-1559038568-MPK_13MEI2019_0492.pdf', '', 'orhar-1559038568-Addendum_AktaFidusia_16Okt2013_15.TIF', '', '', 'orhar-zIfpjyKF-UbahjaminandanpengkaitanOTO_Kevin_28Mei19.docx', 'Ubah keterangan jaminan menjadi \"90% dari plafon Kredit Multi dan PBMM 1; kaitkan dengan no rek 006.900.0551 kom 1; Ubah tgl BAP terakhir menjadi tgl 16-10-2013', 'Ubah keterangan jaminan menjadi \"90% dari plafon Kredit Multi dan PBMM 1; kaitkan dengan no rek 006.900.0551 kom 1; Ubah tgl BAP terakhir menjadi tgl 16-10-2013', NULL, '1', '1', '1', '1', 'Elza Widyasari', 'Nurlaili Putri', 'Nike Elvira', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, '12:16', '', '', '', 0, 0),
(17, 'Vinsensia Givy Gisela', 'Data Debitur', '28-5-2019', 'PT Dana Cipta Kreasi', NULL, '2189379379', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', 'orhar-0y4wHnMC-Regisdatadebiturpt.danacipta_Givy_28Mei19.docx', NULL, 'registrasi data debitur sesuai rekening 522 590 3155 (CIS 1004040)', NULL, '1', '1', '1', '1', 'Elza Widyasari', 'Nurlaili Putri', 'Kurnia Amatilah', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, '13:41', '', '', '', 0, 0),
(18, 'Yedidia Panca Onesimus', 'Hapus Jaminan', '28-5-2019', 'PT Putra Tanjung Pura', '1919015045 ; 1919015908', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', 'orhar-3eGzuP4D-Hapusjaminanpt.putratanjung_Ones_28Mei19.docx', NULL, 'hapus agunan pada nomor jaminan : \r\n30364053, 30364152, 3036568, 30365076, 30363998, 30364210, 30364228, 30364277, 30363980, 30364012, 30364020, 30364038, 30364046', NULL, '1', '1', '1', '1', 'Elza Widyasari', 'Nurlaili Putri', 'Nike Elvira', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, '14:34', '', '', '', 0, 0),
(19, 'Yedidia Panca Onesimus', 'Update Jaminan', '28-5-2019', 'PT Putra Tanjung Pura', '1919015045 ; 1919015908', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', 'orhar-zwQWsXQP-Pengkaitanjaminanpt.putratanjung_Ones_28Mei19.docx', 'register jaminan dengan keterangan \"tanpa agunan\" pada nomor komitmen 14, 15, 19, 20, 23, 3, 4, 6, 8, 10, 11, 12, 13', '', NULL, '1', '1', '1', '1', 'Elza Widyasari', 'Nurlaili Putri', 'Nike Elvira', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, '14:42', '', '', '', 0, 0),
(20, 'Yedidia Panca Onesimus', 'PemRek', '28-5-2019', 'PT Bank Woori Saudara Indonesia 1906 Tbk', NULL, NULL, '20143406', NULL, NULL, NULL, NULL, NULL, '-', 'None', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'orhar-1559048055-NPWPBWS.pdf', 'orhar-1559048055-RADPTBankWooriSaudara.docx', 'orhar-1559048055-0541-BANKWOORISAUDARAINDONESIA1906.pdf', 'orhar-1559048055-AAWooriBankKorea.pdf', 'orhar-1559048055-CopyIDArifinPanigoro.pdf', 'orhar-odd9UWwG-woorisaudaraindonesia.docx', NULL, 'register pembukaan rekening pinjaman baru, register data debitor, register pengurus, register data jaminan (tanpa agunan)', NULL, '1', '1', '1', '1', 'Elza Widyasari', 'Kurnia Amatilah', 'Fitri Dwi', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, '14:54', '', '', '', 0, 0),
(21, 'Vinsensia Givy Gisela', 'Data Debitur', '28-5-2019', 'PT Dana Cipta Kreasi', NULL, '218 937 9379', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', 'orhar-V24NEmBD-Regisdatadebiturpt.danacipta_Givy_28Mei19.docx', NULL, 'lengkapi data debitur sesuai nomor rekening 522 590 3155 (PT Dana Cipta Kreasi) ', NULL, '1', '1', '1', '1', 'Elza Widyasari', 'Nurlaili Putri', 'Kurnia Amatilah', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, '15:16', '', '', '', 0, 0),
(22, 'Leonhard Bianda', 'Data Debitur', '28-5-2019', 'PT Perkebunan Nusantara III', NULL, '2059007097', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'orhar-1559052603-RADPTPNIII.pdf', '', '', '', '', 'orhar-D5tSZYzu-UpdateRADpt.perkebunannusantaraIII.docx', NULL, 'update RAD sesuai terlampir', NULL, '1', '1', '1', '1', 'Mega Febrilia', 'Kurnia Amatilah', 'Nurlaili Putri', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, '16:10', '', '', '', 0, 0),
(23, 'Maria Gretalita Niken Winaputri', 'Update Jaminan', '29-5-2019', 'PT. Kabulinco Jaya', '31880420 ; 31880362', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'orhar-1559115166-MPKGrupKabulinco.pdf', '', 'orhar-1559115166-Appraisal2018-JembatanDua.tif', '', '', 'orhar-Lp0baDTA-Hapus&Gabungjaminanpt.kabulinco_Niken_29Mei19.docx', '9 Unit Ruko SHGB 1192, 10409, 8607, 8610, 5847, 9247, 10410, 5235/Pejagalan di Jl. Jembatan 2', '- Mohon penggabungan no. jaminan 31880362 ke no. jaminan 31880420\r\n- Hapus no. jaminan 31880362', NULL, '1', '1', '1', '1', 'David Ardian', 'Nurlaili Putri', 'Nike Elvira', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, '09:32', '', '', '', 0, 0),
(24, 'Maria Gretalita Niken Winaputri', 'Update Jaminan', '29-5-2019', 'PT. Agristar Grain Indonesia', '42303677', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'orhar-1559115574-MPKGrupKabulinco.pdf', '', 'orhar-1559115574-AJF_20_DES_2018_59.tif', 'orhar-290519-0941-AJF_27_AUG_2018_73.tif', '', 'orhar-kZK5b3Yf-Updatenilaipengikatandantglbappt.agristar_Niken_29Mei19.docx', '-', 'mohon update nilai pengikatan & tgl BAP piutang \r\n(nilai penjaminan : Rp 180.000.000.000 --> AJF No. 73 tgl 27/8/2018)\r\n(tgl AJF terakhir : no. 59 tgl 20/12/2018)', NULL, '1', '1', '1', '1', 'David Ardian', 'Nurlaili Putri', 'Nike Elvira', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, '09:39', '', '', '', 0, 0),
(25, 'Merina Annisa Noviani', 'Hapus Jaminan', '29-5-2019', 'PT Trans Kontainer Solusindo', '49987225', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', 'orhar-Egs2MQFw-Hapusjaminanpt.transkontainer_Merina_29Mei19.docx', NULL, 'Hapus Jaminan. BG sudah lunas', NULL, '1', '1', '1', '1', 'Elza Widyasari', 'Nike Elvira', 'Nurlaili Putri', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, '13:21', '', '', '', 0, 0),
(26, 'Merina Annisa Noviani', 'Hapus Jaminan', '29-5-2019', 'PT Manggala Kiat Ananda', '49987209', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', 'orhar-aMyCUpQw-manggalahapus4998720929052019.docx', NULL, 'Hapus Jaminan', NULL, '1', '1', '1', '1', 'Elza Widyasari', 'Nike Elvira', 'Nurlaili Putri', '', 'Bagus Risza Fahrodhi', NULL, '0', '0', '0', NULL, '13:28', '', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `msnonsmile`
--

CREATE TABLE `msnonsmile` (
  `uniqueid` int(255) NOT NULL,
  `id` varchar(255) NOT NULL,
  `tglbayar` varchar(255) NOT NULL,
  `tipebayar` varchar(255) NOT NULL,
  `angsuranqty` varchar(255) NOT NULL,
  `pikfrekuensi` varchar(255) NOT NULL,
  `angsuranidr` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `msnonsmile`
--

INSERT INTO `msnonsmile` (`uniqueid`, `id`, `tglbayar`, `tipebayar`, `angsuranqty`, `pikfrekuensi`, `angsuranidr`) VALUES
(1, '24', '21-03-2019', '0', '0', '1', '2'),
(2, '24', '--', '', '', '0', '0'),
(3, '24', '--', '', '', '0', '0'),
(4, '24', '--', '', '', '0', '0'),
(5, '24', '--', '', '', '0', '0'),
(6, '24', '--', '', '', '0', '0'),
(7, '24', '--', '', '', '0', '0'),
(8, '24', '--', '', '', '0', '0'),
(9, '24', '--', '', '', '0', '0'),
(10, '24', '--', '', '', '0', '0'),
(11, '24', '21-03-2019', '0', '2', '1', '0'),
(12, '24', '--', '', '', '0', '0'),
(13, '24', '--', '', '', '0', '0'),
(14, '24', '--', '', '', '0', '0'),
(15, '24', '--', '', '', '0', '0'),
(16, '24', '--', '', '', '0', '0'),
(17, '24', '--', '', '', '0', '0'),
(18, '24', '--', '', '', '0', '0'),
(19, '24', '--', '', '', '0', '0'),
(20, '24', '--', '', '', '0', '0');

-- --------------------------------------------------------

--
-- Struktur dari tabel `msprovisi`
--

CREATE TABLE `msprovisi` (
  `id` int(11) NOT NULL,
  `unionid` varchar(255) NOT NULL,
  `ils` varchar(255) NOT NULL,
  `fasilitas` varchar(255) NOT NULL,
  `komitmen` varchar(255) NOT NULL,
  `ibs` varchar(255) NOT NULL,
  `detail` varchar(255) NOT NULL,
  `tgldebet` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `msprovisi`
--

INSERT INTO `msprovisi` (`id`, `unionid`, `ils`, `fasilitas`, `komitmen`, `ibs`, `detail`, `tgldebet`) VALUES
(11, '48', '658-090-0168', 'KL', '001', '526-018-8030', 'IDR 18.750.000', '21-2-2019'),
(12, '48', '205-907-1372', 'TL', '004', '001-300-7176', 'USD 156,25', '21-2-2019'),
(13, '48', '', 'KI', '', '', '', '21-2-2019'),
(14, '48', '', 'KI', '', '', '', '21-2-2019'),
(15, '48', '', 'KI', '', '', '', '21-2-2019'),
(16, '48', '', 'KI', '', '', '', '21-2-2019'),
(17, '48', '', 'KI', '', '', '', '21-2-2019'),
(18, '48', '', 'KI', '', '', '', '21-2-2019'),
(19, '48', '', 'KI', '', '', '', '21-2-2019'),
(20, '48', '', 'KI', '', '', '', '21-2-2019'),
(21, '298', '205-900-9821', 'KI', '01', '088-775-0088', 'Provisi KI 3 (penyebutan di MPK KI 2) - yang di blok kuning saja', '28-2-2019'),
(22, '298', '', 'KI', '', '', '', '28-2-2019'),
(23, '298', '', 'KI', '', '', '', '28-2-2019'),
(24, '298', '', 'KI', '', '', '', '28-2-2019'),
(25, '298', '', 'KI', '', '', '', '28-2-2019'),
(26, '298', '', 'KI', '', '', '', '28-2-2019'),
(27, '298', '', 'KI', '', '', '', '28-2-2019'),
(28, '298', '', 'KI', '', '', '', '28-2-2019'),
(29, '298', '', 'KI', '', '', '', '28-2-2019'),
(30, '298', '', 'KI', '', '', '', '28-2-2019'),
(31, '299', '205-900-9812', 'KI', '01', '088-377-0088', 'KI 5 (Yang di blok kuning)', '28-2-2019'),
(32, '299', '', 'KI', '', '', '', '28-2-2019'),
(33, '299', '', 'KI', '', '', '', '28-2-2019'),
(34, '299', '', 'KI', '', '', '', '28-2-2019'),
(35, '299', '', 'KI', '', '', '', '28-2-2019');

-- --------------------------------------------------------

--
-- Struktur dari tabel `msreturn`
--

CREATE TABLE `msreturn` (
  `id` int(11) NOT NULL,
  `oldid` varchar(255) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `transdate` varchar(255) NOT NULL,
  `deadline` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `dokumen` varchar(255) DEFAULT NULL,
  `norek` varchar(255) DEFAULT NULL,
  `nojaminan` varchar(255) DEFAULT NULL,
  `nokomit` varchar(255) DEFAULT NULL,
  `kondisi` varchar(255) DEFAULT NULL,
  `nopolis` varchar(255) DEFAULT NULL,
  `periode` varchar(255) DEFAULT NULL,
  `polislama` varchar(255) DEFAULT NULL,
  `detail` varchar(1000) DEFAULT NULL,
  `detail2` varchar(1000) DEFAULT NULL,
  `keaslian` varchar(255) DEFAULT NULL,
  `flagkeaslian` varchar(255) DEFAULT '0',
  `alkhcname` varchar(255) NOT NULL,
  `pic1name` varchar(255) DEFAULT NULL,
  `pic2name` varchar(255) DEFAULT NULL,
  `pikhcname` varchar(255) DEFAULT NULL,
  `pikhcname2` varchar(255) DEFAULT NULL,
  `alkop` varchar(255) DEFAULT NULL,
  `alkhc` varchar(255) NOT NULL,
  `pikop` varchar(255) NOT NULL,
  `pikhc1` varchar(255) DEFAULT NULL,
  `pikhc2` varchar(255) DEFAULT NULL,
  `flagrejected` varchar(255) DEFAULT NULL,
  `flagrejectedpik` varchar(255) DEFAULT NULL,
  `flagpiktoalk` int(11) NOT NULL DEFAULT '0',
  `alkop2` varchar(255) DEFAULT NULL,
  `alkhc2` varchar(255) DEFAULT NULL,
  `pikop2` varchar(255) DEFAULT NULL,
  `pikhc12` varchar(255) DEFAULT NULL,
  `flagrejected2` varchar(255) DEFAULT NULL,
  `flagrejectedpik2` varchar(255) DEFAULT NULL,
  `flagpiktoalk2` varchar(255) DEFAULT NULL,
  `pikprogress` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `timestampprovisi` varchar(255) DEFAULT NULL,
  `typeextra` varchar(255) DEFAULT NULL,
  `pikmargin` varchar(255) DEFAULT NULL,
  `comreject` varchar(255) DEFAULT NULL,
  `waktu` varchar(255) DEFAULT NULL,
  `diserahkan` int(11) NOT NULL DEFAULT '0',
  `clusterhold` varchar(255) NOT NULL DEFAULT '0',
  `tgldiserahkan` varchar(255) DEFAULT NULL,
  `waktualk` varchar(255) DEFAULT NULL,
  `pikhc3` varchar(255) NOT NULL DEFAULT '0',
  `reminder` int(5) DEFAULT '0',
  `reminderdate` varchar(255) DEFAULT NULL,
  `lokasibg` varchar(255) DEFAULT NULL,
  `rekgiro` varchar(255) DEFAULT NULL,
  `adminis` varchar(255) DEFAULT NULL,
  `komisi` varchar(255) DEFAULT NULL,
  `bataswaktu` varchar(255) DEFAULT NULL,
  `jangkabg` varchar(255) DEFAULT NULL,
  `jenisjamin` varchar(255) DEFAULT NULL,
  `alamatpenerimajamin` varchar(255) DEFAULT NULL,
  `namapenerimajamin` varchar(255) DEFAULT NULL,
  `alamatjamin` varchar(255) DEFAULT NULL,
  `namajamin` varchar(255) DEFAULT NULL,
  `datereturn1` varchar(255) NOT NULL,
  `datereturn2` varchar(255) NOT NULL,
  `datereturn3` varchar(255) NOT NULL,
  `datereturn4` varchar(255) NOT NULL,
  `file` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `msreturn`
--

INSERT INTO `msreturn` (`id`, `oldid`, `username`, `transdate`, `deadline`, `company`, `dokumen`, `norek`, `nojaminan`, `nokomit`, `kondisi`, `nopolis`, `periode`, `polislama`, `detail`, `detail2`, `keaslian`, `flagkeaslian`, `alkhcname`, `pic1name`, `pic2name`, `pikhcname`, `pikhcname2`, `alkop`, `alkhc`, `pikop`, `pikhc1`, `pikhc2`, `flagrejected`, `flagrejectedpik`, `flagpiktoalk`, `alkop2`, `alkhc2`, `pikop2`, `pikhc12`, `flagrejected2`, `flagrejectedpik2`, `flagpiktoalk2`, `pikprogress`, `type`, `timestampprovisi`, `typeextra`, `pikmargin`, `comreject`, `waktu`, `diserahkan`, `clusterhold`, `tgldiserahkan`, `waktualk`, `pikhc3`, `reminder`, `reminderdate`, `lokasibg`, `rekgiro`, `adminis`, `komisi`, `bataswaktu`, `jangkabg`, `jenisjamin`, `alamatpenerimajamin`, `namapenerimajamin`, `alamatjamin`, `namajamin`, `datereturn1`, `datereturn2`, `datereturn3`, `datereturn4`, `file`) VALUES
(3, NULL, 'Sonia Wibisono', '11-2-2020', '11-2-2020', 'PT Mega Central Finance (MCF 2)', 'Lampiran 1 Daftar Obyek Fidusia', 'Agen Jaminan', '30001470', '', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Wilbert Karel Wetik', 'Keren Hapukh', 'Adi Fajar', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '09:52', 0, '0', NULL, '08:24', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(11, NULL, 'Vinsensia Givy Gisela', '28-2-2020', '10-3-2020', 'PT Surya Darma Perkasa', 'Addendum ke 3 PK', '0359005531', '', '', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Lidia', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '09:42', 0, '0', NULL, '09:28', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(20, NULL, 'U066563', '21-2-2020', '12-2-2020', 'PT. Daliatex Kusuma', 'Scan Asli Dokumen-Dokumen yg ada di keterangan', '0359302942', '-', '-', 'Return', NULL, NULL, NULL, 'Telah dikembalikan pada tanggal 18 Februari 2020', NULL, NULL, '0', 'Wilbert Karel Wetik', 'Adi Fajar', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '09:06', 0, '0', NULL, '18:25', '0', 0, NULL, 'Adi Fajar', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(28, NULL, 'Carissa Kurniawan', '19-2-2020', '21-2-2020', 'PT Catur Sentosa Adiprana', 'CD Daftar Persediaan Periode Desember 2019', '', '10387728; 15625742', '', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Dewi Virgina', 'Adi Fajar', 'Teguh Waspada', 'Iwati', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '14:44', 0, '0', NULL, '14:09', '0', 0, NULL, 'Adi Fajar', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(32, NULL, 'Nur Rahmah Hastiati', '27-2-2020', '28-2-2020', 'PT Andini Sarana', 'Surat Persetujuan Dewan Komisaris', '2059005884,6260904360', '0', '0', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Lidia', 'Adi Fajar', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '10:01', 0, '0', NULL, '10:00', '0', 0, NULL, 'Adi Fajar', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(36, NULL, 'Junista', '22-4-2020', '18-5-2020', 'PT Pancaran Darat Transport ', '1. SHM 9486 (dh.SHGB NO.6857/SUNTER AGUNG)', '- ', '12442802', 'semua ', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Lidia', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '12:27', 0, '0', NULL, '10:37', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(37, NULL, 'Junista', '22-4-2020', '18-5-2020', 'PT Pancaran Darat Transport ', 'SHM NO.2483/KAPUK MUARA', '- ', '12442737', 'semua ', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Elza Widyasari', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '11:20', 0, '0', NULL, '10:38', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(38, NULL, 'Junista', '22-4-2020', '18-5-2020', 'PT Pancaran Darat Transport ', 'SHM 2722/Kelapa Gading Timur', '- ', '38132874', 'semua ', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Elza Widyasari', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '11:20', 0, '0', NULL, '10:38', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(40, NULL, 'Junista', '22-4-2020', '18-5-2020', 'PT Pancaran Samudera Transport ', 'Grose akta kapal PANCARAN 110', '- ', '13921465', 'semua ', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Elza Widyasari', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '11:22', 0, '0', NULL, '10:38', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(41, NULL, 'Junista', '22-4-2020', '18-5-2020', 'PT Pancaran Samudera Transport ', 'Grose Akta kapal PST 110', '- ', '13921473', 'semua ', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Elza Widyasari', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '11:22', 0, '0', NULL, '10:39', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(42, NULL, 'Junista', '22-4-2020', '18-5-2020', 'PT Pancaran Samudera Transport ', 'Grose Akta kapal PST 210', '- ', '13921515', 'semua ', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Elza Widyasari', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '11:22', 0, '0', NULL, '10:39', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(43, NULL, 'Junista', '22-4-2020', '18-5-2020', 'PT Pancaran Samudera Transport ', 'Grose Akta kapal PANCARAN 210', '- ', '13921499', 'semua ', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Elza Widyasari', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '11:23', 0, '0', NULL, '10:40', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(44, NULL, 'Junista', '22-4-2020', '18-5-2020', 'PT Pancaran Samudera Transport ', 'Grose Akta kapal PST 112', '- ', '18458810', 'semua ', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Elza Widyasari', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '11:23', 0, '0', NULL, '10:40', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(45, NULL, 'Junista', '22-4-2020', '18-5-2020', 'PT Pancaran Samudera Transport ', 'Grose akta kapal PANCARAN 112', '- ', '18458760', 'semua ', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Elza Widyasari', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '11:23', 0, '0', NULL, '10:40', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(46, NULL, 'Junista', '22-4-2020', '18-5-2020', 'PT Pancaran Samudera Transport ', 'Grose Akta kapal PST 212', '- ', '18458869', 'semua ', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Elza Widyasari', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '11:23', 0, '0', NULL, '10:40', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(47, NULL, 'Junista', '22-4-2020', '18-5-2020', 'PT Pancaran Samudera Transport ', 'Grose Akta kapal PANCARAN 212', '- ', '18458844', 'semua ', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Elza Widyasari', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '11:23', 0, '0', NULL, '10:40', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(48, NULL, 'Junista', '22-4-2020', '18-5-2020', 'PT Pancaran Samudera Transport ', 'Grose Akta kapal PANCARAN 512', '- ', '20961751', 'semua ', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Elza Widyasari', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '11:23', 0, '0', NULL, '10:41', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(49, NULL, 'Junista', '22-4-2020', '18-5-2020', 'PT Pancaran Samudera Transport ', 'Grose Akta kapal PST 512', '- ', '20961819', 'semua ', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Elza Widyasari', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '11:24', 0, '0', NULL, '10:41', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(50, NULL, 'Junista', '22-4-2020', '18-5-2020', 'PT Pancaran Samudera Transport ', 'Grose Akta kapal PANCARAN 312', '- ', '21272851', 'semua ', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Elza Widyasari', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '11:24', 0, '0', NULL, '10:41', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(51, NULL, 'Junista', '22-4-2020', '18-5-2020', 'PT Pancaran Samudera Transport ', 'Grose Akta kapal PST 312', '- ', '21272877', '002', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Elza Widyasari', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '11:24', 0, '0', NULL, '10:41', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(52, NULL, 'Junista', '22-4-2020', '18-5-2020', 'PT Pancaran Samudera Transport ', 'Grose Akta kapal PANCARAN 612', '- ', '27906460', 'semua ', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Elza Widyasari', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '11:24', 0, '0', NULL, '10:42', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(53, NULL, 'Junista', '22-4-2020', '18-5-2020', 'PT Pancaran Samudera Transport ', 'Grose Akta kapal PST 712', '- ', '27906577', 'semua ', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Elza Widyasari', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '11:24', 0, '0', NULL, '10:42', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(54, NULL, 'Junista', '22-4-2020', '18-5-2020', 'PT Pancaran Samudera Transport ', 'Grose Akta kapal PANCARAN 712', '- ', '27906569', 'semua ', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Elza Widyasari', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '11:24', 0, '0', NULL, '10:43', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(55, NULL, 'Junista', '22-4-2020', '18-5-2020', 'PT Pancaran Samudera Transport ', 'Grose Akta kapal KALTIM FT 50-02', '- ', '49691934', 'semua ', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Elza Widyasari', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '11:25', 0, '0', NULL, '10:43', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, '', '19-2-2020', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL),
(56, NULL, 'Junista', '22-4-2020', '18-5-2020', 'PT Pancaran Samudera Transport ', 'Grose Akta kapal KALTIM 50-01', '- ', '49691850', 'semua ', 'Return', NULL, NULL, NULL, '', NULL, NULL, '0', 'Elza Widyasari', 'Teguh Waspada', 'Keren Hapukh', 'Gokmaria Hotnida', NULL, '1', '1', '1', '1', '1', '0', '0', 0, '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', 'Custom', NULL, NULL, NULL, NULL, '11:25', 0, '0', NULL, '10:43', '0', 0, NULL, 'Keren Hapukh', NULL, NULL, '', '19-2-2020', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `msscan`
--

CREATE TABLE `msscan` (
  `id` int(11) NOT NULL,
  `slkopid` int(11) DEFAULT NULL,
  `slkhcid` int(11) DEFAULT NULL,
  `pikopid` int(11) DEFAULT NULL,
  `pikop2id` int(11) DEFAULT NULL,
  `pikspvid` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `transdate` date DEFAULT NULL,
  `slkoptime` datetime DEFAULT NULL,
  `slkhctime` datetime DEFAULT NULL,
  `pikoptime` datetime DEFAULT NULL,
  `pikspvtime` datetime DEFAULT NULL,
  `receivetime` datetime DEFAULT NULL,
  `debitur` varchar(255) DEFAULT NULL,
  `dok` varchar(255) DEFAULT NULL,
  `dokdate` date DEFAULT NULL,
  `norek` varchar(255) DEFAULT NULL,
  `nodok` varchar(255) DEFAULT NULL,
  `nokom` varchar(255) DEFAULT NULL,
  `nojam` varchar(255) DEFAULT NULL,
  `slknote` varchar(1000) DEFAULT NULL,
  `hccom` varchar(1000) DEFAULT NULL,
  `opcom` varchar(1000) DEFAULT NULL,
  `spvcom` varchar(1000) DEFAULT NULL,
  `terimacom` varchar(1000) DEFAULT NULL,
  `file` varchar(1000) DEFAULT NULL,
  `filescan` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `msscan`
--

INSERT INTO `msscan` (`id`, `slkopid`, `slkhcid`, `pikopid`, `pikop2id`, `pikspvid`, `status`, `transdate`, `slkoptime`, `slkhctime`, `pikoptime`, `pikspvtime`, `receivetime`, `debitur`, `dok`, `dokdate`, `norek`, `nodok`, `nokom`, `nojam`, `slknote`, `hccom`, `opcom`, `spvcom`, `terimacom`, `file`, `filescan`) VALUES
(40, 6, 22, 104, 132, 155, 5, '2022-02-24', '2022-02-24 08:31:20', '2022-02-25 11:26:57', '2022-02-25 13:35:41', '2022-02-25 13:45:53', '2022-03-01 09:15:36', 'PT. Jogya Kulina Utama', 'SHM 453/Karangwaru', '1988-07-19', '2059009022  ', 'SHM 453/Karangwaru', '001', '16129892', 'Mohon scan ulang karena yang terdapat di e-dosir belum mencantumkan SHT Peringkat 3', NULL, NULL, NULL, NULL, '1645684280-CetakChecklistJogya.pdf', '1645788941-453.tif'),
(41, 6, 22, 132, 104, 155, 5, '2022-02-24', '2022-02-24 08:38:37', '2022-02-25 11:26:43', '2022-02-25 13:35:19', '2022-02-25 13:45:22', '2022-03-01 09:15:28', 'PT. Jogya Kulina Utama', 'Sertipikat', '1988-07-19', '2059009022', 'SHM 454/Karangwaru', '001', '16129892', 'Mohon scan karena belum terdapat di e-dosir', NULL, NULL, NULL, NULL, '1645684717-CetakChecklistJogya-.pdf', '1645788919-454.tif'),
(42, 118, 97, 132, 104, NULL, 0, '2022-02-25', '2022-02-25 13:55:24', NULL, NULL, NULL, NULL, 'PT Cibadak Indah Sari Farm', 'APHT (Akte Pemberian Hak Tanggungan)', '2016-11-02', '2059006171', '06/2016', 'semua komitmen', '37065620', 'APHT No 06/2016\r\nrequest scan', 'edit tgl terbit seharusnya 10/02/2016', NULL, NULL, NULL, '1645790124-cibadak.pdf', NULL),
(43, 118, 97, 104, 132, NULL, 0, '2022-02-25', '2022-02-25 14:19:55', '2022-02-25 16:01:23', NULL, NULL, NULL, 'PT Hiba Prima Sejahtera', 'Addendum / Perubahan Perjanjian Kredit ', '2021-08-16', '2059008875', '23', 'semua komitmen', '-', 'ADD PK ke 14 No. 23\r\n', NULL, 'Mohon bantuannya untuk mencantumkan alasan scan dokumen, terima kasih.', NULL, NULL, '1645791595-Hiba.pdf', NULL),
(44, 118, 97, 132, 104, NULL, 0, '2022-02-25', '2022-04-25 09:02:05', '2022-02-25 16:26:26', NULL, NULL, NULL, 'PT Cibadak Indah Sari Farm', 'APHT (Akte Pemberian Hak Tanggungan)', '2016-02-10', '2059006171', '06/2016', 'semua komitmen', '37065620', 'APHT No. 06/2016\r\norder scan ulang', '', 'Mohon bantuannya untuk mencantumkan alasan scan dokumen, terima kasih.', NULL, NULL, '1645799157-cibadak.pdf', NULL),
(45, 30, 0, 132, 104, NULL, 1, '2022-03-01', '2022-03-01 16:11:23', NULL, NULL, NULL, NULL, 'PT PUPUK SRIWIDJAJA PALEMBANG', 'SPPK', '2012-09-28', '2059003644', '20248/GBK/2012 ', '-', '-', 'Mohon bantuannya untuk scan dokumen asli sbb:\r\n1. SPPK No. 20248/GBK/2012 tgl 28-09-2012\r\n2. SPPK No. 20266/GBK/2012 tgl 16-10-2012', NULL, NULL, NULL, NULL, '', NULL),
(46, 15, 23, 132, 104, 155, 5, '2022-03-02', '2022-03-02 11:10:25', '2022-03-02 11:13:51', '2022-03-02 15:35:35', '2022-03-02 15:46:34', '2022-03-02 16:05:02', 'PT Primayudha Mandirijaya', 'Add PK ', '2014-12-02', '205-907-1399', '07', '', '', 'mohon bantuannya untuk scan add PK  (info SLK sebelumnya sudah direvisi namun belum di scan ulang pada saat return)', 'diperbaiki', NULL, NULL, NULL, '1646210695-CrystalViewer2.pdf', '1646228135-PKNO.7TGL02-12-2014(2).tif'),
(47, 15, 23, 132, 104, 155, 5, '2022-03-02', '2022-03-02 11:10:09', '2022-03-02 11:13:38', '2022-03-02 15:39:51', '2022-03-02 15:46:31', '2022-03-02 16:03:40', 'PT Primayudha Mandirijaya', 'Add PK', '2018-10-11', '', '33', '', '', 'mohon bantuannya untuk di scan (info SLK sebelumnya sudah direvisi namun belum di scan ulang pada saat return)', 'diperbaiki', NULL, NULL, NULL, '1646211346-CrystalViewer3.pdf', '1646228391-pkno33.tif'),
(48, 15, 23, 132, 104, 155, 5, '2022-03-02', '2022-03-02 11:15:14', '2022-03-02 11:17:20', '2022-03-02 15:40:19', '2022-03-02 15:43:17', '2022-03-02 16:01:36', 'PT Primayudha Mandirijaya', 'Add PK', '2019-10-10', '', '41', '', '', 'mohon bantuannya untuk di scan ulang (info PIC sebelumnya fisik asli terdapat revisi namun belum di upload ulang) ', NULL, NULL, NULL, NULL, '1646212514-CrystalViewer4.pdf', '1646228419-pkno41.tif'),
(49, 15, 23, 132, 104, 155, 5, '2022-03-02', '2022-03-02 11:20:27', '2022-03-02 11:24:59', '2022-03-02 15:40:43', '2022-03-02 15:42:45', '2022-03-02 16:00:14', 'PT Primayudha Mandirijaya', 'Add PK ', '2020-03-13', '', '08', '', '', 'mohon bantuannya untuk discan (info dari PIC SLK sebelumnya sudah terdapat revisi pada kondisi fisik asli namun tidak diminta untuk upload ulang pada saat return dokumen) ', NULL, NULL, NULL, NULL, '1646212827-CrystalViewer5.pdf', '1646228443-pkno08.tif'),
(50, 15, 23, 132, 104, 155, 5, '2022-03-02', '2022-03-02 11:27:33', '2022-03-02 13:08:19', '2022-03-02 13:56:37', '2022-03-02 13:57:38', '2022-03-02 14:35:16', 'PT Sri Rejeki Isman Tbk ', 'Add PK ', '2015-03-25', '-', '396', '', '', 'mohon bantuannya untuk scan ulang ( info PIC SLK sebelumnya sudah dilakukan revisi pada fisik asli namun belum di upload ulang pada saat return dokumen) ', NULL, NULL, NULL, NULL, '1646213253-CrystalViewer6.pdf', '1646222197-PERJANJIANKREDITNO396TGL25-03-2015.tif'),
(51, 108, 60, 104, 132, 155, 5, '2022-03-02', '2022-03-04 10:16:13', '2022-03-04 10:17:16', '2022-03-04 10:44:04', '2022-03-04 10:52:09', '2022-03-04 14:04:38', 'PT. Indah Kiat Pulp & Paper Tbk', 'DO dan daftar persediaan barang berikut surat pernyataan nya', '2013-12-05', '2059070198', '0083/IKPP-Banking/V/2013', '-', '10244424', 'mohon bantuannya utk scan dokumen terlampir sehubungan dengan adanya komen audit', NULL, 'Mohon bantuannya untuk melakukan revisi pada kolom tgl. terbit dokumen, terima kasih.', NULL, NULL, '1646229819-inkp.docx', '1646383444-DO0083INDAHKIAT.tif'),
(52, 51, 60, 104, 132, 155, 0, '2022-03-07', '2022-03-07 11:45:24', '2022-03-07 14:39:01', '2022-03-08 08:57:40', '2022-03-08 09:07:23', NULL, 'PT Bundamedik', 'Blue Print', '2022-03-07', '2059012414', '-', '000', '54850102 ', '- mohon bantuannya untuk scan blue print RSIA Bunda untuk perizinan dokumen Sertifikat Laik Fungsi ', 'lampirkan surat permohonan debitur', 'LAMPIRKAN CETAK CHECKLIST UNTUK INPUTAN IMB \nKeren Hapukh : Batal scan karena dokumen sudah diborrow oleh SLK untuk dilakukan pengecekkan (dibawa ke GI).', NULL, '', '1646646324-', '1646722661-IMB18(52).tif'),
(53, 131, 100, 104, 132, 155, 5, '2022-03-07', '2022-03-07 09:33:11', '2022-03-07 10:00:28', '2022-03-08 08:59:41', '2022-03-08 09:04:45', '2022-03-08 09:07:06', 'PT BUYUNG PUTRA PANGAN', 'AJF', '2016-12-08', '00459003918', '58', '001', '19631183', 'tidak ada di CAMS MANUAL', NULL, NULL, NULL, NULL, '1646638391-SCAN.PNG', '1646722781-AJF58(53).tif'),
(54, 233, 55, 104, 226, 155, 5, '2022-03-15', '2022-03-15 09:39:33', '2022-03-15 09:48:29', '2022-03-15 13:09:30', '2022-03-15 15:09:27', '2022-03-15 16:28:48', 'PT Agung Solusi Trans', 'B 786 AAM', '2022-03-15', '', 'B 786 AAM', '', 'Non Cams', 'Fotocopy BPKB sesuai surat terlampir. KI 4.1 no urut 5.', NULL, 'Mohon bantuannya untuk mencantumkan KI 4.1, karena debitur salah cantumkan KI (yg salah KI 4.4)', NULL, NULL, '1647267589-doc00351220220314143816.pdf', '1647342570-Doc0039.tif'),
(55, 48, 55, 104, 226, 155, 5, '2022-03-16', '2022-03-16 14:21:59', '2022-03-16 14:42:17', '2022-03-16 15:50:58', '2022-03-16 15:52:55', '2022-03-16 16:13:28', 'PT Istana Kebayoran Raya Motor', 'RUPS', '2022-03-16', '', 'IST/RUPSLB-PT.IKB/2015', '', '3305000', 'alasan : scan ulang untuk upload ke CAMS', NULL, NULL, NULL, NULL, '1647433319-IKRM.docx', '1647438658-Doc0253.tif'),
(56, 15, 23, 132, 104, 155, 5, '2022-03-18', '2022-03-17 15:42:12', '2022-03-17 15:51:25', '2022-03-18 08:51:36', '2022-03-18 10:17:53', '2022-03-18 13:14:14', 'PT Sari Warna Textile Indah Industry ', 'AJF ', '2011-08-09', '205-900-2699', '', '', '15370273', 'Mohon bantuannya untuk scan karena scan di e-dosir tidak lengkap ', NULL, NULL, NULL, NULL, '1647524532-CrystalViewer.pdf', '1647586296-SARIWARNATEXTILEORDERSCAN56.tif'),
(57, 47, 55, 104, 132, 155, 5, '2022-03-22', '2022-03-22 11:33:22', '2022-03-22 14:15:00', '2022-03-23 09:58:39', '2022-03-23 10:01:33', '2022-03-23 11:17:00', 'PT HRC Prima Sejahtera', 'BPKB', '2022-03-22', '2059007372', 'BPKB B 2088 PKV', '', 'non cams', 'scan BPKB KI 5.18 no urut 135 untuk pengurusan STNK', NULL, NULL, NULL, NULL, '1647941602-PermintaanSKLPT.HRCNo.087-BCA.pdf', '1648022319-Doc0040.tif'),
(58, 131, 100, 132, 104, NULL, 0, '2022-03-22', '2022-03-22 15:42:02', '2022-03-22 15:46:14', NULL, NULL, NULL, 'PT TRIKOMSEL OKE TBK', 'Surat pernyataan dari pemberi agunan ', '2011-04-15', '00359008785  ', '', '', '36948057', '', NULL, 'DOKUMEN SUDAH DITARIK DEBITUR HAPUS TAGIH', NULL, NULL, '1647956522-TRIKOMSEL.PNG', NULL),
(59, 47, 60, 104, 132, 155, 5, '2022-03-23', '2022-03-23 15:50:59', '2022-03-24 08:17:58', '2022-03-24 15:54:37', '2022-03-24 16:07:18', '2022-03-24 16:25:41', 'PT HRC Prima Sejahtera', 'BPKB ', '2022-03-23', '2059007372', 'BPKB B 2497 PKY', '', 'non cams', 'scan BPKB untuk pengurusan STNK KI 5.24 No urut 127', NULL, 'REJECT SESUAI REQ. SLK', NULL, NULL, '1648043459-', '1648130077-Doc0041.tif'),
(60, 131, 100, 132, 104, 155, 5, '2022-03-24', '2022-03-24 08:51:47', '2022-03-24 09:28:43', '2022-03-24 09:54:41', '2022-03-24 09:56:52', '2022-03-24 10:00:03', 'UNGGUL WIDYA TEKNOLOGI LEST PT', 'IMB', '2009-07-06', '00359094339  ', '640.641/042/IMB/VII/2009/B.PROG  	', '003', '36598514', 'tidak ada scan di e-dosir (komen PIC)', NULL, NULL, NULL, NULL, '1648104707-IMBUNGGULWIDYA.PNG', '1648108481-IMBUNGGULWIDYA.tif'),
(61, 108, 60, 104, 132, 101, 5, '2022-03-28', '2022-03-28 16:11:01', '2022-03-28 16:15:13', '2022-03-29 09:22:58', '2022-04-01 09:37:53', '2022-04-01 11:11:30', 'PT. Citra Maritime', 'surat pernyataan kesanggupan', '2021-09-24', '0619009527', '-', '-', '-', 'mohon bantuannya utk scan dokumen, karena belum ada di cams', NULL, 'Mohon bantuannya untuk mencantumkan alasan scan dokumen, terima kasih.', NULL, NULL, '1648455187-PERNYATAANKESANGGUPANPTCITRAMARITIME2140.pdf', '1648538578-BlackandWhite2592.tif'),
(62, 45, 0, 0, 0, NULL, 1, '2022-03-28', '2022-03-28 15:18:38', NULL, NULL, NULL, NULL, 'A', 'A', '2022-03-28', 'Terlampir', 'Terlampir', '001', '1', 'Hanya coba untuk pembuatan manual eOrhar', NULL, NULL, NULL, NULL, '', NULL),
(63, 33, 22, 104, 132, 101, 5, '2022-03-29', '2022-03-29 11:35:44', '2022-03-29 13:14:47', '2022-03-29 15:25:07', '2022-04-01 09:38:22', '2022-04-06 08:57:00', 'PT. TRIMITRA TRANS PERSADA', 'BPKB PADA DAFTAR KENDARAAN 018/TTP/FIN/XII/2021 TGL. 14-12-2021', '2022-03-29', '6890905577', 'BPKB NO.L-14003039', '-', '43511617', 'UNTUK PENGURUSAN STNK HILANG', NULL, NULL, NULL, NULL, '1648546544-ScanBPKBuntukurusSTNKHilangPT.TTP2022.pdf', '1648560307-BPKBTRIMITRA.tif'),
(65, 50, 60, 132, 104, 101, 5, '2022-03-31', '2022-03-31 14:09:29', '2022-03-31 15:00:11', '2022-04-01 10:35:30', '2022-04-01 16:04:40', '2022-04-06 13:53:20', 'PT Indobaruna Bulk Transport', 'RUPS', '2022-03-31', '2059005019', 'terlampir', '', '', 'komen audit tidak ditemukan e dosir RUPS di cams', NULL, 'Mohon bantuannya untuk mencantumkan alasan order scan dokumen tersebut, terima kasih.', NULL, NULL, '1648719432-Doc1.docx', '1648802130-Doc0259.zip');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mstarik`
--

CREATE TABLE `mstarik` (
  `id` int(5) NOT NULL,
  `username` varchar(255) NOT NULL,
  `transdate` varchar(255) NOT NULL,
  `dokumen` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `bataswaktu` varchar(255) NOT NULL,
  `norek` varchar(255) NOT NULL,
  `nojaminan` varchar(255) NOT NULL,
  `nokomit` varchar(255) NOT NULL,
  `nodok` varchar(255) NOT NULL,
  `detail` varchar(255) NOT NULL,
  `alkhcname` varchar(255) NOT NULL,
  `pic1name` varchar(255) NOT NULL,
  `pic2name` varchar(255) NOT NULL,
  `pikname` varchar(255) NOT NULL,
  `pikhcname` varchar(255) NOT NULL,
  `penerima` varchar(255) NOT NULL,
  `alkop` int(5) NOT NULL,
  `alkhc` int(5) NOT NULL,
  `pikop` int(5) NOT NULL,
  `pikhc` int(5) NOT NULL,
  `alkop2` int(5) NOT NULL,
  `alkhcdate` varchar(255) NOT NULL,
  `pikopdate` varchar(255) NOT NULL,
  `pikhcdate` varchar(255) NOT NULL,
  `alkop2date` varchar(255) NOT NULL,
  `flagrejected` int(5) NOT NULL,
  `comreject` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `notes` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `mstarik`
--

INSERT INTO `mstarik` (`id`, `username`, `transdate`, `dokumen`, `company`, `bataswaktu`, `norek`, `nojaminan`, `nokomit`, `nodok`, `detail`, `alkhcname`, `pic1name`, `pic2name`, `pikname`, `pikhcname`, `penerima`, `alkop`, `alkhc`, `pikop`, `pikhc`, `alkop2`, `alkhcdate`, `pikopdate`, `pikhcdate`, `alkop2date`, `flagrejected`, `comreject`, `file`, `notes`) VALUES
(8, 'Maria Olivia Widjaya', '10-2-2021', '(terlampir) ', 'PT Swakarsa Sinarsentosa', '10-2-2021', '0359006570', '49808140', '-', '(terlampir)', 'tarik seluruh dokumen pada no jaminan 49808140 : agunan telah dilepas sesuai memo GBK no. 20054/GBK/2020 tgl 05-03-2020', 'Nyimas Wida', 'Teguh Waspada', 'Olivia Santoso', 'Teguh Waspada', 'Ratna Irana M P', 'Maria Olivia Widjaya', 1, 1, 1, 1, 1, '10-02-2021 09:04', '10-02-2021 10:52', '10-02-2021 14:05', '11-02-2021 14:41', 0, '', '1612877165-tarikagunanBAS.zip', ''),
(9, 'Friskilla Clara Swita Abadi Taede', '10-2-2021', 'seluruh dokumen pada checklist terlampir', 'PT Pupuk Indonesia Logistik', '10-2-2021', '2059010586', '', '', '', 'penarikan seluruh dokumen sesuai checklist dosir asli dan harian terlampir karena sudah tidak menjadi debitur', 'Nyimas Wida', 'Olivia Santoso', 'Teguh Waspada', 'Teguh Waspada', 'Ratna Irana M P', 'Friskilla Clara Swita Abadi Taede', 1, 1, 1, 1, 1, '10-02-2021 11:36', '10-02-2021 14:21', '11-02-2021 13:53', '11-02-2021 14:24', 0, '', '1612947092-Pilog-ChecklistDosir.zip', ''),
(10, 'Aris Fredy', '15-2-2021', 'terlampir', 'PT Modern Widya Tehnical', '15-2-2021', '2309878994', '45161320 & 45161486', '0', 'terlampir', 'tarik seluruh jaminan fidusia kendaraan (45161320) dan Mesin (45161486) dikarenakan fasilitas KI 2 yang menjadi tanggungan jaminan sudah lunas', 'Dewi Virgina', 'Keren Hapukh', 'Olivia Santoso', 'Keren Hapukh', 'Ratna Irana M P', 'Aris Fredy', 1, 1, 1, 1, 1, '18-02-2021 08:14', '18-02-2021 08:28', '18-02-2021 14:48', '23-02-2021 10:59', 0, 'mohon tambahkan keterangan tarik untuk apa? ,by: Ratna Irana M P', '1613392254-image2021-02-15-142819.pdf', ''),
(11, 'Junista', '16-2-2021', '2 BPKB sesuai surat ', 'PT Blue Bird Pusaka ', '16-2-2021', '', 'Non CAMS', 'semua', '', 'Surat terlampir ', 'Lidia', 'Adi Fajar', 'Olivia Santoso', 'Adi Fajar', 'Ratna Irana M P', 'Junista', 1, 1, 1, 1, 1, '16-02-2021 17:14', '17-02-2021 10:04', '18-02-2021 14:19', '18-02-2021 14:53', 0, 'NAMA PT SEHARUSNYA PT BLUE BIRD PUSAKA ,by: Olivia Santoso', '1613484525-penarikanBBP16-02-2021.pdf', ''),
(12, 'Junista', '16-2-2021', 'Memo Penarikan BPKB ', 'PT Prima Sarijati Agung ', '16-2-2021', '', '', 'semua', '', 'sesuai checklist terlampir', 'Lidia', 'Adi Fajar', 'Olivia Santoso', 'Adi Fajar', 'Ratna Irana M P', 'Junista', 1, 1, 1, 1, 1, '16-02-2021 16:31', '17-02-2021 11:14', '18-02-2021 14:18', '18-02-2021 14:53', 0, '', '1613484588-penarikanmemopenukaranKi3.51.pdf', ''),
(13, 'Hanindha Putri Hardannie', '18-2-2021', 'terlampir', 'PT Swadharma Bhakti Sedaya Finance', '18-2-2021', '2059007429', '42441766, 44902922', '02', 'terlampir', 'Tarik dokumen jaminan no 42441766 dan 44902922 sesuai dengan highlight terlampir (pinjaman lunas)', 'Lidia', 'Olivia Santoso', 'Keren Hapukh', 'Keren Hapukh', 'Ratna Irana M P', 'Hanindha Putri Hardannie', 1, 1, 1, 1, 1, '18-02-2021 16:43', '19-02-2021 10:30', '22-02-2021 14:02', '22-02-2021 14:11', 0, 'DOKUMEN YANG DI ORDER TARIK KURANG ,by: Olivia Santoso', '1613631291-tarik.pdf', ''),
(14, 'Junista', '18-2-2021', 'BPKB KI 3.36 dan 3.37', 'PT Agung Solusi Trans', '18-2-2021', '', 'Non CAMS', 'semua', '', 'penarikan karena lunas', 'Lidia', 'Adi Fajar', 'Olivia Santoso', 'Adi Fajar', 'Ratna Irana M P', 'Junista', 1, 1, 1, 1, 1, '18-02-2021 11:36', '19-02-2021 10:46', '22-02-2021 13:20', '22-02-2021 13:47', 0, '', '1613639961-PenarikanDokumenLunasBPKBPTAgungSolusiTrans.msg', ''),
(15, 'Junista', '18-2-2021', 'BPKB ', 'PT Agung Solusi Trans', '18-2-2021', '', '', '', '', 'penarikan BPKB sesuai email', 'Lidia', 'Adi Fajar', 'Olivia Santoso', 'Adi Fajar', 'Ratna Irana M P', 'Junista', 1, 1, 1, 1, 1, '18-02-2021 16:43', '19-02-2021 10:46', '22-02-2021 13:21', '22-02-2021 13:48', 0, '', '1613651746-PenarikanBPKBPTAgungSolusiTrans.msg', ''),
(16, 'Merina Annisa Noviani', '19-2-2021', 'BPKB 14 unit', 'PT HRC Prima Sejahtera', '19-2-2021', '2059007372', 'non cams', '', 'sesuai lampiran', 'tarik BPKB 14 unit (sesuai lampiran) sesuai surat permohonan debitur', 'Elza Widyasari', 'Keren Hapukh', 'Olivia Santoso', 'Keren Hapukh', 'Ratna Irana M P', 'Merina Annisa Noviani', 1, 1, 1, 1, 1, '19-02-2021 15:37', '19-02-2021 15:56', '22-02-2021 13:30', '22-02-2021 14:30', 0, '', '1613740030-image2021-02-19-134401.pdf', ''),
(17, 'Nadila', '22-2-2021', 'IMB', 'PT SMART Tbk', '6-10-1997', '035-930-080-0', '14206973', '', '03/IMB/DPUK/1997', 'Tarik dokumen karena jaminan berupa kebun sehingga IMB tidak diperlukan.', 'Mega Febrilia', 'Teguh Waspada', 'Olivia Santoso', 'Teguh Waspada', 'Ratna Irana M P', 'Nadila', 1, 1, 1, 1, 1, '19-02-2021 16:40', '22-02-2021 10:17', '22-02-2021 13:54', '22-02-2021 14:13', 0, '', '1613745168-CrystalViewer(79)_Tarik.pdf', ''),
(18, 'Leonhard Bianda', '22-2-2021', 'Seluruh dokumen perkreditan', 'PT Greenfields Indonesia ', '22-2-2021', '2059008042', '', '1', '', 'tarik seluruh dokumen perkreditan debitur lunas PT Greenfields Indonesia \r\n(cetak checklist terlampir)', 'Mega Febrilia', 'Teguh Waspada', 'Olivia Santoso', 'Teguh Waspada', 'Ratna Irana M P', 'Leonhard Bianda', 1, 1, 1, 1, 1, '22-02-2021 08:33', '22-02-2021 15:50', '24-02-2021 15:03', '25-02-2021 09:01', 0, '', '1613747122-CrystalViewer(72).pdf', ''),
(19, 'Leonhard Bianda', '22-2-2021', 'Seluruh dokumen perkreditan', 'PT Greenfields Dairy Indonesia ', '22-2-2021', '2059008069', '', '', '', 'tarik seluruh dokumen debitur lunas PT Greenfields Dairy Indonesia \r\n(cetak checklist terlampir)', 'Mega Febrilia', 'Teguh Waspada', 'Olivia Santoso', 'Teguh Waspada', 'Ratna Irana M P', 'Leonhard Bianda', 1, 1, 1, 1, 1, '22-02-2021 08:33', '22-02-2021 15:50', '24-02-2021 14:35', '25-02-2021 09:01', 0, '', '1613747258-CrystalViewer(80).pdf', ''),
(21, 'Monika Istiana Dewi', '22-2-2021', 'Deposito, TTDBJ, DOG', 'PT AM/NS INDONESIA', '22-2-2021', '0359302845', '54366455 ; 54213467', '5', 'AJ 595154 ; AJ 595177', 'Penarikan deposito AJ 595177 dan AJ 595154 \r\nTTDBJ\r\nDOG \r\nsesuai terlampir.\r\nJatuh tempo forex', 'Dewi Virgina', 'Adi Fajar', 'Olivia Santoso', 'Olivia Santoso', 'Ratna Irana M P', 'Monika Istiana Dewi', 1, 1, 1, 1, 1, '22-02-2021 08:53', '22-02-2021 09:08', '22-02-2021 09:11', '22-02-2021 09:12', 0, '', '1613976238-cetakceklits.zip', ''),
(22, 'Putri Pramesti Tiarma', '22-2-2021', 'sesuai lampiran, kecuali gadai rekening (NJ50110378 )', 'PT. Prokemas Adhikari Kreasi', '22-2-2021', '2059007054', '-', '-', 'sesuai lampiran, kecuali gadai rekening (NJ50110378 )', 'tarik dokumen sesuai dengan lampiran, kecuali gadai rekening (NJ50110378 ) , debitur pelunasan fasilitas sebagian', 'Elza Widyasari', 'Teguh Waspada', 'Olivia Santoso', 'Teguh Waspada', 'Ratna Irana M P', 'Putri Pramesti Tiarma', 1, 1, 1, 1, 1, '22-02-2021 09:58', '23-02-2021 13:21', '24-02-2021 14:22', '25-02-2021 08:44', 0, '', '1613978440-image2021-02-22-082332.zip', ''),
(23, 'Bertha Elita Hia', '22-2-2021', 'Sesuai Checklist', 'PT. Inti Estrella', '22-2-2021', '2059010292', '-', 'Seluruh komitmen', 'Sesuai Checklist', 'Penarikan dokumen, sesuai checklis terlampir. Dokumen ditarik karena akan diserahkan ke notaris', 'Dewi Virgina', 'Keren Hapukh', 'Olivia Santoso', 'Keren Hapukh', 'Ratna Irana M P', 'Bertha Elita Hia', 1, 1, 1, 1, 1, '22-02-2021 17:10', '23-02-2021 08:58', '24-02-2021 13:29', '24-02-2021 17:22', 0, '', '1614004843-PTIntiEstrella-Tarik.pdf', ''),
(24, 'Leonhard Bianda', '24-2-2021', 'Surat Kolektif Saham dan Tanda Terima Jaminan', 'PT FAP AGRI', '24-2-2021', '2059011761', '42476648', '', '', 'tarik surat kolektif saham dan tanda terima jaminan sesuai cetak checklist terlampir. sudah ada surat kolektif saham terbaru', 'Mega Febrilia', 'Keren Hapukh', 'Olivia Santoso', 'Olivia Santoso', 'Ratna Irana M P', 'Leonhard Bianda', 1, 1, 1, 1, 1, '23-02-2021 13:45', '24-02-2021 08:34', '24-02-2021 09:04', '24-02-2021 09:25', 0, '', '1614079124-cetakchecklistsahamFAP2020.pdf', ''),
(26, 'Friskilla Clara Swita Abadi Taede', '26-2-2021', 'seluruh dokumen jaminan sesuai checklist terlampir', 'PT Petrokimia Gresik', '26-2-2021', '2059001161; 2059071402; 7900900176; 7900900168; 7900900508', '8664179; 10589034; 10589059', '', '', 'tarik seluruh dokumen jaminan karena sudah tidak ada jaminan atas fasilitas (negative pledge sudah berlaku)', 'Nyimas Wida', 'Teguh Waspada', 'Keren Hapukh', 'Keren Hapukh', 'Ratna Irana M P', 'Friskilla Clara Swita Abadi Taede', 1, 1, 1, 1, 1, '26-02-2021 11:41', '01-03-2021 13:57', '02-03-2021 10:59', '02-03-2021 18:51', 0, '', '1614331997-Petrogres-ChecklistDosirAsliJaminan.pdf', ''),
(27, 'Friskilla Clara Swita Abadi Taede', '26-2-2021', 'seluruh dokumen jaminan sesuai checklist terlampir', 'PT Pupuk Kujang', '26-2-2021', '2059002672', '', '', '', 'tarik seluruh dokumen jaminan karena fasilitas sudah tidak ada agunan (negative pledge sudah berlaku)', 'Nyimas Wida', 'Teguh Waspada', 'Keren Hapukh', 'Keren Hapukh', 'Ratna Irana M P', 'Friskilla Clara Swita Abadi Taede', 1, 1, 1, 1, 1, '26-02-2021 11:44', '01-03-2021 10:26', '03-03-2021 14:18', '12-03-2021 14:05', 0, '', '1614332174-PupukKujang-ChecklistDosirAsliJaminan.pdf', ''),
(28, 'Friskilla Clara Swita Abadi Taede', '26-2-2021', 'seluruh dokumen jaminan sesuai checklist terlampir', 'PT Pupuk Kalimantan Timur', '26-2-2021', '2059002389; 2059070708; 2179000614; 2179000193; 2179007007', '', '', '', 'tarik seluruh dokumen jaminan karena fasilitas sudah tidak ada agunan (negative pledge sudah berlaku)', 'Nyimas Wida', 'Teguh Waspada', 'Keren Hapukh', 'Keren Hapukh', 'Ratna Irana M P', 'Friskilla Clara Swita Abadi Taede', 1, 1, 1, 1, 1, '26-02-2021 13:27', '01-03-2021 10:27', '03-03-2021 14:19', '04-03-2021 15:24', 0, '', '1614333650-PupukKaltim-ChecklistDosirAsliJaminan.zip', ''),
(30, 'Friskilla Clara Swita Abadi Taede', '26-2-2021', 'seluruh dokumen jaminan pada nomor jaminan 26472282, 17133224', 'PT Pupuk Sriwidjaja', '26-2-2021', '2059003644; 0219009684', '26472282, 17133224', '', '', 'tarik seluruh dokumen jaminan pada nomor jaminan 26472282, 17133224 karena fasilitas KMK sudah tidak ada agunan (negative pledge sudah berlaku utk fasilitas KMK), nomor jaminan 17133224 di cetak checklist', 'Nyimas Wida', 'Teguh Waspada', 'Keren Hapukh', 'Keren Hapukh', 'Ratna Irana M P', 'Friskilla Clara Swita Abadi Taede', 1, 1, 1, 1, 1, '26-02-2021 16:07', '01-03-2021 10:27', '03-03-2021 14:19', '08-03-2021 15:23', 0, 'no jaminan kurang ,by: Teguh Waspada', '1614334614-Pusri-ChecklistDosirAsliJaminan.pdf', ''),
(31, 'Merina Annisa Noviani', '1-3-2021', 'BPKB 47 Unit (Terlampir)', 'PT Srikandi Multi Rental', '1-3-2021', '0359006961', 'non cams', '', 'sesuai lampiran', 'penarikan oleh Debitur', 'Elza Widyasari', 'Teguh Waspada', 'Keren Hapukh', 'Keren Hapukh', 'Ratna Irana M P', 'Merina Annisa Noviani', 1, 1, 1, 1, 1, '01-03-2021 11:33', '02-03-2021 10:23', '04-03-2021 14:32', '04-03-2021 15:03', 0, '', '1614587749-PermohonanTarikBPKB-47unit.zip', ''),
(34, 'Patricia Ariel Oleano', '2-3-2021', 'Perjanjian Kredit', 'PT. JASAMARGA PROBOLINGGO BANYUWANGI', '29-1-2019', '2059011493', '', '001', '01', 'dokumen akan dinonaktif karena fasilitas sudah dilunasi', 'Nyimas Wida', 'Keren Hapukh', 'Adi Fajar', 'Keren Hapukh', 'Ratna Irana M P', 'Patricia Ariel Oleano', 1, 1, 1, 1, 1, '01-03-2021 16:25', '02-03-2021 08:30', '04-03-2021 14:35', '04-03-2021 15:41', 0, '', '1614607837-CrystalViewer.pdf', ''),
(35, 'Patricia Ariel Oleano', '2-3-2021', 'SPPK', 'PT. JASAMARGA PROBOLINGGO BANYUWANGI', '28-1-2019', '2059011493', '', '001', '168/GCF/2019', 'dokumen akan dinonaktif karena fasilitas sudah dilunasi', 'Nyimas Wida', 'Keren Hapukh', 'Adi Fajar', 'Keren Hapukh', 'Ratna Irana M P', 'Patricia Ariel Oleano', 1, 1, 1, 1, 1, '01-03-2021 16:25', '02-03-2021 08:31', '04-03-2021 14:39', '04-03-2021 15:42', 0, '', '1614607974-Capture.PNG', ''),
(36, 'Leonhard Bianda', '2-3-2021', 'Bilyet Deposito + Tanda Terima Jaminan', 'PT Perkebunan Nusantara III', '1-3-2021', '', '', '', '', '- tarik dokumen bilyet deposito No. AK 151565\r\n- tanda terima jaminan No. 030/TTD/KCK/II/2021 tgl 16-02-2021\r\n(nomor jaminan 54380167)\r\n', 'Ona', 'Olivia Santoso', 'Teguh Waspada', 'Olivia Santoso', 'Ratna Irana M P', 'Leonhard Bianda', 1, 1, 1, 1, 1, '02-03-2021 15:15', '02-03-2021 15:20', '02-03-2021 15:22', '02-03-2021 15:23', 0, 'CETAK CHECKLIST TIDAK DITANDAI (HIGHLIGHT), DAFTAR OBJEK GADAI BELUM DITARIK ,by: Olivia Santoso', '1614610822-CrystalViewer(85).pdf', ''),
(38, 'Maria', '3-3-2021', 'Surat Order Notaris & Surat Roya', 'PT. Indah Jaya Textile Industry', '5-9-2019', '035-930-2390', '-', '01', 'Terlampir', 'Mohon tarik dokumen sbb :\r\n1. Surat Order : 4218/LKK/MBA/2017 tgl 05 September 2017\r\n2. Surat Roya : 4219/LKK/MBA/2017 tgl 05 September 2017\r\n\r\nKarena asli nya akan dinonaktif\r\n', 'Wilbert Karel Wetik', 'Olivia Santoso', 'Keren Hapukh', 'Keren Hapukh', 'Ratna Irana M P', 'Maria', 1, 1, 1, 1, 1, '03-03-2021 10:37', '03-03-2021 13:35', '03-03-2021 14:19', '03-03-2021 14:34', 0, '', '', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mstarikasuransi`
--

CREATE TABLE `mstarikasuransi` (
  `id` int(5) NOT NULL,
  `username` varchar(255) NOT NULL,
  `transdate` varchar(255) NOT NULL,
  `spvMonName` varchar(255) NOT NULL,
  `spvMonAcc` int(5) NOT NULL,
  `pikOpAsliName` varchar(200) NOT NULL,
  `pikOpAsliAcc` int(5) NOT NULL,
  `inputmon` int(5) NOT NULL,
  `inputmonName` varchar(255) NOT NULL,
  `spvPikAsliName` varchar(255) NOT NULL,
  `spvPikAsliAcc` int(5) NOT NULL,
  `opMonName` varchar(255) NOT NULL,
  `opMonAcc` int(5) NOT NULL,
  `commentreject` varchar(255) NOT NULL,
  `recordrejected` int(5) NOT NULL,
  `pikOpAsliName1` varchar(255) NOT NULL,
  `inputmonTime` varchar(255) NOT NULL,
  `spvMonAccTime` varchar(255) NOT NULL,
  `pikOpAsliAccTime` varchar(255) NOT NULL,
  `spvPikAsliAccTime` varchar(255) NOT NULL,
  `opMonAccTime` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `debiturName` varchar(255) NOT NULL,
  `kat1` varchar(255) NOT NULL,
  `namadok1` varchar(255) NOT NULL,
  `nomordok1` varchar(255) NOT NULL,
  `periodakhir1` varchar(255) NOT NULL,
  `ket1` varchar(255) NOT NULL,
  `file1` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `mstarikasuransi`
--

INSERT INTO `mstarikasuransi` (`id`, `username`, `transdate`, `spvMonName`, `spvMonAcc`, `pikOpAsliName`, `pikOpAsliAcc`, `inputmon`, `inputmonName`, `spvPikAsliName`, `spvPikAsliAcc`, `opMonName`, `opMonAcc`, `commentreject`, `recordrejected`, `pikOpAsliName1`, `inputmonTime`, `spvMonAccTime`, `pikOpAsliAccTime`, `spvPikAsliAccTime`, `opMonAccTime`, `type`, `debiturName`, `kat1`, `namadok1`, `nomordok1`, `periodakhir1`, `ket1`, `file1`) VALUES
(54, 'Ni Putu Emy Indrayani', '05-2-2021', 'Cicilia Prima Widi Astuti', 1, 'Olivia Santoso', 1, 1, 'Kania Nurbaiti', '', 3, 'Ni Putu Emy Indrayani', 3, '', 0, 'Keren Hapukh', '19-02-2021 15:52', '19-02-2021 16:39', '22-02-2021 10:06', '', '', 'Non Aktif', 'PT Jogya Kulina Utama ', 'Jaminan,Jaminan', 'Polis,Polis', '010101211900267,010101221900618', '4-Dec-20,4-Dec-20', 'Sudah diterima polis perpanjangan,Sudah diterima polis perpanjangan', 'POLIS_28 NOV 2019_010101211900267.tif,POLIS_09 DES 2019_010101221900618.tif'),
(55, 'Ni Putu Emy Indrayani', '08-2-2021', 'Cicilia Prima Widi Astuti', 1, 'Olivia Santoso', 1, 1, 'Kania Nurbaiti', '', 3, 'Ni Putu Emy Indrayani', 3, '', 0, 'Keren Hapukh', '19-02-2021 15:53', '19-02-2021 16:40', '22-02-2021 10:06', '', '', 'Non Aktif', 'PT Saranakulina Intisejahtera', 'Jaminan', 'Polis', '010101211900266', '20-12-2020', 'Sudah terima ppj', 'POLIS_28 NOV 2019_010101211900266.tif'),
(56, 'Ni Putu Emy Indrayani', '08-2-2021', 'Cicilia Prima Widi Astuti', 1, 'Olivia Santoso', 1, 1, 'Kania Nurbaiti', '', 3, 'Ni Putu Emy Indrayani', 3, '', 0, 'Keren Hapukh', '19-02-2021 15:53', '19-02-2021 16:40', '22-02-2021 10:06', '', '', 'Non Aktif', 'PT Kabulinco Jaya', 'Jaminan', 'Polis', '010101091900643', '02-12-2020', 'Sudah diterima ppj', 'POLIS_18 DES 2019_010101091900643.tif'),
(58, 'Ni Putu Emy Indrayani', '19-2-2021', 'Cicilia Prima Widi Astuti', 1, 'Olivia Santoso', 1, 1, 'Kania Nurbaiti', '', 3, 'Ni Putu Emy Indrayani', 3, '', 0, 'Keren Hapukh', '23-02-2021 16:03', '24-02-2021 08:35', '25-02-2021 11:14', '', '', 'Non Aktif', 'PT Indoguna Utama ', 'Jaminan', 'Polis', '010101212000003', '13-12-2020', 'Sudah diterima perpanjangan', ''),
(59, 'Ni Putu Emy Indrayani', '23-2-2021', 'Cicilia Prima Widi Astuti', 1, 'Olivia Santoso', 1, 1, 'Kania Nurbaiti', '', 3, 'Ni Putu Emy Indrayani', 3, '', 0, 'Keren Hapukh', '24-02-2021 09:10', '24-02-2021 14:01', '25-02-2021 11:14', '', '', 'Non Aktif', 'PT Lestari Agribisnis Indonesia', 'Jaminan|Jaminan|Jaminan|Jaminan|Jaminan|Jaminan|Jaminan|Jaminan', 'Polis|Polis|Polis|Polis|Polis|Polis|Polis|Polis', '010101091900623|010101221900621|010101091900622|010101221900623|010101091900619|010101221900624|010101091900620|010101221900626', '30-12-2020|30-12-2020|30-12-2020|30-12-2020|30-12-2020|30-12-2020|30-12-2020|30-12-2020', 'Sudah terima Soft Copy perpanjangan  dari BCAI|Sudah terima Soft Copy perpanjangan  dari BCAI|Sudah terima Soft Copy perpanjangan  dari BCAI|Sudah terima Soft Copy perpanjangan  dari BCAI|Sudah terima Soft Copy perpanjangan  dari BCAI|Sudah terima Soft Co', '|||||||'),
(60, 'Florence', '02-3-2021', 'Cicilia Prima Widi Astuti', 1, 'Olivia Santoso', 1, 1, 'Kania Nurbaiti', '', 3, 'Florence', 3, '', 0, 'Teguh Waspada', '02-03-2021 13:23', '02-03-2021 15:55', '04-03-2021 15:06', '', '', 'Non Aktif', 'PT Srikandi Multi Rental', 'Jaminan', 'Polis', '042009647451', '01-03-2021', 'Voucher SLK tgl. 02/02/2021', '10022021 - PT SRIKANDI MULTI RENTAL - ALK.tif.jpg'),
(61, 'Florence', '03-3-2021', 'Cicilia Prima Widi Astuti', 1, 'Olivia Santoso', 1, 1, 'Kania Nurbaiti', 'Ratna Irana M P', 1, 'Florence', 1, '', 0, 'Teguh Waspada', '03-03-2021 10:24', '03-03-2021 18:21', '04-03-2021 15:06', '08-03-2021 13:54', '08-03-2021 15:58', 'Kembali ke Monitoring', 'PT Srikandi Multi Rental', 'Jaminan|Jaminan|Jaminan', 'Polis|Polis|Polis', '042009622058|042009936300|042009847833', '6-Mar-21|28-Jul-21|25-Jul-21', '||', '||'),
(63, 'Florence', '05-3-2021', 'Cicilia Prima Widi Astuti', 1, 'Olivia Santoso', 1, 1, 'Kania Nurbaiti', '', 3, 'Florence', 3, '', 0, 'Adi Fajar', '05-03-2021 14:53', '05-03-2021 14:55', '15-03-2021 09:39', '', '', 'Non Aktif', 'PT Agung Solusi Trans', 'Jaminan', 'Polis', '012000070155', '03-01-2021', 'Sudah terima polis ppj', ''),
(64, 'Ni Putu Emy Indrayani', '05-3-2021', 'Cicilia Prima Widi Astuti', 1, 'Olivia Santoso', 1, 1, 'Martanita Dika Puspita', '', 3, 'Ni Putu Emy Indrayani', 3, '', 0, 'Keren Hapukh', '05-03-2021 17:06', '08-03-2021 11:02', '10-03-2021 08:45', '', '', 'Non Aktif', 'PT Mitra Kreasidharma ', 'Jaminan|Jaminan', 'Polis|Polis', '100010320020000343|100010620020000255', '08-07-2020|08-07-2020', 'Nilai asuransi atas persediaan sudah cover, polis nomor 110010320080000661|Nilai asuransi atas persediaan sudah cover, polis nomor 100010620020000255', '|'),
(65, 'Ni Putu Emy Indrayani', '09-3-2021', 'Cicilia Prima Widi Astuti', 1, 'Olivia Santoso', 1, 1, 'Martanita Dika Puspita', '', 3, 'Ni Putu Emy Indrayani', 3, '', 0, 'Keren Hapukh', '16-03-2021 08:52', '16-03-2021 13:28', '16-03-2021 15:34', '', '', 'Non Aktif', 'PT Makassar Kulina Utama (Grup Indoguna)', 'Jaminan', 'Polis', '010101211900263', '18-11-2020', 'Sudah terima polis perpanjangan ', ''),
(66, 'Florence', '16-3-2021', 'Cicilia Prima Widi Astuti', 1, 'Olivia Santoso', 1, 1, 'Kania Nurbaiti', '', 3, 'Florence', 3, '', 0, 'Adi Fajar', '16-03-2021 14:16', '16-03-2021 14:20', '17-03-2021 11:07', '', '', 'Non Aktif', 'PT Agung Solusi Trans', 'Jaminan|Jaminan', 'Polis|Polis', '042009551039	|042009551037', '06-02-2021|06-02-2021', '|', '|'),
(68, 'Ni Putu Emy Indrayani', '23-3-2021', 'Ona', 1, 'Olivia Santoso', 1, 1, 'Martanita Dika Puspita', 'Ratna Irana M P', 1, 'Ni Putu Emy Indrayani', 1, '', 0, 'Keren Hapukh', '26-03-2021 09:07', '26-03-2021 11:17', '29-03-2021 09:30', '30-03-2021 09:02', '01-04-2021 14:43', 'Kembali ke Monitoring', 'PT Kahatex', 'Jaminan|Jaminan|Jaminan|Jaminan|Jaminan|Jaminan|Jaminan|Jaminan|Jaminan', 'Polis|Polis|Polis|Polis|Polis|Polis|Polis|Polis|Polis', '12.000.0001.75699|12.000.0001.75685|12.000.0001.75583|12.000.0001.75713|12.000.0001.75596|12.000.0001.75690|12.000.0001.75613|12.000.0001.75618|12.000.0001.75727', '30-09-2021|30-09-2021|30-09-2021|30-09-2021|30-09-2021|30-09-2021|30-09-2021|30-09-2021|30-09-2021', 'Polis dibatalkan |Polis dibatalkan |Polis dibatalkan |Polis dibatalkan |Polis dibatalkan |Polis dibatalkan |Polis dibatalkan |Polis dibatalkan |Polis dibatalkan ', ''),
(69, 'Ni Putu Emy Indrayani', '23-3-2021', 'Ona', 1, 'Olivia Santoso', 1, 1, 'Martanita Dika Puspita', '', 3, 'Ni Putu Emy Indrayani', 3, '', 0, 'Keren Hapukh', '26-03-2021 09:09', '26-03-2021 11:18', '29-03-2021 10:25', '', '', 'Non Aktif', 'PT Karangjuang Hijau Lestari', 'Jaminan|Jaminan', 'Polis|Polis', '0124011901482|0124011901483', '31-10-2020|31-10-2020', 'Sudah terima polis perpanjangan|Sudah terima polis perpanjangan', ''),
(70, 'Ni Putu Emy Indrayani', '26-3-2021', 'Ona', 1, 'Olivia Santoso', 1, 1, 'Martanita Dika Puspita', '', 3, 'Ni Putu Emy Indrayani', 3, '', 0, 'Teguh Waspada', '26-03-2021 14:56', '29-03-2021 15:51', '05-04-2021 15:49', '', '', 'Non Aktif', 'PT Sari Warna Asli Textile', 'Jaminan', 'Polis', '410.297.300.20.00035/000/000', '31-12-2020', 'Sudah terima polis perpanjangan', ''),
(71, 'Ni Putu Emy Indrayani', '05-4-2021', 'Cicilia Prima Widi Astuti', 1, 'Olivia Santoso', 1, 1, 'Martanita Dika Puspita', '', 3, 'Ni Putu Emy Indrayani', 3, '', 0, 'Keren Hapukh', '06-04-2021 13:16', '07-04-2021 09:19', '19-04-2021 15:30', '', '', 'Non Aktif', 'PT Jogya Kulina Utama (Grup Indoguna)', 'Jaminan|Jaminan', 'Polis|Polis', '010101212000137|010101222000304', '12-03-2021|12-03-2021', 'Sudah terima perpanjangan|Sudah terima perpanjangan', ''),
(72, 'Ni Putu Emy Indrayani', '08-4-2021', 'Cicilia Prima Widi Astuti', 1, 'Olivia Santoso', 1, 1, 'Martanita Dika Puspita', '', 3, 'Ni Putu Emy Indrayani', 3, '', 0, 'Teguh Waspada', '08-04-2021 15:58', '09-04-2021 13:16', '12-04-2021 14:56', '', '', 'Non Aktif', 'PT Perkebunan Nusantara V ', 'Jaminan', 'Polis', 'IP090119000145', '27-08-2020', 'Non aktif karena sudah ada perpanjangan', ''),
(73, 'Ni Putu Emy Indrayani', '09-4-2021', 'Cicilia Prima Widi Astuti', 1, 'Olivia Santoso', 1, 1, 'Martanita Dika Puspita', '', 3, 'Ni Putu Emy Indrayani', 3, '', 0, 'Keren Hapukh', '09-04-2021 14:29', '14-04-2021 13:25', '19-04-2021 15:30', '', '', 'Non Aktif', 'PT Karangjuang Hijau Lestari', 'Jaminan|Jaminan', 'Polis|Polis', '0124011901350|0124011901351', '31-10-2020|31-10-2020', 'Sudah terima perpanjangan|Sudah terima perpanjangan', ''),
(74, 'Ni Putu Emy Indrayani', '15-4-2021', 'Cicilia Prima Widi Astuti', 1, 'Olivia Santoso', 1, 1, 'Martanita Dika Puspita', '', 3, 'Ni Putu Emy Indrayani', 3, 'salah tulis no.polis , by: Cicilia Prima Widi Astuti', 1, 'Adi Fajar', '15-04-2021 14:54', '15-04-2021 15:01', '22-04-2021 09:39', '', '', 'Non Aktif', 'PT Aetra Air Tangerang', 'Jaminan', 'Polis', '100010319120003563', '31-12-2020', 'Sudah terima polis ppj', ''),
(75, 'Ni Putu Emy Indrayani', '15-4-2021', 'Cicilia Prima Widi Astuti', 1, 'Olivia Santoso', 1, 1, 'Martanita Dika Puspita', 'Ratna Irana M P', 1, 'Ni Putu Emy Indrayani', 1, '', 0, 'Teguh Waspada', '15-04-2021 13:24', '15-04-2021 14:39', '16-04-2021 14:31', '19-04-2021 14:21', '19-04-2021 14:24', 'Kembali ke Monitoring', 'PT Panca Budi Pratama', 'Jaminan', 'Polis', 'CL0101162000227', '26-11-2021', 'Asuransi ditarik, karena terdapat memo penurunan nilai persediaan', ''),
(76, 'Florence', '15-4-2021', 'Cicilia Prima Widi Astuti', 1, 'Adi Fajar', 0, 1, 'Kania Nurbaiti', '', 0, 'Florence', 0, '', 0, 'Adi Fajar', '15-04-2021 16:37', '15-04-2021 17:01', '', '', '', 'Non Aktif', 'PT Blue Bird Tbk', 'Jaminan', 'Polis', 'S090220000118 (KI 3.8)', '01-08-2020', 'Order tarik dari SLK via email tgl. 07/04/2021', ''),
(77, 'Florence', '15-4-2021', 'Cicilia Prima Widi Astuti', 1, 'Adi Fajar', 0, 1, 'Kania Nurbaiti', '', 0, 'Florence', 0, '', 0, 'Adi Fajar', '15-04-2021 16:38', '15-04-2021 17:04', '', '', '', 'Non Aktif', 'PT Central Naga Europindo ', 'Jaminan|Jaminan|Jaminan', 'Polis|Polis|Polis', 'S090220000148 (KI 3.30)|S090218000377 (KI 3.32)|S090220000148 (KI 3.10)', '01-08-2020|01-05-2020|01-08-2020', 'Order non-aktif SLK via email tgl. 07/04/2021|Order non-aktif SLK via email tgl. 07/04/2021|Order non-aktif SLK via email tgl. 07/04/2021', ''),
(78, 'Florence', '15-4-2021', 'Cicilia Prima Widi Astuti', 1, 'Adi Fajar', 0, 1, 'Kania Nurbaiti', '', 0, 'Florence', 0, '', 0, 'Adi Fajar', '15-04-2021 16:38', '15-04-2021 17:05', '', '', '', 'Non Aktif', 'PT Morante Jaya', 'Jaminan', 'Polis', 'S090218000507 (KI 3.22)', '01-05-2020', 'Order non-aktif SLK via email tgl. 07/04/2021', ''),
(79, 'Florence', '15-4-2021', 'Cicilia Prima Widi Astuti', 1, 'Adi Fajar', 0, 1, 'Kania Nurbaiti', '', 0, 'Florence', 0, '', 0, 'Adi Fajar', '15-04-2021 16:38', '15-04-2021 17:05', '', '', '', 'Non Aktif', 'PT Pusaka Nuri Utama', 'Jaminan', 'Polis', 'S090218000427 (KI 3.25)', '01-05-2020', 'Order Non-aktif SLK tgl. 07/04/2021', ''),
(80, 'Ni Putu Emy Indrayani', '23-4-2021', 'Cicilia Prima Widi Astuti', 1, 'Olivia Santoso', 1, 1, 'Martanita Dika Puspita', '', 3, 'Ni Putu Emy Indrayani', 3, '', 0, 'Keren Hapukh', '26-04-2021 10:17', '27-04-2021 16:40', '29-04-2021 08:51', '', '', 'Non Aktif', 'PT Lestari Agribisnis Indonesia', 'Jaminan|Jaminan', 'Polis|Polis', '010101212000031|010101222000139', '08-03-2021|08-03-2021', '|', ''),
(81, 'Ni Putu Emy Indrayani', '27-4-2021', 'Cicilia Prima Widi Astuti', 1, 'Teguh Waspada', 0, 1, 'Kania Nurbaiti', '', 0, 'Ni Putu Emy Indrayani', 0, '', 0, 'Teguh Waspada', '24-05-2021 13:57', '24-05-2021 14:04', '', '', '', 'Non Aktif', 'Singa Propertindo Haryono', 'Jaminan', 'Polis', '17 ZI-CAR-2390084', '08-Mar-2021', 'sudah terima polis PAR', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mstrans`
--

CREATE TABLE `mstrans` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `transdate` varchar(255) NOT NULL,
  `deadline` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `idr` varchar(255) NOT NULL DEFAULT '0',
  `rtgs` int(11) NOT NULL DEFAULT '0',
  `ors` int(11) NOT NULL,
  `tipevalas` varchar(255) NOT NULL,
  `valas` varchar(255) NOT NULL,
  `pelpem` varchar(255) NOT NULL,
  `ils` varchar(255) NOT NULL,
  `komitmen` varchar(255) NOT NULL,
  `pinjaman` varchar(255) NOT NULL,
  `realisasi` varchar(255) NOT NULL,
  `autodebet` varchar(255) NOT NULL,
  `bunga` varchar(255) NOT NULL,
  `idx` varchar(255) NOT NULL,
  `frekuensi` varchar(255) NOT NULL,
  `fasilitas` varchar(255) NOT NULL,
  `syarat` varchar(255) NOT NULL,
  `syaratqty` varchar(255) NOT NULL,
  `sandidati2` varchar(255) NOT NULL,
  `detail` varchar(2000) NOT NULL,
  `detailpik` varchar(1000) NOT NULL,
  `file` varchar(255) NOT NULL,
  `filepik` varchar(255) NOT NULL,
  `keaslian` varchar(255) NOT NULL,
  `flagkeaslian` varchar(255) NOT NULL DEFAULT '0',
  `keaslianaprvdname` varchar(100) DEFAULT NULL,
  `keaslianaprvdtime` varchar(100) DEFAULT NULL,
  `alkhcname` varchar(255) NOT NULL,
  `pic1name` varchar(255) NOT NULL,
  `pic2name` varchar(255) NOT NULL,
  `pikname` varchar(255) NOT NULL,
  `pikhcname` varchar(255) NOT NULL,
  `pikhcname2` varchar(255) NOT NULL,
  `alkop` varchar(255) NOT NULL,
  `alkhc` varchar(255) NOT NULL,
  `pikop` varchar(255) NOT NULL,
  `pikhc1` varchar(255) NOT NULL,
  `pikhc2` varchar(255) NOT NULL,
  `flagrejected` varchar(255) NOT NULL,
  `flagrejectedpik` varchar(255) NOT NULL,
  `flagpiktoalk` int(11) NOT NULL DEFAULT '0',
  `pikprogress` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `timestampprovisi` varchar(255) NOT NULL,
  `typeextra` varchar(255) NOT NULL,
  `pikmargin` varchar(255) NOT NULL,
  `pikjenispinjaman` varchar(255) NOT NULL,
  `pikusercode` varchar(255) NOT NULL,
  `piknomorpinjaman` varchar(255) NOT NULL,
  `pikkategoripinjaman` varchar(255) NOT NULL,
  `pikautodebet` varchar(255) NOT NULL,
  `pikdebetgiro` varchar(255) NOT NULL,
  `piktipepokok` varchar(255) NOT NULL,
  `pikmatauang` varchar(255) NOT NULL,
  `pikkodecabang` varchar(255) NOT NULL,
  `piksaldoawal` varchar(255) NOT NULL,
  `pikbasis` varchar(255) NOT NULL,
  `pikplusminus` varchar(255) NOT NULL,
  `pikfrekuensi` varchar(255) NOT NULL,
  `comreject` varchar(1000) NOT NULL,
  `waktu` varchar(255) DEFAULT NULL,
  `diserahkan` int(11) NOT NULL DEFAULT '0',
  `clusterhold` varchar(255) NOT NULL DEFAULT '-',
  `tgldiserahkan` varchar(255) DEFAULT NULL,
  `waktualk` varchar(255) DEFAULT NULL,
  `pikhc3` varchar(255) DEFAULT '0',
  `reminder` int(5) NOT NULL DEFAULT '0',
  `lokasibg` varchar(255) DEFAULT NULL,
  `reminderdate` varchar(255) DEFAULT NULL,
  `rekgiro` varchar(255) DEFAULT NULL,
  `adminis` varchar(255) DEFAULT NULL,
  `komisi` varchar(255) DEFAULT NULL,
  `bataswaktu` varchar(255) DEFAULT NULL,
  `jangkabg` varchar(255) DEFAULT NULL,
  `jenisjamin` varchar(255) DEFAULT NULL,
  `alamatpenerimajamin` varchar(255) DEFAULT NULL,
  `namapenerimajamin` varchar(255) DEFAULT NULL,
  `alamatjamin` varchar(255) DEFAULT NULL,
  `namajamin` varchar(255) DEFAULT NULL,
  `changedate` varchar(255) NOT NULL,
  `waktuHC` varchar(255) NOT NULL,
  `waktuPIKO` varchar(255) NOT NULL,
  `waktuPIKHC` varchar(255) NOT NULL,
  `flagCancelling` varchar(255) NOT NULL,
  `flagCancellingDiserahkan` varchar(255) NOT NULL,
  `tgldiaslikan` varchar(255) NOT NULL,
  `urgent` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `mstrans`
--

INSERT INTO `mstrans` (`id`, `username`, `transdate`, `deadline`, `company`, `idr`, `rtgs`, `ors`, `tipevalas`, `valas`, `pelpem`, `ils`, `komitmen`, `pinjaman`, `realisasi`, `autodebet`, `bunga`, `idx`, `frekuensi`, `fasilitas`, `syarat`, `syaratqty`, `sandidati2`, `detail`, `detailpik`, `file`, `filepik`, `keaslian`, `flagkeaslian`, `keaslianaprvdname`, `keaslianaprvdtime`, `alkhcname`, `pic1name`, `pic2name`, `pikname`, `pikhcname`, `pikhcname2`, `alkop`, `alkhc`, `pikop`, `pikhc1`, `pikhc2`, `flagrejected`, `flagrejectedpik`, `flagpiktoalk`, `pikprogress`, `type`, `timestampprovisi`, `typeextra`, `pikmargin`, `pikjenispinjaman`, `pikusercode`, `piknomorpinjaman`, `pikkategoripinjaman`, `pikautodebet`, `pikdebetgiro`, `piktipepokok`, `pikmatauang`, `pikkodecabang`, `piksaldoawal`, `pikbasis`, `pikplusminus`, `pikfrekuensi`, `comreject`, `waktu`, `diserahkan`, `clusterhold`, `tgldiserahkan`, `waktualk`, `pikhc3`, `reminder`, `lokasibg`, `reminderdate`, `rekgiro`, `adminis`, `komisi`, `bataswaktu`, `jangkabg`, `jenisjamin`, `alamatpenerimajamin`, `namapenerimajamin`, `alamatjamin`, `namajamin`, `changedate`, `waktuHC`, `waktuPIKO`, `waktuPIKHC`, `flagCancelling`, `flagCancellingDiserahkan`, `tgldiaslikan`, `urgent`) VALUES
(10999, 'Kevin Keisha Pratama', '28-6-2019', '1-7-2019', 'PT Nusa Surya Ciptadana', '50000000000', 0, 0, 'None', '0', '', '2059001293', '003', '-', '', '0093045430', '', '-', '', '', '', '', '', 'Signature Checked!\r\n            ', '', '1561642669-KonfirmasiPBMM240619.zip', '1561703698-NUSA.docx', 'asli', '0', NULL, NULL, 'Elza Widyasari', 'Dominggus Richardod', 'Christine', '', 'Endah Nurnendah', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', 'Custom', '', 'Rollover PBMM', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '17:01', 1, '-', '05-07', '15:37', '1', 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11000, 'Merina Annisa Noviani', '27-6-2019', '31-3-2020', 'PT Mitsubishi Motors Krama Yudha Sales Indonesia', '0', 0, 0, 'None', '80000000', '', '0659700001', '1', '', '', '', '', '', '', '', '', '', '', 'perpanjang fasilitas forex s.d 31-03-2020', '', '1561642730-image2019-06-27-153234.pdf', '1561643273-MITSUBISHI.docx', 'none', '0', NULL, NULL, 'Elza Widyasari', 'Dominggus Richardod', 'Christine', '', 'Febriani Kenedy', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', 'Custom', '', 'Perpanjang Fasilitas', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '15:45', 0, '-', NULL, '15:38', '1', 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11001, 'Merina Annisa Noviani', '27-6-2019', '31-3-2020', 'PT Krama Yudha Tiga Berlian Motors', '0', 0, 0, 'None', '60000000', '', '0659090009', '1', '', '', '', '', '', '', '', '', '', '', 'perpanjangan fasilitas', '', '1561642881-image2019-06-27-153327.pdf', '1561643284-KRAMA.docx', 'none', '0', NULL, NULL, 'Elza Widyasari', 'Dominggus Richardod', 'Christine', '', 'Febriani Kenedy', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', 'Custom', '', 'Perpanjang Fasilitas', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '15:46', 0, '-', NULL, '15:41', '1', 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11002, 'Monika Istiana Dewi', '28-6-2019', '25-6-2026', 'PT MULIAGLASS', '4257500000', 0, 0, 'None', '-', '', '2059071488', '22', '10', '3433007600', '3433007600', '10.25', '997', '-', 'KI', 'ya', 'ya', '', 'Signature Checked!\r\n            Realisasi sesuai terlampir tgl 28-06-2019.\r\n', '', '1561643204-KIMULIAGLASS.zip', '1561706127-mulia.docx', 'asli', '0', NULL, NULL, 'Dewi Virgina', 'Christine', 'Dominggus Richardod', '', 'Febriani Kenedy', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', 'Realisasi', '', 'NONSMILE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '08:59', 1, '-', '28-06', '15:46', '1', 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11003, 'Monika Istiana Dewi', '28-6-2019', '21-9-2019', 'PT DWIJAYA SENTOSA ABADI', '12796014000', 0, 0, 'None', '-', '', '2059002711', '3', '-', '4683839119', '4683839119', '10', '997', '-', 'TL', 'ya', '1 Lembar', '', 'Signature Checked!\r\n            ', '', '1561643314-TLDSA.pdf', '1561703912-dsa.docx', 'asli', '0', NULL, NULL, 'Dewi Virgina', 'Christine', 'Dominggus Richardod', '', 'Endah Nurnendah', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', 'Realisasi', '', 'SMILE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '16:35', 1, '-', '01-07', '15:48', '1', 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11004, 'Junista', '28-6-2019', '5-7-2019', 'PT Agung Automall', '30000000000', 0, 0, 'None', '0', '', '205-900-426-8', '004 dan 005', '-', '', '035-317-499-9', '', '', '', '', '', '', '', 'Signature Checked!\r\n            Perpanjangan PBMM dan debet bunga periode sebelumnya ', '', '1561643831-PerpanjanganPBMMagung.zip', '1561705065-', 'asli', '0', NULL, NULL, 'Elza Widyasari', 'Dominggus Richardod', 'Christine', '', 'Febriani Kenedy', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', 'Custom', '', 'Rollover PBMM', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '17:04', 1, '-', '28-06', '15:57', '1', 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11005, 'Nadia Wohon', '28-6-2019', '28-12-2019', 'PT Ruangan Pendingin Indonesia', '5892563760', 0, 0, 'None', '0', '', '0699002811', '005', '-', '0697732288', '0697732288', '10.25', '997', '-', 'TL', 'ya', '', '', 'Signature Checked!\r\n            ', '', '1561644042-1.RPITarikTLRp5.892.563.760.zip', '1561707640-REALISASIRPI.docx', 'asli', '0', NULL, NULL, 'David Ardian', 'Dimas Qolifatul Fajerul', 'Resnawati', '', 'Febriani Kenedy', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', 'Realisasi', '', 'SMILE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '08:12', 1, 'Urgent (Bypassed)', '10-07', '16:00', '1', 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11006, 'Merina Annisa Noviani', '27-6-2019', '27-6-2019', 'PT Mandiri Sekuritas', '70000000000', 0, 0, 'None', '0', '', '2059004080', '2', '', '', '2050005898', '', '', '', '', '', '', '', 'Signature Checked!\r\n            pelunasan PBMM + debet bunga', '', '1561646006-image2019-06-27-093345.zip', '1561646299-mandiri.docx', 'none', '0', NULL, NULL, 'Elza Widyasari', 'Dominggus Richardod', 'Christine', '', 'Endah Nurnendah', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', 'Custom', '', 'Pelunasan PBMM', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '16:37', 0, '-', NULL, '16:13', '1', 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11007, 'Kevin Keisha Pratama', '28-6-2019', '28-6-2019', 'PT Gading Prima Perkasa', '0', 0, 0, 'None', '0', '', '0849098898', '001', '-', '', '0848878998', '-', '-', '', '', '', '', '', 'Debet Biaya Administrasi Rp 10.000.000', '', '1561645011-GPP-2019-06-17-SPPK.pdf', '1561703937-GADING.docx', 'none', '0', NULL, NULL, 'Elza Widyasari', 'Dominggus Richardod', 'Christine', '', 'Febriani Kenedy', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', 'Custom', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '08:21', 0, '-', NULL, '16:16', '1', 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11008, 'Conny Yusran', '27-6-2019', '12-8-2019', 'PT. PANEN WANGI ABADI', '60000000000', 0, 0, 'None', '0', '', '2059011086', '-', '-', '3193109469', '3193109469', '-', '-', '-', 'TL', 'tidak', '', '', 'SETTING PLAFON SUBLIMIT TL DARI PT. MITRA ADIPERKASA TBK rek. 2059006813 kom.001', 'SETTING PLAFON SUBLIMIT TL DARI PT. MITRA ADIPERKASA TBK rek. 2059006813 kom.001', '1561645300-SPPKMAP2019-02-04-091229.pdf', '1561647716-PANENWANGI.docx', 'none', '0', NULL, NULL, 'Wilbert Karel Wetik', 'Dimas Qolifatul Fajerul', 'Resnawati', '', 'Febriani Kenedy', '', '1', '1', '1', '1', '1', '0', '0', 1, '0', 'Setting Plafond Baru', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Ya Allah udah di reject ko masih salah. mikirin jokowo melulu sih\r\n\r\nitu nomor komitmen sama nomor rekening di kolom keterangannya salah pak', '16:57', 0, 'Urgent (Bypassed)', NULL, NULL, '1', 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11009, 'Hizkia Ignatius Tambun', '27-6-2019', '27-6-2019', 'PT. Buana Megah', '0', 0, 0, 'None', '0', '', '411-900-046-4 ; 010 907 091 4', '001; 001 & 002', '001; 001 & 003', '', '', '10%', '', '', '', '', '', '', 'Ubah Bunga KL menjadi 10% effektif tgl 24-06-2019 (back dated)\r\nubah index menjadi 997', '', '1561646180-SPPK2019.pdf', '1561648003-BUANA.docx', 'none', '0', NULL, NULL, 'Lidia', 'Dominggus Richardod', 'Christine', '', 'Febriani Kenedy', '', '1', '1', '1', '1', '1', '0', '0', 1, '0', 'Custom', '', 'Ubah Suku Bunga', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'indeks kosong', '17:03', 0, '-', NULL, '16:26', '1', 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11011, 'Leonhard Bianda', '28-6-2019', '25-3-2025', 'PT Dayasa Aria Prima', '0', 0, 0, 'USD', '697881', '', '2059009359', '2', '-', '2050072722', 'sin-dik-asi', '5.83138', '997', '2', 'KI', 'ya', 'ya', '', '1.) realisasi sesuai surat agen terlampir\r\n2.) monitor dana masuk pada rek. 205.007.2722 sebesar USD 1.395.762\r\n3.) pindah dana ke no. rek 205.008.8823 sebesar USD 1.395.762\r\n4.) bayar bunga tiap 25 Mar Jun Sep Des', '', '1561720199-ANGSURAN.zip', '1561722720-ATTACHMENT.docx', 'none', '0', NULL, NULL, 'Mega Febrilia', 'Michael Antonius Tholense', 'Resnawati', '', 'Muhammad Budi Sulistiyono', '', '1', '1', '1', '1', '1', '0', '0', 1, '0', 'Realisasi', '', 'NONSMILE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Kurang tanggal bayar bunga', '13:38', 0, '-', NULL, '16:37', '1', 2, NULL, '28-6-2019', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11013, 'Hizkia Ignatius Tambun', '26-6-2019', '13-7-2019', 'PT. Buana Megah', '1104760416.67', 0, 0, 'None', '0', '', '411-900-046-4 ; 0899006919; 4119001177; 0109070914', '', '-', '', '4110689999', '', '', '', '', '', '', '', 'Rek. 4119000464\r\nPenambahan & perpanjangan KL menjadi Rp 72.204.588.522 (com 001)\r\n\r\nRek 0899006919\r\nBaru KI Rp 80M\r\nPenambahan & perpanjangan TL. Rev. menjadi Rp 316.2 (com 001)\r\nBaru Forex (Tod, Tom, Spot, Forward) USD 2 Jt\r\n\r\nRek 4119001177\r\nPenambahan & erpanjangan KMF LC (sight/usance) & SKBDN menjadi USD  5.5 Jt (com 004), saling mengikat dengan Rek 0899006919 com 005\r\n\r\nRek 0109070914:\r\nPerpanjangan KL com 001, 002 & TL com 003\r\n\r\nRek 0899006919:\r\nHapus com 3, 4 & 6\r\n\r\nDebet Provisi hitungan provisi terlampir di SPPK\r\n\r\nPK. No. 5 tgl 25 Juni 2019\r\n', '', '1561647766-SPPKBuanaMegah.pdf', '1561647861-', 'none', '0', NULL, NULL, 'Lidia', 'Dominggus Richardod', 'Christine', '', 'Febriani Kenedy', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', 'Custom', '', 'Perpanjang Fasilitas', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '17:04', 0, '-', NULL, '17:02', '1', 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11014, 'Patricia Ariel Oleano', '27-6-2019', '11-7-2019', 'PT. TIMAH', '0', 0, 0, 'None', '0', '', '2059009677', '001', '001,003,004', '', '0413083025', '8', '997', '', '', '', '', '', '- ppj pembayaran pinjaman sd 11 Juli 2019\r\n- bunga yg jatem hari ini tetap didebet manual -> dana sudah tersedia spt terlampir\r\n- suku bunga 8% sd 11 Juli 2019', '', '1561647848-OrharPIK-PpjTL27062019.zip', '1561648366-ATTACHMENTT.docx', 'none', '0', NULL, NULL, 'Nyimas Wida', 'Resnawati', 'Michael Antonius Tholense', '', 'Febriani Kenedy', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', 'Custom', '', 'Gagal Debet', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '17:05', 0, '-', NULL, '17:04', '1', 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11015, 'Vivin Veronica', '27-6-2019', '27-10-2019', 'PT Lautan Steel Indonesia', '2056596525.44', 0, 0, 'None', '0', '', '205-900-406-3', '4', '-', '7110352888', '711-035-288-8', '10', '997', '-', 'TR', 'tidak', '', '', 'Signature Checked!\r\n            Deal kurs dengan Ibu Tia TRS Rp 14.176 ', '', '1561647941-FwdTIDAKURGENTPELUNASANDOKUMENY084805USD14507594.msg', '1561648018-LSI.docx', 'asli', '0', NULL, NULL, 'Dewi Virgina', 'Christine', 'Dominggus Richardod', '', 'Febriani Kenedy', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', 'Realisasi', '', 'SMILE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '17:06', 1, '-', '28-06', '17:05', '1', 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11016, 'Hizkia Ignatius Tambun', '28-6-2019', '28-6-2019', 'PT. Buana Megah', '0', 0, 0, 'None', '0', '', '411-900-046-4 ; 0899006919; 4119001177; 0109070914', 'seluruh komitmen', 'seluruh pinjaman', '', '', '-', '997', '', '', '', '', '', 'Ubah seluruh index menjadi 997', '', '', '1561705309-buanamegah.docx', 'none', '0', NULL, NULL, 'Lidia', 'Dominggus Richardod', 'Christine', '', 'Febriani Kenedy', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', 'Custom', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '17:15', 0, '-', NULL, '17:09', '1', 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11017, 'Vivin Veronica', '28-6-2019', '28-6-2019', 'PT Caturadiluhur Sentosa', '0', 0, 0, 'None', '0', '', '2059001943', '8', '-', '', '', '', '', '', '', '', '', '', 'untuk dapat menambahkan Kode Perusahaan DF Mowilex .\r\nUntuk kode perusahaan DF Mowilex adalah 00005003044\r\n', '', '1561649045-REKodePerusahaanKerjasamaDFuntukCaturAdiluhurSentosa.msg', '1561704444-', 'none', '0', NULL, NULL, 'Dewi Virgina', 'Christine', 'Dominggus Richardod', '', 'Febriani Kenedy', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', 'Custom', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '08:13', 0, '-', NULL, '17:24', '1', 2, NULL, '28-6-2019', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11018, 'Kevin Keisha Pratama', '28-6-2019', '1-7-2019', 'PT Nusa Surya Ciptadana', '175000000000', 0, 0, 'None', '0', '', '2059001293', '003', '-', '0093045430', '009-304-543-0', '-', '-', '1', 'PBMM', 'tidak', '', '', 'Signature Checked!\r\n            ', '', '1561649549-KonfirmasiPBMM280619.2.tif', '1561702939-nusasurya.docx', 'asli', '0', NULL, NULL, 'Elza Widyasari', 'Dominggus Richardod', 'Christine', '', 'Endah Nurnendah', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', 'Realisasi', '', 'SMILE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '08:04', 1, '-', '05-07', '17:32', '1', 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11019, 'Aris Fredy', '27-6-2019', '12-7-2019', 'PT Krakatau Steel', '0', 0, 0, 'None', '0', '', '2059006121 dan 2459006561', '5 (TR) dan 5 (TL)', 'TR (1,3,4,5,6,7) dan TL (13,14,15,16,17,18)', '', '0', '-', '-', '', '', '', '', '', 'Signature Checked!\r\n            perpanjangan 12 pinjaman (surat akan direvisi besok)', '', '1561651916-Segment001ofdk665.pdf', '1561653749-12PPJPIJAMANKRAKATAUSTEEL.docx', 'asli', '0', NULL, NULL, 'Dewi Virgina', 'Christine', 'Michael Antonius Tholense', '', 'Febriani Kenedy', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', 'Custom', '', 'Perpanjang Pinjaman', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '18:12', 1, '-', '05-07', '18:11', '1', 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11021, 'Valiant Gunawan', '28-6-2019', '28-7-2019', 'PT. Jasa Marga (Persero)', '150000000000', 0, 0, 'None', '0', '', '0359005603', '7', '-', '2050067257', '2050067257', '8% p.a', '997', '-', 'TL', 'ya', 'ya', '', 'Signature Checked!\r\n            Realisasi fasilitas TL sejumlah Rp. 150.000.000.000,- dengan bunga 8% p.a dikreditkan pada rekening 205-006725-7 dan akan dibayar kembali kepada BCA pada tanggal 28-07-2019\r\n\r\ntidak dilakukan pendebetan provisi karena provisi sudah terdebet maksimal saat penarikan sebelumnya untuk jangka waktu sampai dengan tanggal 13-08-2019\r\n\r\nTanggal pembayaran bunga 3 bulanan setiap tanggal 13 bulan agustus, november, februari dan mei', '', '1561737413-Penarikan28-06-2019.zip', '1561744169-', 'none', '0', NULL, NULL, 'Nyimas Wida', 'Resnawati', 'Michael Antonius Tholense', '', 'Muhammad Budi Sulistiyono', '', '1', '1', '1', '1', '1', '0', '0', 1, '0', 'Realisasi', '', 'NONSMILE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '18:01', 0, '-', NULL, '19:50', '1', 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11022, 'Valiant Gunawan', '28-6-2019', '28-7-2019', 'PT. Bosowa Marga Nusantara', '1527302394', 1, 0, 'None', '0', '', '2059002249', 'terlampir', 'terlampir', 'bulanan', '0253705717', '10.801%', '997', '1 bulanan', 'KI', 'ya', 'ya', '', 'Signature *Not* Checked!\r\n1. mohon bantuan agar pendebetan dari rekening nasabah 0253705717 sebesar Rp. 920.092.530,- selanjutnya \r\n   ditransfer ke rekening PT. Bank Sulselbar Cabang Jakarta 400-800400-1 sebesar Rp. 136.751.576,- \r\n2. Pencairan KI IDC untuk pembayaran bunga sebagai berikut:\r\n   a. Pencairan Rp. 1.527.302.394,-( Kom 004, pinjaman baru)\r\n   b. Tabel angsuran terlampir\r\n   c. Pembayaran bunga setiap tanggal 29/bln \r\n3.Pembayaran bunga jatuh tempo 28 Juni 2019 (yang didebet dari rekening 0253705717) untuk komitmen 3 dan 4\r\n4.Suku bunga sebagaimana terlampir efektif per tanggal 29 Juni 2019 s/d 28 Juli 2019 sebesar \r\n   10,801%\r\n\r\n', '', '1561727855-PenarikanKIIDCdanPembayaranBunga28Juni2019.zip', '1561730541-Signature.docx', 'none', '0', NULL, NULL, 'Nyimas Wida', 'Resnawati', 'Michael Antonius Tholense', '', 'Febriani Kenedy', '', '1', '1', '1', '1', '1', '0', '0', 1, '0', 'Realisasi', '', 'NONSMILE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'LAMPIRKAN TABEL ANGSURAN DAN MEMO DR GCF YANG TERBARU', '15:27', 0, '-', NULL, '21:11', '1', 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11023, 'Nur Rahmah Hastiati', '28-6-2019', '1-10-2019', 'PT Lautan Teduh Interniaga', '0', 0, 0, 'None', '0', '', '0209001197', '001', '-', '', '0200772288', '0', '0', '', '', '', '', '', '-perpanjangan fasilitas KL sementara s.d 1 oktober 2019\r\n', '', '1561701709-SuratPpjsPTLTI2019-06-27-175228.pdf', '1561705069-', 'none', '0', NULL, NULL, 'Elza Widyasari', 'Dominggus Richardod', 'Christine', '', 'Febriani Kenedy', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', 'Custom', '', 'Perpanjang Fasilitas', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '08:42', 0, '-', NULL, '08:01', '1', 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11024, 'Patricia Ariel Oleano', '28-6-2019', '23-9-2032', 'PT. JASAMARGA MANADO BITUNG', '12742474238', 1, 0, 'None', '0', '', '2059008352', '001', 'baru', 'sindikasi', '-', '10', '997', '-', 'KI', 'ya', 'ya', '', '- realisasi dan RTGS:\r\n	No. rek: 1500012956908\r\n	Nama Bank: Mandiri Cab. Manado Dotulolong Lasut\r\n	a.n: PT Jasamarga Manado Bitung\r\n- tgl pembayaran bunga setiap tgl 23 Mar, Jun, Sep, Des\r\n- terlampir tabel angsuran\r\n\r\n*Laporan pengawasan ke23 periode 1 April - 30 Apil 2019', '', '1561702277-Penarikanke2027062019.zip', '1561707360-1REALISASIJASAMRAGA.docx', 'none', '0', NULL, NULL, 'Nyimas Wida', 'Resnawati', 'Michael Antonius Tholense', '', 'Endah Nurnendah', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', 'Realisasi', '', 'SMILE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '08:26', 0, '-', NULL, '08:03', '1', 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11025, 'Nur Rahmah Hastiati', '1-7-2019', '', 'PT Lautan Teduh Interniaga', '0', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '1561701800-SuratPpjsPTLTI2019-06-27-175228.pdf', '1561961047-', '', '0', NULL, NULL, 'Elza Widyasari', 'Dominggus Richardod', 'Christine', '', 'Febriani Kenedy', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', 'Provisi', '1561683800', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '08:45', 0, '-', NULL, '08:03', '1', 2, NULL, '1-7-2019', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL),
(11026, 'Hizkia Ignatius Tambun', '28-6-2019', '5-7-2019', 'PT. Panin Sekuritas', '3000000000', 0, 0, 'None', '0', '', '205-900-609-1', '001', '-', '', '205-000-814-5', '-', '-', '', '', '', '', '', 'Signature Checked!\r\n            Roll over 1 + debet bunga sebelumnya', '', '1561701863-PBMMtgl28Juni2019.zip', '1561712680-PANIN.docx', 'asli', '0', NULL, NULL, 'Elza Widyasari', 'Dominggus Richardod', 'Christine', '', 'Endah Nurnendah', '', '1', '1', '1', '1', '1', '0', '0', 0, '0', 'Custom', '', 'Rollover PBMM', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '08:27', 1, '-', '28-06', '08:04', '1', 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `msuser`
--

CREATE TABLE `msuser` (
  `id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `head` varchar(255) DEFAULT NULL,
  `ttd` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `msuser`
--

INSERT INTO `msuser` (`id`, `username`, `password`, `role`, `name`, `head`, `ttd`) VALUES
(0, 'sa', '$2y$10$WsD3tlfV/1V1o0RlfvsO1.gJbVqrK.iog2ysw3PbVrSCoDWV7HtCC', '0', 'Super Admin', NULL, ''),
(4, 'u065946', '$2y$10$TIldQhJ.5IRDt0MVoy4/yulnPNaZrida7lb/v2XgZvrky1gCe2XQS', '6', 'Andra Annatasha', 'Wilbert Karel Wetik', 'Andra Annatasha.PNG'),
(6, 'u056369', '$2y$10$lpVs3iFjn4XaVXBbiTa5ge0o3cy4kPodL1RUxgXph/OyQ1uHoNO2C', '6', 'Maria Gretalita Niken Winaputri', 'David Ardian', 'Maria Gretalita Niken Winaputri.PNG'),
(9, 'u065837', '$2y$10$KpCFQGxBtE.n/6ESzrLTYupyeSykl2ppNyz9m7ufp.i3KYHCc17Hm', '6', 'Endru Sanjaya', 'David Ardian', 'Endru Sanjaya.PNG'),
(10, 'u061045', '$2y$10$BY.iabQprmgojNQClAIzXOVkg8QqFLY.aOGsN3FLD/iHcglCV1.k6', '6', 'Maria', 'Wilbert Karel Wetik', 'Maria.PNG'),
(12, 'u058138', '$2y$10$t4X2jx8QYvYprx9zusPZU.B4M.GOKX36pVtSRAzyCtPjUJPYBrPZW', '4', 'Resnawati', NULL, ''),
(13, 'u061327', '$2y$10$g28nvg3E8czI.MSu26Y8qeCzsZ4KfybGI18M0r8twIEuHW/LUFRWi', '4', 'Michael Antonius Tholense', NULL, ''),
(14, 'u065089', '$2y$10$R.v1u1UcR1/wRCbihdNiHOYC38kgPuDOT0izsi/rFqi2cWNcdkYxm', '3', 'Dominggus Richardod', NULL, ''),
(15, 'u060668', '$2y$10$qXAFtzhX3E41XtqVCHcH5.TF5QiLnlZRxTlTA1TfNhB1V9a77lydu', '6', 'Christine', 'Wilbert Karel Wetik', 'Christine.PNG'),
(19, 'u897691', '$2y$10$9bzxAjGH7eh/l75/B6jAverc.BB6mVMxZAj3majTGQSHM2OtYF6hy', '5', 'Endah Nurnendah', NULL, ''),
(20, 'u050140', '$2y$10$xKD/QQI4ZTs5ZPP2LAerbOMmf/JmRjnwvkf69QQYRPJU4FYF1fGAK', '5', 'Muhammad Budi Sulistiyono', NULL, ''),
(22, 'u963671', '$2y$10$B9zJCUapWtTYoxvaAJtNOeyXAxwdW5YNCOZPBUzaNQxsEuAL1EpHi', '7', 'David Ardian', NULL, 'David Ardian.PNG'),
(23, 'u970592', '$2y$10$wJOsp1M3sBJZFfySIYIfgu1/Lir./c6zI9m693fUbRAP0g4lziRma', '7', 'Wilbert Karel Wetik', NULL, 'Wilbert Karel Wetik.PNG'),
(24, 'u051378', '$2y$10$EtJiFTZ9Zw8tFKjZmr782uAMsnXuEaVYyOrW9vmiOeBOBnsKs2xMG', '2', 'Dewi Virgina', NULL, 'Dewi Virgina.PNG'),
(25, 'u054936', '$2y$10$cdBzO1CK6MFF5HgW05g6/efsb5f8lw0AUG6vXTjZL4YZ52yzg0wA.', '2', 'Carissa Kurniawan', 'Dewi Virgina', 'Carissa Kurniawan.PNG'),
(26, 'u056483', '$2y$10$1MZrllld/A9Ms51Md.dx7O2k6qvrFKZdSpTekPDGAj2GX/RzToYAe', '2', 'Aris Fredy', 'Dewi Virgina', 'Aris Fredy.PNG'),
(27, 'u057692', '$2y$10$3RMwduhf5BSEwqHBE9WNM.eu53iYaTllzl2AJ6d.dJuX9SA9v0Rk6', '1', 'Merlyn Halim', 'Carissa Kurniawan', 'Merlyn Halim.PNG'),
(30, 'u064989', '$2y$10$y4q.VBSzAaN3xHjQGFbi7uZ4KNqrglZxOWv8cr/uBvJ1SSmz4xnlW', '1', 'Monika Istiana Dewi', 'Dewi Virgina', 'Monika Istiana Dewi.PNG'),
(31, 'u065058', '$2y$10$wvTgWPHjztVgQVxOth4lOea0kaQjzHXG4lQEvGP0oqoqsjOqfKZSG', '1', 'Hindrawati', 'Dewi Virgina', 'Hindrawati.PNG'),
(32, 'u065477', '$2y$10$T7dK6cwZhp/QNjYaqcj.TOAtpi/ILrPwZyJET2mDA26.mjLLeZlqq', '1', 'Bertha Elita Hia', 'Carissa Kurniawan', 'Bertha Elita Hia.PNG'),
(33, 'u974124', '$2y$10$WZT9yW7I17255.WFaBQlv.Qp1uEdZ/0Sy42aFcDrXBTYGtWw5WncW', '6', 'Conny Yusran', 'David Ardian', 'Conny Yusran.PNG'),
(34, 'u050328', '$2y$10$VJzyN.SeIgWqr6nBu75wVOHOXZz9C1CNBs6vm.x/OWYihjg9UjYwm', '2', 'Nyimas Wida', NULL, 'Nyimas Wida.PNG'),
(37, 'u066132', '$2y$10$CQJaDNZZ8Xl3mjqg/cHz4uAlmbI4R.4u3Xug2DJYzb3wEL/nmAQ5e', '1', 'Patricia Ariel Oleano', 'Nyimas Wida', 'Patricia Ariel Oleano.PNG'),
(39, 'u051383', '$2y$10$NMxhG5oCcK5qVtLiVp6OXuuXA1FB99XKwom3cx8o167h.fAuwJ6S.', '2', 'Mega Febrilia', NULL, 'Mega Febrilia.PNG'),
(40, 'u055826', '$2y$10$SCihIrJ7pB31.5oFLo8R2Orglnhq.nI9pFEOFIRHrMqs6l9tT2loK', '4', 'Indra Sugata', 'Mega Febrilia', ''),
(43, 'u065158', '$2y$10$AUnKbVWly1xuc1fSo.EvkOxASZ95upKuZC2eFG8pIhfh7qESoKdVK', '1', 'Yusuf Patandung', 'Mega Febrilia', 'Yusuf Patandung.PNG'),
(45, 'u066347', '$2y$10$EE4L9MeIEFRLNbZ8UUIC7.TlnnsEYxxpaOj/o50/nTjWVEeGJHsc6', '1', 'Nadila', 'Mega Febrilia', 'Nadila.PNG'),
(46, 'u058825', '$2y$10$gNn72jOUFGfNki9JviuzMegFjZWLUXxMB..UQnl8u4ns9z30TSEJ2', '1', 'Yedidia Panca Onesimus', 'Elza Widyasari', 'Yedidia Panca Onesimus.PNG'),
(47, 'u055492', '$2y$10$iJb97yYSEJw9pd5aj9SD8ORdWKlmIvPq5p0KRhatXhUQqSFEtAW.e', '1', 'Merina Annisa Noviani', 'Elza Widyasari', 'Merina Annisa Noviani.PNG'),
(48, 'u058165', '$2y$10$WWgtwhH6s5xQrkImTXeFFOMXOktksg/NYGI3TA45YVufTQIHphMpG', '1', 'Junista', 'Elza Widyasari', 'Junista.PNG'),
(51, 'u065218', '$2y$10$h.yX6NGOugbPYhgSOCcLbeO02AjCMmCYZ5EtZq8nXE3F4hsk6Auim', '1', 'Nur Rahmah Hastiati', 'Elza Widyasari', 'Nur Rahma Hastiati.PNG'),
(52, 'u057419', '$2y$10$dzQxpLNh67hPZzffdhcwF.CBDAqn0wjPvlsGzWKnaKJf6lGvzHIU6', '1', 'Vinsensia Givy Gisela', 'Elza Widyasari', 'Vinsensia Givy.PNG'),
(53, 'u066128', '$2y$10$lNl0SVlzSnovfHswuemBD.izrr8q1EDeKFUbDWvx1JfEUz7LdCMAa', '1', 'Hizkia Ignatius Tambun', 'Elza Widyasari', 'Hizkia Ignatius Tambun.PNG'),
(55, 'u050615', '$2y$10$YwIV10/B4Ufkq5UYM2WJHOe2d30PUKb20siNB0xja6keY9x9A6rci', '2', 'Lidia', 'Lidia', 'Lidia Sengyu.PNG'),
(58, 'u974606', '$2y$10$0jAAs1Cy39aV4HO/jajbcer/A17cBb0sWSKL3ugko3XGPCsvdSmnm', '2', 'Liliani Kurniawan', NULL, ''),
(59, 'u912671', '$2y$10$MNiUpmrSyblK0FGYTUjtBupRPgj08NsE/I1I/ZUQ5gGHHYMYbF3Xa', '2', 'Dhejani Surjadi', NULL, ''),
(60, 'u052221', '$2y$10$s5sTGdxAdsoV0BF/v0d1GOCg2Ut4GF6y2rvS3DAvSGTMXedNywHTy', '2', 'Elza Widyasari', NULL, 'Elza Widyasari.PNG'),
(61, 'u010168', '$2y$10$qiLHoPTLmC2d21TbRyXIFeCUMHx0rYgrlcWb9zXU2CROz62yK4wIK', '2', 'Ona', NULL, ''),
(62, 'u054354', '$2y$10$rYhW.wHgYKHiSph6GHUDruWqH28BWR3cNKL5YsfmrEVyZ6GOZqRNO', '4', 'Bagus Risza Fahrodhi', NULL, ''),
(72, 'u055505', '$2y$10$rqjg.sEfF0hAxut3Qt5aNO4rtyKaF9wnJOgMbtup0jM.9Cr31YG/W', '1', 'Valiant Gunawan', 'Nyimas Wida', 'Valiant Gunawan.PNG'),
(73, 'u064872', '$2y$10$Q1/HF7WL.DZeR8oYv0yjaOxIpnt.0I3IvgwDWVn3noOn2br3bjSSK', '9', 'Santo Christianto', NULL, ''),
(74, 'u053524', '$2y$10$JNSIQZTwfPUa.bSbeLOXd.mS6MNp96wf4uyaktAQuPTt11WaBLnku', '9', 'Mimin Rusmiati', NULL, ''),
(75, 'u940327', '$2y$10$e6sUll9aX1g59LlUEjISuuE6bGiN86MfpWsWTmk26mYaOt0jvclDC', '9', 'Tju I Thing', NULL, ''),
(77, 'u970116', '$2y$10$xPwMIxA1PwE4jU/a.3RCZOgu2hmZ4cv/YOblLHey5cWvTw29pqazy', '9', 'Gia Anastasia', NULL, ''),
(81, 'u066343', '$2y$10$Q3PmcSJIh8IbjQoyZqfDruO3nGfOWXyDHqBnVH9hhmvv6oXvuf8XW', '3', 'Nurlaili Putri', NULL, ''),
(84, 'sa1', '$2y$10$KL/6ami9rarneaJrAHwGkuzou.GliT1/dVAiD4cOYviTOSm.jQzl2', '0', 'Super Admin 1', NULL, ''),
(85, 'sa2', '$2y$10$IMPZ3qQ8.wXECWP2LPLceuTNbaw74D/yLIT822fjMCtDnQWYz4Q82', '0', 'Super Admin 2', NULL, ''),
(87, 'u061262', '$2y$10$f0mNOybYULTCDviksdJEK.qC5DxHXVTrY6UKcqTkPCyANSmvd6FcG', '4', 'Desyanti Purba', NULL, ''),
(89, 'u065836', '$2y$10$hfI.ID1wH.jfYoxC4uIJmO5N6rKFSndrdAmaiPl0/IwHZ4ViQ4Ebe', '3', 'KALMI YAEL', NULL, ''),
(91, 'u067236', '$2y$10$yI.ru7AbR46wb2PxtgBWCeHp5HfegA.2T4ZUmKsW7nndfXATqGsSG', '3', 'Liona Meilinda', NULL, ''),
(92, 'U066503', '$2y$10$cw.h6DjCkGLMgiKMBB46U.TJEX0svdhh7s.VBZjQ78mAMm9uaaqmi', '9', 'Eunice Claudia Christiani L', NULL, ''),
(93, 'U67325', '$2y$10$jbZzc3k1aEQ8A5ipyqcufeiv05E4mRIzZYQxkwoj5fh524J6PtLW6', '10', 'Christian', NULL, ''),
(94, 'U66494', '$2y$10$MM2mefn5Y/U1qh5QF5dC1.MJP08IIssBZDgykO.BqrFoYJMsGCKDC', '3', 'Finda Ariesta Mulia', NULL, ''),
(96, 'U534304', '$2y$10$qIqDrNICSW0EKqHVZhpiVudyCo7OLPY4b.IcXvVJVeyX8F6dXv29a', '10', 'Alvia Sindi Hastuti', NULL, ''),
(97, 'U060828', '$2y$10$1uG8YPyt0BKYAR6SGAA5Ie4crwO6KJZVcDF3izdTGpFDkL42LFQmK', '14', 'Monika Tiur Apriani', NULL, ''),
(100, 'u060491', '$2y$10$XchB9TKt41/VOjyO5qpGXet6ytMP0yMIwEWxWQ9irWwH3nzYwARMW', '11', 'Moch. Tri Wicaksono', NULL, ''),
(101, 'U940720', '$2y$10$cdd21yLMTwW8VqtdlKL/GeyFzqbXuKLub2xbFMnqFNHJUzi.qfDDG', '11', 'Iwati', NULL, ''),
(104, 'U065430', '$2y$10$dshKFFlMBctdCRYbWXuxg.caxb2Z8t8rFL1.c6cv4JmoeBf2U7BWC', '12', 'Keren Hapukh', NULL, ''),
(108, 'U057434', '$2y$10$Hm8LNp5qKJHlz3.b6iknWOTtfScHvp8krfuH.Vsj25J9VJie7sekS', '1', 'Putri Pramesti Tiarma', 'Elza Widyasari', 'Putri Pramesti Tiarma.PNG'),
(109, 'U068148', '$2y$10$tIXbQJJQw43R2vSEAYk1V.OodyEgkthXgVwjnA6iSmFY30TK7iSV.', '1', 'Jonathan', 'Carissa Kurniawan', 'Jonathan.PNG'),
(111, 'U534305', '$2y$10$qzT7WQ9pplRJ7c2IpBtuf.zeHu5Jhvg4tK39Oayhu7my0eTP16ptK', '3', 'Septi Arinta Dewi', NULL, ''),
(112, 'U068281', '$2y$10$apqVti3Ni00GdoHarCjptu0YUhV5xOO1WWdFInWJh2Iq7NXZfoU7y', '1', 'Christa Amelia', 'Elza Widyasari', 'Christa Amelia.PNG'),
(113, 'U067698', '$2y$10$j0x7OeOKGTBnpz7nQNKpiO76ftpun5uox0Eyzv8XaK6o.Uracky7C', '9', 'Benedict Yunas Nandiwardhana', NULL, ''),
(114, 'U068296', '$2y$10$0fFCx.4lmMYK4vMqBHpYw.Cybfr34FZVnsugCe257oiIOwRGvDCi6', '1', 'Caecilia Novadena', 'Nyimas Wida', 'Caecilia Novadena.PNG'),
(117, 'u065159', '$2y$10$GB3xB2bwE6SFKOeNPbYXNubOb.8hSrWwLsEFOyctiEceLU.Nsgv1y', '14', 'Ni Putu Emy Indrayani', NULL, ''),
(121, 'testes1', '$2y$10$jirgyaHhLJyvfWGpi59/eOS1M/peQzs4JEX./8TpMrtYEuLfEq.he', '1', 'slk op', 'Choose Head Cluster', 'Background Zoom HUT BCA64-01.JPG'),
(122, 'testes2', '$2y$10$Hrw0XZvUPg06HKXP479FK.OwTYi/3tbewQcteXPxvmFVcWvlMkF.K', '7', 'SLK HC Testing', NULL, 'Webinar-BCA-HD.JPG'),
(123, 'testes3', '$2y$10$6WP1C9yjSTmA0tc97S4leu3Yrh6CuZ7FoQDh77oeSAELUdju.nUPm', '3', 'Pik Operator Testing', NULL, ''),
(124, 'testes4', '$2y$10$GBwlLFM4itc6vf2QtqKTzeXgfxfuBTUYl5hDXDCuuTyrKEqs3w/tO', '4', 'ASD', NULL, ''),
(125, 'testes5', '$2y$10$tuuRFSP411F9GM1GD97F8eKypwn0cD6BkpAr343PxgwQXl0AUekIy', '5', 'PIK HC Testing', NULL, ''),
(126, 'testes6', '$2y$10$va60.vNf21BQwjM9f3ibZOo1txxl.WU/RgkVwWnxElhlx5nF.VW4G', '10', 'Cams Operator', NULL, ''),
(127, 'testes7', '$2y$10$a9J936Z.i2me94jwYALAcuOgEXXMhVyG5MePSexwE59J0UwEAOtsy', '13', 'Cams Supervisor', NULL, ''),
(129, 'U068457', '$2y$10$6r1ADFLHybf1yQEZamnh3u7/oLotJvSw/w1YfCxnAnDCcXAmVm5bS', '1', 'Cindy Chandra', 'Mega Febrilia', 'Cindy.PNG'),
(131, 'U068545', '$2y$10$x3ZHAjk9T/rjqlaDcjlVYusENrRsXR.CuNQTf7rmnGrMw7K5dzOmS', '10', 'Ryan Daviandi', NULL, ''),
(133, 'testesmonop', '$2y$10$ZKc/VuApSXLcQokwq.a/j.gvGVCCJaJ9Y0Gi9LT5YNIU63j3GtGwC', '14', 'Mon OP', NULL, ''),
(135, 'U068703', '$2y$10$7laeJwUAkTB/UKPE.riRdOwsg.aIDU1UQGcsAwPbL2WWJLV1S4p66', '6', 'Stanlie', 'David Ardian', 'Stanlie.PNG'),
(137, 'U068802', '$2y$10$f3yImmoy.P62dz57gegWMOlTsTyz6KcSL09JqMxBvMg8jZDwlIxI.', '3', 'Mario', NULL, ''),
(140, 'U973841', '$2y$10$5UsJ5T8oO.u6VzoXIW5oIOgo6ZWTWERih5yQi7oMSpvq8q2Bw8dJK', '20', 'Abdul Walid', NULL, ''),
(142, 'U069103', '$2y$10$DprJqhhULdKJy5tKiAR4Xeyo0xcPunU1U8i4lIjgx2Ifo.ptNf6TK', '9', 'Regita Aditya Surya', NULL, ''),
(143, 'U069071', '$2y$10$BZRzAfYKQPmKhCrXWfjygen0J7IoRnwJ5Yqgic4NpbldtkDuWNSle', '9', 'Rika Monalisa Tamsil', NULL, ''),
(146, 'U061873', '$2y$10$AfBGrL0KPeUryqO.Lw0kB.hRIfWRNL2dph66lF96cwd6vWx0mqByO', '9', 'Felicia', NULL, ''),
(151, 'backup', '$2y$10$0SVq5qwMG5DJANl4RqKRNumBe2hM5sPbJXMF/YzPUaLu.wgz64Wny', '1000', 'backup', NULL, ''),
(152, 'U541505', '$2y$10$ibik3/gNzuBtp7uKRLlkw.ETKCKVhEmDwYF0kd7xaz3H7CLPr3dG.', '10', 'Dwiky Satriawan', NULL, ''),
(155, 'u004021', '$2y$10$nYw.Pb3speF4bB7hIBVot.TywBAWRUDzirqaAh5S7G64167Jw05R6', '13', 'Ratna Irana M P', NULL, ''),
(160, 'U970629', '$2y$10$ji6lxTuk3p.hYzeRdU4/9uPYXYXu83QQrn9bLW3d5o.BdRjAnLLOy', '24', 'Toni Fresly F M', NULL, ''),
(161, 'U913891', '$2y$10$JA88.npF1Y8uhU.Ty59dr.Ij6Kg940xKOpyK4SEzo66A/o8peMB9K', '24', 'Elfin Alfiana', NULL, ''),
(162, 'U951149', '$2y$10$MVrcoYgtQ.QriFoQmo7C2uxvMN4RV1qunQ85Zd32Mta4nWXAXO.1S', '24', 'Diah Kusumarini', NULL, ''),
(183, 'u069932', '$2y$10$xau7z9dGyLmsH5UEpZWrd.eftmBKt68Aw6giriZVvo5VkIexkQyGi', '9', 'Cristian Matthew', NULL, ''),
(185, 'u055944', '$2y$10$JWk6a4bUJWDp4q.huCGNo.aqvfw67DW3kD3dujBeY9FtS7YMSpQj2', '24', 'Luciana Chrisnawati', NULL, ''),
(193, '0532321', '$2y$10$sd0qKt/NorsO46x//7k8Hu14cqSsx/1.IZxGx.B8Ii1W4X0LuztsK', '14', 'Septiani Dewi', NULL, ''),
(194, 'testes10', '$2y$10$9f2z2HFzNtCVgn39qBI5y.XYteeC2ADGE.KsDdAJVfjXg3BdlJlxq', '20', 'testes10', NULL, ''),
(195, 'testes9', '$2y$10$VQsB6YsA.J7617FtUT0I7OW.KGKHb84B.CPhVdikC8qbF6oHg0rxy', '9', 'testes9', NULL, ''),
(196, 'u010501', '$2y$10$f8pUtT9IcdIME7qA/KUNLu6ZLycHJP5mNFU/TdRzKW4nqMxjoazl.', '20', 'FELIYANTI TRIAS KUSUMAWATI', NULL, ''),
(198, 'testesmonspv', '$2y$10$5Q/1Ovk2mQfx4S0/5KM/E.01wuuJ9QrmVV5K6lQiQO2t7nrBerYU2', '15', 'testesmonspv', NULL, ''),
(199, 'testesbg', '$2y$10$bJfQz2MB5lgqmkzd42E37.EambHmWmsTtwZG9/GPwK9BmoDYOa.F6', '28', 'bg op', NULL, ''),
(200, 'testesasli', '$2y$10$q9/J3F/Efrr.tRSOzucd4uVWK0LDz3WPv7kgXu6m1W0fh1rZKmd0a', '12', 'testespikasli', NULL, ''),
(203, 'testes7', '$2y$10$B2s35ppgD1l2QtIWe76C4OxVo1ycwpm8DwNQcnwvJEHX0a9Lf3oxa', '11', 'PIK Cams Supervisor', NULL, ''),
(204, 'u069950', '$2y$10$0zm/IjWtxS1SK6BrdLafk.6Y5b58Of9A67SJHsD9oqtxI6NqXa8pS', '14', 'Taniesha Budiono', NULL, ''),
(205, 'u065092', '$2y$10$knR3poFRo89IVYfpP67ciuQgdnJjOWE1UpaqXf6gpfu84T.l7PzHy', '10', 'Albertus Renard', NULL, ''),
(206, 'u070318', '$2y$10$xEZslUPgg9gn92SW1iMY9O./Zt/K/33DqBDXUPVYfJLVprt/UQ39u', '9', 'KEVIN SETIAWAN', NULL, ''),
(208, 'U070544', '$2y$10$GVconXGf0.hK6g4EtwCvLO774Dy5VBgoL4p94N.uYW39.liiTyCWS', '28', 'Feby Yola Wijaya', NULL, ''),
(209, 'testes11', '$2y$10$KjXQyjxNsMTHMjPp458zHOOHO5msVOuwgUzH5GHAvy9RJFLzgcjrC', '6', 'SLK OP Double Check', 'SLK HC Testing', ''),
(210, 'u051087', '$2y$10$.KBBuWHDsV1v8sc0RA1jauuifx.XDQOEPHVe0Si75LV87B2aeELNC', '9', 'Aryadi Wijaya', NULL, ''),
(252, 'u062225', '$2y$10$RiIsUN9G3U8xdIjf2AogLu0no9VkYrNGSvoGFjUgSE8lngxGSu8O.', '28', 'Andi Eldyana Pratama', NULL, ''),
(253, 'u062625', '$2y$10$6AYMOmgvf1C0.ftGpQuXlu7ku4fyLEyGIXBckrtrsa2SJPNIwlA8.', '1', 'Singgih Gautama', NULL, ''),
(256, 'u071991', '$2y$10$6uBwTFydReH05Yzg6vkgNe2D.OS7WUK9MWe7P44Cclt1jIf1QF4ZW', '1', 'Juan Aditya Kencana', NULL, ''),
(259, 'u072058', '$2y$10$sVadIixFrvBjfAO0jmZcN.xc6QSUdx6TwrWR4EtbC6oNzoGAUuEhu', '6', 'Reyhan Daniel Yakub', NULL, ''),
(260, 'u072276', '$2y$10$tUmNDfWmDSvTdeHLfjiCMuRluWTGfd98PsqEmkCGE13ZFLjhaQExm', '1', 'Michelle Angelia', NULL, ''),
(262, 'u072392', '$2y$10$AeuUEhFCJQtkw.HZfw58GudGnFTRIX7fqIelNR0/.3Gnjy8z4FWT6', '6', 'Irene Septin Maharani', NULL, ''),
(264, 'U070658', '$2y$10$C48xSmHW9gNEJLESKniSku4HD7lKvpqAPj1pgUm1ER64.JS3LfmZC', '9', 'Aldi Tanaya', NULL, ''),
(265, 'U073185', '$2y$10$WTI21ItAcyXKAyF3cjrd6eQJkt9/allHqHgJ6AsUnJOWeMBVKBFay', '1', 'Kevin Yogatama', NULL, ''),
(266, 'u072554', '$2y$10$YB54jp/bG3GPY5HsPyCd8ekF5G2dPocg3XKvbsqrO.O.IikxxLDYG', '1', 'Felicia Sidarta', NULL, ''),
(267, 'U073246', '$2y$10$TNsiR63/M7obz8wrI5NVIObdBg7bCxFv7XjGTLebDnanWun2/wcgO', '3', 'Ivana Arni Wijaya', NULL, ''),
(268, 'U057342', '$2y$10$PVWFWepkHb6RIEAfmXoVAOgjSG5.tOHVpfU1HmgWiyo.Dvds6SV42', '9', 'Marrisa Debora D', NULL, ''),
(269, 'U072393', '$2y$10$I6RFbl1geNRhGzGP7Pv40uUqJkAL9OKbZsbJ26LGWfxZQWjuJAAVm', '3', 'Timotius', NULL, ''),
(270, 'U057560', '$2y$10$YtxeRY95YvAovCw.de0MquSsiFc6CeSekfzS4lyJwj9TvVcHAGpyi', '24', 'Alifia Syahrina', NULL, ''),
(271, 'U061640', '$2y$10$pN6uSMHBns4m9XwVmWuZv.Laby.fjCgvTipxfdjvcCynS0dFgwb/.', '24', 'Febrina Angelia S', NULL, ''),
(272, 'U070764', '$2y$10$2ky6e5gzOjhT/rKxl397nOSdiIrn3txC/YXDXfAH194yF2z2c3vm6', '23', 'Stella Natasa', NULL, ''),
(273, 'u072898', '$2y$10$pwT457n89EYXtIItXM.dP.mvZMizXAklnAiC3FVIWyGB60nXBI1Vq', '23', 'Abellisa Ramanov T', NULL, ''),
(274, 'U065838', '$2y$10$gxS7zd/IfRrR8nlvYZtdUuwpt7FdjtlTNmkHZ6nx/GZA4dzoSEBr2', '23', 'Naomi Malem R G', NULL, ''),
(275, 'U070879', '$2y$10$5sNavHfUAYAY41yy2k/RW.yEyW7lTMdy8RvYnbjaSoDBY.0U80nCm', '14', 'Felix Januvi Setianto', NULL, ''),
(276, 'u071716', '$2y$10$lhOSL/ahAECQclTixvc.r.8GeBdjYbuYERZzle0hX3BHlU/ytoKSW', '12', 'Enrico Winata', NULL, ''),
(277, 'u072270', '$2y$10$BdGsJreEH2oDyfbBPeSSTe317RJwv/L5aRjXI5qjqfwkqvtohYNj2', '12', 'Natasaha Zefanya Tantono', NULL, ''),
(278, 'U543560', '$2y$10$4aZFjwpqEbsmZvLWtewKz.RlekdfHikwgeyWiWw4oI4YtpofWWl.i', '10', 'Geoyances Micellia DC', NULL, ''),
(279, 'U912360', '$2y$10$26D4zZaWqayJWR1dNii7TONLobAW66k08zFtHKGrnmXfHvCkpCHj.', '5', 'Candera Liauw', NULL, ''),
(280, 'U067651', '$2y$10$efnwa1f81mmzfylLzZCQTe8F15AA7PqhfUlz09JQdD.UWQisRGXP.', '9', 'Maria Christina', NULL, ''),
(281, 'U073694', '$2y$10$Pj/APJdjyiLeN1pWtpgHle5CS859LfwrorTX1/R.nfGJU2.dfx3jO', '1', 'Joyya Gebyalita', NULL, ''),
(282, '912360', '$2y$10$sN731bqFjWSorUl8AvtIHuUnJHdWBL2Qiiyj3sYiAlB548pMiV/0W', '15', 'Candera Liauw', NULL, ''),
(283, 'U548723', '$2y$10$9Ge8IKNkkX26vUPU1UjBEuM7I/Wv.RmyMYtEmmsIHVa/FTZhZ1BYS', '3', 'Saima Lantang', NULL, ''),
(284, 'U074601', '$2y$10$tCHO79bhtIM60w8w9kTfkuluPh./4hCXFTg4R1piH1C9IqBs4xjTq', '10', 'Yohanes Erick Prajitno', NULL, ''),
(286, 'U074713', '$2y$10$qdknpoghxyMItWg3Ehg4pOtF7Qcog9PfLfZRuWziB.vWo85Nj4wBy', '14', 'Celinia Harijono', NULL, ''),
(287, 'U074316', '$2y$10$cd/51j1OQ9BbgKgDAwe/GOXQXbGa0CutC0VzduHQnvmqyNoylH06i', '9', 'Steven Christian', NULL, ''),
(289, 'U065481', '$2y$10$1Zd412VC4EDtmlATSAkntu0N4p5/kex7EM/Z3dWM6IvtF/WqY3RfS', '9', 'Cynthia', NULL, ''),
(291, 'U073037', '$2y$10$W8UTzRt6sA6Pg0NLDZI0ZOKFrEDxzfRjTODfDjYBqfHzYuhYkWnUG', '3', 'Elisse Claudea Bella', NULL, ''),
(292, 'U074937', '$2y$10$sdZ8pBa2jxMjFOMC.ZM17eT.3iNmbIf4iOj9VYfDnhldMo/rpJH2a', '1', 'Randy Irawan', NULL, ''),
(293, 'U070237', '$2y$10$vCun1L01MTqqV3ZWca3aG.Qpj99SVTI6/mKkbSPQbl0a50CWgM77y', '9', 'Juli Yana', NULL, ''),
(294, 'U074883', '$2y$10$qNaCLddaDVbYu4m6Iwib5epptn3GwB19GM0MZ.foCa1gpsntqPHXS', '9', 'Setiawati Oktavia', NULL, ''),
(295, 'U074927', '$2y$10$3SJB/EsGjf.HbinicxlxEOPZH94AbUoN091UnWd1BkTGKlK1zhqXy', '3', 'Tiara Tannesha Hartono', NULL, ''),
(296, 'U075393', '$2y$10$Zo3xIfWHE8DKUGtbOgIck.i9Wu/Cb4C/LdTomfUAj9HwYfV5hYjXu', '1', 'Adi Julianto Halim P', NULL, ''),
(297, 'sa', '$2y$10$WsD3tlfV/1V1o0RlfvsO1.gJbVqrK.iog2ysw3PbVrSCoDWV7HtCC', '0', 'Super Admin', NULL, ''),
(445, 'U075574', '$2y$10$hgYROXRESVvqqOb9n5Vbq.rulrASHuKrtrB7X8GzeF9dEH//MbJya', '3', 'Hansen Setyawan Bunari', NULL, ''),
(446, 'U069637', '$2y$10$f5UhwvBBqTl9y/pd/5MLeO2r5bWkbrjtuam0mFj51f9JwuqTa0W8m', '9', 'Christie Limnois', NULL, ''),
(447, 'U067693', '$2y$10$hpsrezl8EVr6EL//d/4lKOIsh8RDRNRFbRjOnlUWCopdKjORKQdiC', '9', 'Elsa Christina', NULL, ''),
(448, 'U074928', '$2y$10$F4F7pg1H3qcuNI1ddpoFbeBw/R1mUNQ6mBlBeDKkXMvfUeighLfhq', '6', 'Steven Djohan Reynara', NULL, ''),
(449, 'U076013', '$2y$10$OwCwZIZrAJuM0b8cTkxRbuaMueT.a.CHtI.oKxwJZIaS9.KHbRUeu', '6', 'LOUIS LIMANDA', NULL, ''),
(450, 'U074906', '$2y$10$UDORRONRV0WKEGIbhta5CewRo9dtOFolX4uYui.5BDT/aXuEhfaeG', '3', 'Audrey Febriana Kurniawan', NULL, ''),
(451, 'U067025', '$2y$10$ku4zE2iruQDZ6hSaJf3.0uT4cujEIM95r6CVbVT4OQIvnV3FywR1e', '23', 'Clarissa Valencia', NULL, ''),
(452, 'U076813', '$2y$10$I7LqqHV0BkeCZ/Igy0FajOpltGjHdpk74NVRCNFEWzYQKd5ZWpVd.', '10', 'Graciela Marcellina S', NULL, ''),
(453, 'U076818', '$2y$10$CcfcKK18x18XIAKQlTKQ/.V6Y7KhmkA0CDB4AphbHr4gxqWn2aSpC', '10', 'Gerardus Jason', NULL, ''),
(455, 'U076765', '$2y$10$nJ63pLTepM.ZzyvvDAp3M.K5M680VXleEqkQDfoXVPHR3gmgtEMWS', '1', 'Erlis', NULL, ''),
(456, 'U076764', '$2y$10$vRRPgNGhMrkE6/LRjg/gpu9X8T2pA/osY.SRFyj5VJe9NtaO/Ve4.', '1', 'Violin Janey Hewis', NULL, '');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `fasbg`
--
ALTER TABLE `fasbg`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `memobg`
--
ALTER TABLE `memobg`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_creator` (`creator`);

--
-- Indeks untuk tabel `msahu`
--
ALTER TABLE `msahu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_username_datepenarikan_ptname` (`userName`,`datePenarikan`,`ptName`);

--
-- Indeks untuk tabel `msasli`
--
ALTER TABLE `msasli`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_username_transdate_company` (`username`,`transdate`,`company`);

--
-- Indeks untuk tabel `msasuransi`
--
ALTER TABLE `msasuransi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_username_transdate_debitur` (`username`,`transdate`,`debitur`);

--
-- Indeks untuk tabel `msblokirrekening`
--
ALTER TABLE `msblokirrekening`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_username_datetransaction_ptname` (`username`,`dateTransaction`,`ptname`);

--
-- Indeks untuk tabel `msborrow`
--
ALTER TABLE `msborrow`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_username_transdate_company` (`username`,`transdate`,`company`);

--
-- Indeks untuk tabel `mscams`
--
ALTER TABLE `mscams`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_username_transdate_company` (`username`,`transdate`,`company`);

--
-- Indeks untuk tabel `mscamscategory`
--
ALTER TABLE `mscamscategory`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `msforum`
--
ALTER TABLE `msforum`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `msinstruction`
--
ALTER TABLE `msinstruction`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_username_transdate_company` (`username`,`transdate`,`company`);

--
-- Indeks untuk tabel `msjaminan`
--
ALTER TABLE `msjaminan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `msmoncategory`
--
ALTER TABLE `msmoncategory`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `msmonitoring`
--
ALTER TABLE `msmonitoring`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_username_transdate_company` (`username`,`transdate`,`company`);

--
-- Indeks untuk tabel `msmonreturn`
--
ALTER TABLE `msmonreturn`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_username2_transdate_company` (`username2`,`transdate`,`company`);

--
-- Indeks untuk tabel `msnews`
--
ALTER TABLE `msnews`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `msnonfintrans`
--
ALTER TABLE `msnonfintrans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_name_date_dbt` (`name`,`date`,`dbt`);

--
-- Indeks untuk tabel `msnonsmile`
--
ALTER TABLE `msnonsmile`
  ADD PRIMARY KEY (`uniqueid`);

--
-- Indeks untuk tabel `msprovisi`
--
ALTER TABLE `msprovisi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `msreturn`
--
ALTER TABLE `msreturn`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_username_transdate_company` (`username`,`transdate`,`company`);

--
-- Indeks untuk tabel `msscan`
--
ALTER TABLE `msscan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `mstarik`
--
ALTER TABLE `mstarik`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_username_transdate_company` (`username`,`transdate`,`company`);

--
-- Indeks untuk tabel `mstarikasuransi`
--
ALTER TABLE `mstarikasuransi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_username_transdate_debiturname` (`username`,`transdate`,`debiturName`);

--
-- Indeks untuk tabel `mstrans`
--
ALTER TABLE `mstrans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_trans_date` (`transdate`),
  ADD KEY `idx_company_name` (`company`);

--
-- Indeks untuk tabel `msuser`
--
ALTER TABLE `msuser`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_role_name` (`role`,`name`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `fasbg`
--
ALTER TABLE `fasbg`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=840;

--
-- AUTO_INCREMENT untuk tabel `memobg`
--
ALTER TABLE `memobg`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT untuk tabel `msahu`
--
ALTER TABLE `msahu`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1690;

--
-- AUTO_INCREMENT untuk tabel `msasli`
--
ALTER TABLE `msasli`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44426;

--
-- AUTO_INCREMENT untuk tabel `msasuransi`
--
ALTER TABLE `msasuransi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5862;

--
-- AUTO_INCREMENT untuk tabel `msblokirrekening`
--
ALTER TABLE `msblokirrekening`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1914;

--
-- AUTO_INCREMENT untuk tabel `msborrow`
--
ALTER TABLE `msborrow`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3435;

--
-- AUTO_INCREMENT untuk tabel `mscams`
--
ALTER TABLE `mscams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49477;

--
-- AUTO_INCREMENT untuk tabel `mscamscategory`
--
ALTER TABLE `mscamscategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=190;

--
-- AUTO_INCREMENT untuk tabel `msforum`
--
ALTER TABLE `msforum`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT untuk tabel `msinstruction`
--
ALTER TABLE `msinstruction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=369;

--
-- AUTO_INCREMENT untuk tabel `msjaminan`
--
ALTER TABLE `msjaminan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7294;

--
-- AUTO_INCREMENT untuk tabel `msmoncategory`
--
ALTER TABLE `msmoncategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=189;

--
-- AUTO_INCREMENT untuk tabel `msmonitoring`
--
ALTER TABLE `msmonitoring`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1645;

--
-- AUTO_INCREMENT untuk tabel `msmonreturn`
--
ALTER TABLE `msmonreturn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3380;

--
-- AUTO_INCREMENT untuk tabel `msnews`
--
ALTER TABLE `msnews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `msnonfintrans`
--
ALTER TABLE `msnonfintrans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9461;

--
-- AUTO_INCREMENT untuk tabel `msnonsmile`
--
ALTER TABLE `msnonsmile`
  MODIFY `uniqueid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1031;

--
-- AUTO_INCREMENT untuk tabel `msprovisi`
--
ALTER TABLE `msprovisi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54301;

--
-- AUTO_INCREMENT untuk tabel `msreturn`
--
ALTER TABLE `msreturn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59239;

--
-- AUTO_INCREMENT untuk tabel `msscan`
--
ALTER TABLE `msscan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=333;

--
-- AUTO_INCREMENT untuk tabel `mstarik`
--
ALTER TABLE `mstarik`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1596;

--
-- AUTO_INCREMENT untuk tabel `mstarikasuransi`
--
ALTER TABLE `mstarikasuransi`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=332;

--
-- AUTO_INCREMENT untuk tabel `mstrans`
--
ALTER TABLE `mstrans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=147990;

--
-- AUTO_INCREMENT untuk tabel `msuser`
--
ALTER TABLE `msuser`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=457;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
